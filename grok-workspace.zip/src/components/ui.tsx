import { cva, type VariantProps } from "class-variance-authority";
import { Printer } from "lucide-react";
import { Link } from "@tanstack/react-router";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

const buttonStyles = cva(
  "inline-flex items-center justify-center gap-2 rounded-full font-extrabold transition duration-200 disabled:cursor-not-allowed disabled:opacity-45",
  {
    variants: {
      variant: {
        gold: "bg-gold text-cream hover:opacity-90",
        rose: "bg-rose text-cream hover:opacity-90",
        line: "border border-line bg-cream text-ink hover:border-gold",
        ghost: "bg-transparent text-ink hover:bg-gold-soft",
      },
      size: {
        md: "min-h-11 px-5 text-base",
        sm: "min-h-11 px-4 text-sm",
      },
    },
    defaultVariants: { variant: "gold", size: "md" },
  },
);

export function buttonClass(opts?: { variant?: "gold" | "rose" | "line" | "ghost"; size?: "md" | "sm" }) {
  return buttonStyles(opts);
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonStyles>;

export function Button({ className, variant, size, type = "button", ...props }: ButtonProps) {
  return <button type={type} className={cn(buttonStyles({ variant, size }), className)} {...props} />;
}

export function Portrait({
  name,
  photo,
  className,
}: {
  name: string;
  photo?: string;
  className?: string;
}) {
  const letter = name.trim().charAt(0).toUpperCase() || "?";
  return (
    <div
      className={cn(
        "relative flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-rose-soft font-display text-rose ring-2 ring-gold-soft",
        className,
      )}
    >
      {photo ? (
        <img src={photo} alt="" className="h-full w-full object-cover" />
      ) : (
        <span aria-hidden="true">{letter}</span>
      )}
    </div>
  );
}

export function Frame({
  name,
  photo,
  className,
}: {
  name: string;
  photo?: string;
  className?: string;
}) {
  const letter = name.trim().charAt(0).toUpperCase() || "?";
  return (
    <div
      className={cn(
        "flex items-center justify-center overflow-hidden rounded-2xl border border-gold bg-gold-soft font-display text-gold",
        className,
      )}
    >
      {photo ? (
        <img src={photo} alt="" className="h-full w-full object-cover" />
      ) : (
        <span aria-hidden="true">{letter}</span>
      )}
    </div>
  );
}

export function Panel({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-3xl border border-line bg-cream p-4 shadow-sm sm:p-5", className)}>
      {children}
    </section>
  );
}

export function NeedPlayers({
  min,
  count,
  children,
}: {
  min: number;
  count: number;
  children: React.ReactNode;
}) {
  if (count >= min) return children;
  return (
    <Panel>
      <p className="font-display text-2xl">La table est encore trop petite.</p>
      <p className="mt-2 text-muted">
        Ce jeu demande {min} visages. La maison en compte {count}.
      </p>
      <Link to="/atelier" className={cn(buttonClass(), "mt-4")}>
        Composer la maison
      </Link>
    </Panel>
  );
}

export function PrintBar({ children }: { children?: React.ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 print:hidden">
      <p className="max-w-xl text-sm text-muted">
        {children ?? "Planches au format carte. Imprimez, ou enregistrez en PDF, puis découpez le filet."}
      </p>
      <Button variant="line" onClick={() => window.print()}>
        <Printer className="size-4" aria-hidden="true" />
        Imprimer
      </Button>
    </div>
  );
}

export function PaperCard({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <article
      className={cn(
        "sheet-card flex flex-col justify-between overflow-hidden rounded-2xl border border-gold bg-cream p-3 text-ink",
        className,
      )}
    >
      {children}
    </article>
  );
}

export function LogList({ lines }: { lines: string[] }) {
  if (!lines.length) return null;
  return (
    <ol className="mt-4 space-y-1 text-sm text-muted">
      {lines.map((line, index) => (
        <li key={`${index}-${line}`}>{line}</li>
      ))}
    </ol>
  );
}

const PIP: Record<number, number[]> = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
};

export function Die({ value }: { value: number }) {
  const on = new Set(PIP[value] ?? []);
  return (
    <div
      aria-label={`Dé ${value}`}
      className="grid h-14 w-14 grid-cols-3 gap-1 rounded-2xl border border-gold bg-cream p-1.5"
    >
      {Array.from({ length: 9 }, (_, index) => (
        <span
          key={index}
          className={cn("rounded-full", on.has(index) ? "bg-ink" : "bg-transparent")}
        />
      ))}
    </div>
  );
}

export type Mode = "jouer" | "imprimer" | "regles";
