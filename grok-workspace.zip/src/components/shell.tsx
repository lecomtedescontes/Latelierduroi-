import { Link, useRouterState } from "@tanstack/react-router";
import { Crown } from "lucide-react";
import { useEffect } from "react";
import { cn } from "@/lib/cn";
import { useParty } from "@/lib/party-store";

export function Shell({ children }: { children: React.ReactNode }) {
  const hydrate = useParty((state) => state.hydrate);
  const path = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const links = [
    { to: "/", label: "Salon" },
    { to: "/atelier", label: "Atelier" },
  ] as const;

  return (
    <div className="min-h-screen text-ink">
      <header className="print:hidden">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-4">
          <Link to="/" className="flex min-h-11 items-center gap-2">
            <span className="flex size-10 items-center justify-center rounded-full bg-gold text-cream">
              <Crown className="size-5" aria-hidden="true" />
            </span>
            <span className="font-display text-lg leading-tight sm:text-xl">
              L'Atelier du Petit Roi
            </span>
          </Link>
          <nav className="flex items-center gap-1">
            {links.map((link) => {
              const active = path === link.to;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={cn(
                    "inline-flex min-h-11 items-center rounded-full px-4 text-sm font-extrabold",
                    active ? "bg-ink text-cream" : "text-ink hover:bg-gold-soft",
                  )}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl px-4 pb-16">{children}</main>
      <footer className="print:hidden mx-auto w-full max-w-6xl px-4 pb-10 text-sm text-muted">
        Jeux originaux de l'atelier. Les portraits restent sur cet appareil : rien n'est envoyé.
      </footer>
    </div>
  );
}
