import { useState } from "react";
import { Button, Die, Panel, Portrait, PrintBar, PaperCard, type Mode } from "@/components/ui";
import { cn } from "@/lib/cn";
import { useParty, type Player } from "@/lib/party-store";

type Space =
  | { t: "gate"; name: string }
  | { t: "estate"; name: string; price: number; rent: number }
  | { t: "edict"; name: string }
  | { t: "tax"; name: string; amount: number }
  | { t: "rest"; name: string };

const SPACES: Space[] = [
  { t: "gate", name: "Porte d'or" },
  { t: "estate", name: "Verger", price: 60, rent: 8 },
  { t: "edict", name: "Édit" },
  { t: "estate", name: "Rubans", price: 70, rent: 10 },
  { t: "tax", name: "Cygnes", amount: 20 },
  { t: "estate", name: "Hiboux", price: 90, rent: 14 },
  { t: "estate", name: "Porcelaine", price: 100, rent: 14 },
  { t: "rest", name: "Sieste" },
  { t: "estate", name: "Galerie", price: 120, rent: 18 },
  { t: "edict", name: "Édit" },
  { t: "estate", name: "Cuisine", price: 130, rent: 20 },
  { t: "estate", name: "Orangerie", price: 140, rent: 22 },
  { t: "tax", name: "Bal", amount: 30 },
  { t: "estate", name: "Ambre", price: 160, rent: 24 },
  { t: "estate", name: "Livres", price: 180, rent: 28 },
  { t: "estate", name: "Trône", price: 220, rent: 36 },
];

const LAYOUT: ({ k: "s"; n: number } | { k: "c" })[] = [
  { k: "s", n: 0 },
  { k: "s", n: 1 },
  { k: "s", n: 2 },
  { k: "s", n: 3 },
  { k: "s", n: 4 },
  { k: "s", n: 15 },
  { k: "c" },
  { k: "s", n: 5 },
  { k: "s", n: 14 },
  { k: "s", n: 6 },
  { k: "s", n: 13 },
  { k: "s", n: 7 },
  { k: "s", n: 12 },
  { k: "s", n: 11 },
  { k: "s", n: 10 },
  { k: "s", n: 9 },
  { k: "s", n: 8 },
];

const DEEDS: { name: string; price: number; rent: number }[] = [
  { name: "Verger de miel", price: 60, rent: 8 },
  { name: "Atelier des rubans", price: 70, rent: 10 },
  { name: "Tour des hiboux", price: 90, rent: 14 },
  { name: "Salon de porcelaine", price: 100, rent: 14 },
  { name: "Galerie des miroirs", price: 120, rent: 18 },
  { name: "Cuisine d'argent", price: 130, rent: 20 },
  { name: "Orangerie", price: 140, rent: 22 },
  { name: "Chambre d'ambre", price: 160, rent: 24 },
  { name: "Bibliothèque", price: 180, rent: 28 },
  { name: "Salle du trône", price: 220, rent: 36 },
];

type Pawn = { id: string; name: string; photo?: string; pos: number; money: number; out: boolean };
type Own = { ownerId: string; gilded: boolean };
type Phase =
  | { t: "roll" }
  | { t: "buy"; index: number }
  | { t: "own"; index: number }
  | { t: "note" }
  | { t: "end"; id: string; reason: string };

type Model = {
  pawns: Pawn[];
  own: Record<number, Own>;
  turn: number;
  phase: Phase;
  die: number | null;
  note: string;
};

const PASS = 20;
const GILD = 50;
const WIN = 400;
const PURSE = 220;

function logName(model: Model) {
  return model.pawns[model.turn]?.name ?? "";
}

function alive(model: Model) {
  return model.pawns.filter((pawn) => !pawn.out);
}

function finish(model: Model): Model {
  const rich = model.pawns.find((pawn) => !pawn.out && pawn.money >= WIN);
  if (rich) return { ...model, phase: { t: "end", id: rich.id, reason: `${rich.name} atteint ${WIN} écus.` } };
  const left = alive(model);
  if (left.length <= 1 && left[0]) {
    return { ...model, phase: { t: "end", id: left[0].id, reason: `${left[0].name} reste seul dans le domaine.` } };
  }
  return model;
}

function pay(model: Model, fromId: string, amount: number, toId: string | null): { model: Model; broke: boolean } {
  const pawns = model.pawns.map((pawn) => ({ ...pawn }));
  const from = pawns.find((pawn) => pawn.id === fromId);
  if (!from || from.out) return { model, broke: false };
  if (from.money >= amount) {
    from.money -= amount;
    if (toId) {
      const to = pawns.find((pawn) => pawn.id === toId);
      if (to) to.money += amount;
    }
    return { model: { ...model, pawns }, broke: false };
  }
  if (toId) {
    const to = pawns.find((pawn) => pawn.id === toId);
    if (to) to.money += from.money;
  }
  from.money = 0;
  from.out = true;
  const own = { ...model.own };
  for (const key of Object.keys(own)) {
    const index = Number(key);
    if (own[index]?.ownerId === fromId) delete own[index];
  }
  return { model: { ...model, pawns, own }, broke: true };
}

function give(model: Model, amount: number, note: string): Model {
  const pawns = model.pawns.map((pawn, index) =>
    index === model.turn ? { ...pawn, money: pawn.money + amount } : pawn,
  );
  return finish({ ...model, pawns, phase: { t: "note" }, note });
}

function edict(model: Model): Model {
  const roll = Math.floor(Math.random() * 6);
  if (roll === 0) return give(model, 25, `${logName(model)} reçoit 25 écus du trésor.`);
  if (roll === 1) return give(model, 40, `Un invité laisse 40 écus à ${logName(model)}.`);
  if (roll === 2) {
    const charged = pay(model, model.pawns[model.turn]!.id, 15, null);
    const note = charged.broke
      ? `${logName(model)} ne peut pas payer les lanternes et quitte la table.`
      : `${logName(model)} paie 15 écus pour les lanternes.`;
    return finish({ ...charged.model, phase: { t: "note" }, note });
  }
  if (roll === 3) {
    let next = model;
    const others = model.pawns.filter((pawn) => !pawn.out && pawn.id !== model.pawns[model.turn]?.id);
    for (const other of others) {
      next = pay(next, other.id, 10, model.pawns[model.turn]!.id).model;
    }
    return finish({
      ...next,
      phase: { t: "note" },
      note: `C'est la fête de ${logName(model)} : chacun donne 10 écus, s'il le peut.`,
    });
  }
  if (roll === 4) {
    const ownerId = model.pawns[model.turn]!.id;
    const owned = Object.entries(model.own)
      .filter(([, value]) => value.ownerId === ownerId && !value.gilded)
      .map(([key]) => Number(key))
      .sort((a, b) => {
        const pa = SPACES[a];
        const pb = SPACES[b];
        return (pa?.t === "estate" ? pa.price : 0) - (pb?.t === "estate" ? pb.price : 0);
      });
    if (!owned.length) {
      return { ...model, phase: { t: "note" }, note: "L'édit dore un domaine, mais vous n'en avez aucun de libre." };
    }
    const index = owned[0]!;
    return {
      ...model,
      own: { ...model.own, [index]: { ownerId, gilded: true } },
      phase: { t: "note" },
      note: `${SPACES[index]?.name ?? "Un domaine"} est doré sans frais.`,
    };
  }
  const charged = pay(model, model.pawns[model.turn]!.id, 20, null);
  return finish({
    ...charged.model,
    phase: { t: "note" },
    note: charged.broke
      ? `${logName(model)} a oublié sa bourse et quitte la table.`
      : `${logName(model)} paie 20 écus : bourse oubliée.`,
  });
}

function land(model: Model, pos: number): Model {
  const stopped = finish(model);
  if (stopped.phase.t === "end") return stopped;
  const space = SPACES[pos];
  const pawn = model.pawns[model.turn];
  if (!space || !pawn) return model;
  if (space.t === "estate") {
    const owner = model.own[pos];
    if (!owner) return { ...model, phase: { t: "buy", index: pos } };
    if (owner.ownerId === pawn.id) return { ...model, phase: { t: "own", index: pos } };
    const holder = model.pawns.find((item) => item.id === owner.ownerId);
    const rent = space.rent * (owner.gilded ? 2 : 1);
    if (!holder || holder.out) return { ...model, phase: { t: "buy", index: pos } };
    const charged = pay(model, pawn.id, rent, holder.id);
    return finish({
      ...charged.model,
      phase: { t: "note" },
      note: charged.broke
        ? `${pawn.name} ne peut pas payer ${rent} écus et quitte la table.`
        : `${pawn.name} verse ${rent} écus à ${holder.name}.`,
    });
  }
  if (space.t === "tax") {
    const charged = pay(model, pawn.id, space.amount, null);
    return finish({
      ...charged.model,
      phase: { t: "note" },
      note: charged.broke
        ? `${pawn.name} ne paie pas ${space.name} et sort.`
        : `${pawn.name} paie ${space.amount} écus : ${space.name}.`,
    });
  }
  if (space.t === "edict") return edict(model);
  if (space.t === "rest") return { ...model, phase: { t: "note" }, note: `${pawn.name} fait la sieste au jardin.` };
  return { ...model, phase: { t: "note" }, note: `${pawn.name} est à la Porte d'or.` };
}

export function Domaine({ mode }: { mode: Mode }) {
  const players = useParty((state) => state.players);
  const [model, setModel] = useState<Model | null>(null);

  function begin(source: Player[]) {
    const pawns = source.slice(0, 6).map((player) => ({
      id: player.id,
      name: player.name.trim() || "Invité",
      photo: player.photo,
      pos: 0,
      money: PURSE,
      out: false,
    }));
    setModel({
      pawns,
      own: {},
      turn: 0,
      phase: { t: "roll" },
      die: null,
      note: `Chacun reçoit ${PURSE} écus. Premier à ${WIN}, ou dernier debout.`,
    });
  }

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        {players.length < 2 ? (
          <Panel>
            <p className="font-display text-2xl">Il faut deux acquéreurs.</p>
          </Panel>
        ) : !model ? (
          <Panel>
            <h2 className="font-display text-3xl">Seize lieux, une bourse</h2>
            <p className="mt-2 text-muted">
              Achetez, encaissez, dorez une fois pour doubler le loyer. Les édits de la cour bousculent les bourses.
              {players.length > 6 ? " Les six premiers de la maison jouent." : ""}
            </p>
            <Button className="mt-4" onClick={() => begin(players)}>
              Ouvrir les portes
            </Button>
          </Panel>
        ) : (
          <Match model={model} setModel={setModel} onReset={() => setModel(null)} />
        )}
      </div>
      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>Titres de propriété à signer du sceau de l'acheteur. Le plateau numérique reste la partie vivante.</PrintBar>
        <div className="sheet-grid">
          {DEEDS.map((deed) => (
            <PaperCard key={deed.name}>
              <p className="text-xs font-extrabold text-gold">Titre</p>
              <h3 className="font-display text-2xl leading-tight">{deed.name}</h3>
              <p className="text-sm">Prix {deed.price} · loyer {deed.rent}</p>
              <p className="text-sm">Doré : loyer {deed.rent * 2}</p>
              <p className="text-xs text-muted">Sceau du propriétaire</p>
            </PaperCard>
          ))}
        </div>
      </div>
      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>Chaque joueur part avec {PURSE} écus, sur la Porte d'or. Un dé. Passer ou retomber sur la Porte rapporte {PASS} écus.</p>
            <p>Un lieu libre s'achète. Chez un autre, on paie le loyer — double s'il est doré. Dorer coûte {GILD} écus, une fois.</p>
            <p>Si l'on ne peut pas payer, on rend ses domaines à la cour et l'on sort. On gagne à {WIN} écus, ou en restant le dernier.</p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Match({
  model,
  setModel,
  onReset,
}: {
  model: Model;
  setModel: (model: Model) => void;
  onReset: () => void;
}) {
  const pawn = model.pawns[model.turn];
  function nextTurn(base: Model) {
    if (base.phase.t === "end") return base;
    let turn = base.turn;
    for (let step = 0; step < base.pawns.length; step += 1) {
      turn = (turn + 1) % base.pawns.length;
      if (!base.pawns[turn]?.out) break;
    }
    return { ...base, turn, phase: { t: "roll" } as Phase, die: null };
  }

  function onRoll() {
    if (!pawn || model.phase.t !== "roll") return;
    const die = 1 + Math.floor(Math.random() * 6);
    const sum = pawn.pos + die;
    const passed = sum >= SPACES.length;
    const pos = sum % SPACES.length;
    const pawns = model.pawns.map((item, index) =>
      index === model.turn ? { ...item, pos, money: item.money + (passed ? PASS : 0) } : item,
    );
    const note = passed
      ? `${pawn.name} fait ${die}, touche ${PASS} à la Porte et s'arrête sur ${SPACES[pos]?.name}.`
      : `${pawn.name} fait ${die} et s'arrête sur ${SPACES[pos]?.name}.`;
    setModel(land({ ...model, pawns, die, note }, pos));
  }

  return (
    <div className="grid gap-4">
      <div className="grid grid-cols-5 gap-1">
        {LAYOUT.map((cell, index) => {
          if (cell.k === "c") {
            return (
              <div key="center" className="col-span-3 row-span-3 flex flex-col items-center justify-center rounded-3xl border border-line bg-gold-soft p-2 text-center">
                <p className="font-display text-xl leading-tight sm:text-2xl">Grand Domaine</p>
                {model.die ? <div className="mt-2"><Die value={model.die} /></div> : null}
                <p className="mt-2 text-xs font-extrabold">{pawn && model.phase.t !== "end" ? pawn.name : "Fin"}</p>
              </div>
            );
          }
          const space = SPACES[cell.n]!;
          const owner = model.own[cell.n];
          const holder = model.pawns.find((item) => item.id === owner?.ownerId);
          const here = model.pawns.filter((item) => !item.out && item.pos === cell.n);
          return (
            <div
              key={`${cell.n}-${index}`}
              className={cn(
                "flex min-h-16 flex-col justify-between rounded-xl border p-1",
                space.t === "edict" ? "border-rose bg-rose-soft" : space.t === "estate" ? "border-gold bg-cream" : "border-line bg-parchment",
              )}
            >
              <span className="text-xs font-extrabold leading-tight">{space.name}</span>
              <span className="flex items-center justify-between gap-1">
                {holder ? <Portrait name={holder.name} photo={holder.photo} className="size-5 text-xs" /> : <span />}
                <span className="flex">
                  {here.map((item) => (
                    <Portrait key={item.id} name={item.name} photo={item.photo} className="size-5 text-xs ring-1" />
                  ))}
                </span>
              </span>
            </div>
          );
        })}
      </div>
      <Panel>
        <p>{model.note}</p>
        {model.phase.t === "end" ? (
          <div className="mt-3">
            <h2 className="font-display text-3xl">{model.phase.reason}</h2>
            <Button className="mt-3" variant="line" onClick={onReset}>
              Rejouer
            </Button>
          </div>
        ) : model.phase.t === "roll" ? (
          <Button className="mt-3" onClick={onRoll}>
            Lancer le dé
          </Button>
        ) : model.phase.t === "buy" ? (
          <Buy model={model} setModel={setModel} />
        ) : model.phase.t === "own" ? (
          <OwnPane model={model} setModel={setModel} />
        ) : (
          <Button className="mt-3" onClick={() => setModel(nextTurn(model))}>
            Joueur suivant
          </Button>
        )}
        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
          {model.pawns.map((item) => (
            <li key={item.id} className={cn("flex items-center justify-between gap-2 rounded-2xl px-2 py-1", item.out && "opacity-50")}>
              <span className="flex items-center gap-2 font-extrabold">
                <Portrait name={item.name} photo={item.photo} className="size-8 text-sm" />
                {item.name}
              </span>
              <span className="text-sm">{item.out ? "sorti" : `${item.money} écus`}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

function Buy({ model, setModel }: { model: Model; setModel: (model: Model) => void }) {
  if (model.phase.t !== "buy") return null;
  const space = SPACES[model.phase.index];
  const pawn = model.pawns[model.turn];
  if (!space || space.t !== "estate" || !pawn) return null;
  const index = model.phase.index;
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      <Button
        disabled={pawn.money < space.price}
        onClick={() => {
          const charged = pay(model, pawn.id, space.price, null);
          setModel({
            ...charged.model,
            own: { ...charged.model.own, [index]: { ownerId: pawn.id, gilded: false } },
            phase: { t: "note" },
            note: `${pawn.name} achète ${space.name} pour ${space.price} écus.`,
          });
        }}
      >
        Acheter {space.price}
      </Button>
      <Button
        variant="line"
        onClick={() => setModel({ ...model, phase: { t: "note" }, note: `${pawn.name} laisse ${space.name}.` })}
      >
        Laisser
      </Button>
    </div>
  );
}

function OwnPane({ model, setModel }: { model: Model; setModel: (model: Model) => void }) {
  if (model.phase.t !== "own") return null;
  const space = SPACES[model.phase.index];
  const pawn = model.pawns[model.turn];
  const owner = model.own[model.phase.index];
  if (!space || space.t !== "estate" || !pawn || !owner) return null;
  const index = model.phase.index;
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      {!owner.gilded && (
        <Button
          disabled={pawn.money < GILD}
          onClick={() => {
            const charged = pay(model, pawn.id, GILD, null);
            setModel({
              ...charged.model,
              own: { ...charged.model.own, [index]: { ownerId: pawn.id, gilded: true } },
              phase: { t: "note" },
              note: `${pawn.name} dore ${space.name}. Le loyer double.`,
            });
          }}
        >
          Dorer ({GILD})
        </Button>
      )}
      <Button variant="line" onClick={() => setModel({ ...model, phase: { t: "note" }, note: `${pawn.name} séjourne chez soi.` })}>
        Continuer
      </Button>
    </div>
  );
}
