import { useState } from "react";
import { Button, LogList, NeedPlayers, Panel, PaperCard, Portrait, PrintBar, type Mode } from "@/components/ui";
import { useParty, type Player } from "@/lib/party-store";
import { shuffle } from "@/lib/shuffle";

const PROMPTS = [
  "Au bal, {name} arrive vêtu de ___.",
  "Le cadeau le plus étrange devant {name} : ___.",
  "Pour endormir le dragon de la tour, il faut ___.",
  "La recette secrète du goûter contient ___.",
  "Si le château parlait, il dirait : ___.",
  "{name} a un animal invisible qui ___.",
  "L'édit du jour interdit formellement ___.",
  "Dans la bibliothèque, un livre s'intitule ___.",
  "Cette nuit, {name} a rêvé de ___.",
  "Pour gagner le cœur de la cour, il suffit de ___.",
  "La potion rose sent ___.",
  "Personne ne sait que {name} collectionne ___.",
  "Le trône est trop grand : on le remplace par ___.",
  "À minuit, les portraits se mettent à ___.",
  "Le mot de passe du jardin secret est ___.",
  "Demain, tout le monde devra ___.",
  "Le goûter royal est annulé à cause de ___.",
  "{name} a brodé sur son mouchoir : ___.",
];

type Answer = { playerId: string; text: string };
type Step = "cover" | "write" | "judge" | "end";

type Model = {
  order: Player[];
  judge: number;
  prompt: string;
  deck: string[];
  step: Step;
  cursor: number;
  answers: Answer[];
  pile: Answer[];
  scores: Record<string, number>;
  log: string[];
};

function fill(template: string, players: Player[]) {
  const name = players[Math.floor(Math.random() * players.length)]?.name ?? "quelqu'un";
  return template.replaceAll("{name}", name);
}

function openRound(model: Model): Model {
  const deck = model.deck.length ? model.deck : shuffle(PROMPTS);
  const template = deck[0] ?? PROMPTS[0]!;
  return {
    ...model,
    deck: deck.slice(1),
    prompt: fill(template, model.order),
    step: "cover",
    cursor: 0,
    answers: [],
    pile: [],
  };
}

export function Phrases({ mode }: { mode: Mode }) {
  const players = useParty((state) => state.players);
  const [model, setModel] = useState<Model | null>(null);

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        <NeedPlayers min={3} count={players.length}>
          {!model ? (
            <Panel>
              <h2 className="font-display text-3xl">La phrase a un trou</h2>
              <p className="mt-2 text-muted">
                Chacun écrit à l'abri des regards. Le juge couronne la fin qu'il préfère. Premier à 5 points.
              </p>
              <Button
                className="mt-4"
                onClick={() => {
                  const scores: Record<string, number> = {};
                  const order = players.map((player) => ({
                    ...player,
                    name: player.name.trim() || "Invité",
                  }));
                  for (const player of order) scores[player.id] = 0;
                  setModel(
                    openRound({
                      order,
                      judge: 0,
                      prompt: "",
                      deck: shuffle(PROMPTS),
                      step: "cover",
                      cursor: 0,
                      answers: [],
                      pile: [],
                      scores,
                      log: [],
                    }),
                  );
                }}
              >
                Tirer une phrase
              </Button>
            </Panel>
          ) : (
            <Table model={model} setModel={setModel} onReset={() => setModel(null)} />
          )}
        </NeedPlayers>
      </div>
      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>Phrases à lire tout haut, et cartes-réponses au prénom de chacun.</PrintBar>
        <h2 className="font-display text-2xl">Phrases</h2>
        <div className="sheet-grid mt-3">
          {PROMPTS.map((prompt) => (
            <PaperCard key={prompt}>
              <p className="text-xs font-extrabold text-gold">Phrases de Soie</p>
              <p className="font-display text-xl leading-snug">{prompt.replaceAll("{name}", "______")}</p>
              <p className="text-xs text-muted">Le juge lit. Les autres écrivent.</p>
            </PaperCard>
          ))}
        </div>
        <h2 className="mt-8 font-display text-2xl">Réponses</h2>
        <div className="sheet-grid mt-3">
          {players.map((player) => (
            <PaperCard key={player.id}>
              <div className="flex items-center gap-2">
                <Portrait name={player.name} photo={player.photo} className="size-10 text-sm" />
                <p className="font-extrabold">{player.name}</p>
              </div>
              <div className="mt-8 space-y-4">
                <span className="block border-b border-gold" />
                <span className="block border-b border-gold" />
                <span className="block border-b border-gold" />
              </div>
              <p className="text-xs text-muted">Une idée, puis on plie.</p>
            </PaperCard>
          ))}
        </div>
      </div>
      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>À trois au moins. Le juge lit la phrase. Chaque autre joueur écrit une fin, sans la montrer.</p>
            <p>Le juge choisit sa préférée et donne un point. On change de juge. Le premier à cinq remporte le ruban.</p>
            <p>À l'impression, le prénom devient un blanc : la table le choisit à voix haute.</p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Table({
  model,
  setModel,
  onReset,
}: {
  model: Model;
  setModel: (model: Model) => void;
  onReset: () => void;
}) {
  const judge = model.order[model.judge];
  const writers = model.order.filter((player) => player.id !== judge?.id);

  function award(answer: Answer) {
    if (!judge) return;
    const scores = { ...model.scores, [answer.playerId]: (model.scores[answer.playerId] ?? 0) + 1 };
    const who = model.order.find((player) => player.id === answer.playerId);
    const log = [`${judge.name} couronne ${who?.name ?? "quelqu'un"} : « ${answer.text} »`, ...model.log].slice(0, 6);
    if (Object.values(scores).some((score) => score >= 5)) {
      setModel({ ...model, scores, log, step: "end" });
      return;
    }
    const judgeIndex = (model.judge + 1) % model.order.length;
    setModel(openRound({ ...model, scores, log, judge: judgeIndex }));
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1.4fr_0.6fr]">
      <Panel>
        {model.step === "end" || !judge ? (
          <Winner model={model} onReset={onReset} />
        ) : model.step === "judge" ? (
          <div>
            <p className="text-sm font-extrabold text-gold">{judge.name} juge</p>
            <h2 className="mt-1 font-display text-3xl leading-tight">{model.prompt}</h2>
            <div className="mt-4 grid gap-2">
              {model.pile.map((answer) => (
                <button
                  key={answer.playerId}
                  type="button"
                  onClick={() => award(answer)}
                  className="min-h-11 rounded-2xl border border-line bg-parchment px-3 py-3 text-left font-extrabold"
                >
                  {answer.text}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <Writer
            key={`${model.judge}-${model.cursor}-${model.prompt}`}
            prompt={model.prompt}
            player={writers[model.cursor]}
            hidden={model.step === "cover"}
            onOpen={() => setModel({ ...model, step: "write" })}
            onAnswer={(text) => {
              const player = writers[model.cursor];
              if (!player) return;
              const answers = [...model.answers, { playerId: player.id, text }];
              if (model.cursor + 1 >= writers.length) {
                setModel({ ...model, answers, pile: shuffle(answers), step: "judge" });
                return;
              }
              setModel({ ...model, answers, cursor: model.cursor + 1, step: "cover" });
            }}
          />
        )}
      </Panel>
      <Panel>
        <h2 className="font-display text-2xl">Rubans</h2>
        <ul className="mt-3 space-y-2">
          {model.order.map((player) => (
            <li key={player.id} className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 font-extrabold">
                <Portrait name={player.name} photo={player.photo} className="size-8 text-sm" />
                {player.name}
                {player.id === judge?.id && model.step !== "end" ? (
                  <span className="text-xs font-extrabold text-gold">juge</span>
                ) : null}
              </span>
              <span>{model.scores[player.id] ?? 0}</span>
            </li>
          ))}
        </ul>
        <LogList lines={model.log} />
        <Button className="mt-4" variant="ghost" onClick={onReset}>
          Ranger les phrases
        </Button>
      </Panel>
    </div>
  );
}

function Writer({
  prompt,
  player,
  hidden,
  onOpen,
  onAnswer,
}: {
  prompt: string;
  player: Player | undefined;
  hidden: boolean;
  onOpen: () => void;
  onAnswer: (text: string) => void;
}) {
  const [text, setText] = useState("");
  if (!player) return null;
  if (hidden) {
    return (
      <div>
        <h2 className="font-display text-4xl">{player.name}</h2>
        <p className="mt-2 text-muted">Le juge et les autres regardent ailleurs.</p>
        <Button className="mt-4" onClick={onOpen}>
          Écrire ma réponse
        </Button>
      </div>
    );
  }
  return (
    <div>
      <p className="text-sm font-extrabold text-gold">{player.name} écrit</p>
      <h2 className="mt-2 font-display text-3xl leading-tight">{prompt}</h2>
      <textarea
        value={text}
        maxLength={80}
        onChange={(event) => setText(event.target.value)}
        placeholder="Votre fin de phrase"
        className="mt-4 min-h-24 w-full rounded-2xl border border-line bg-parchment p-3"
      />
      <Button className="mt-3" disabled={!text.trim()} onClick={() => onAnswer(text.trim())}>
        Plier la réponse
      </Button>
    </div>
  );
}

function Winner({ model, onReset }: { model: Model; onReset: () => void }) {
  const best = [...model.order].sort((a, b) => (model.scores[b.id] ?? 0) - (model.scores[a.id] ?? 0))[0];
  return (
    <div>
      <p className="text-sm font-extrabold text-gold">Cinq rubans</p>
      <h2 className="font-display text-4xl">{best ? `${best.name} emporte la soirée` : "Fin"}</h2>
      <Button className="mt-4" variant="line" onClick={onReset}>
        Rejouer
      </Button>
    </div>
  );
}
