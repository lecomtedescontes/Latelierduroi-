import { useEffect, useState } from "react";
import { Button, Frame, NeedPlayers, Panel, PaperCard, Portrait, PrintBar, type Mode } from "@/components/ui";
import { useParty, type Player } from "@/lib/party-store";
import { shuffle } from "@/lib/shuffle";

const MOTIFS = [
  "Orage doré",
  "Thé de minuit",
  "Cheval de nuage",
  "Clé perdue",
  "Jardin mouillé",
  "Rire sous cape",
  "Navire de sucre",
  "Lanterne bleue",
  "Escalier sans fin",
  "Lettre jamais lue",
  "Chapeau trop grand",
  "Soupe aux étoiles",
];

const TITLES = [
  "Regard de fête",
  "Couronne de travers",
  "Secret du col",
  "Clair de lune",
  "Rire en or",
  "Pas de velours",
  "Étoile dans l'œil",
  "Manteau trop grand",
];

type Card = { id: string; title: string; photo?: string; who?: string };
type Played = { playerId: string; card: Card };
type Step = "clue" | "cover" | "play" | "vote-cover" | "vote" | "score" | "end";

type Model = {
  players: Player[];
  hands: Record<string, Card[]>;
  storyteller: number;
  clue: string;
  picked: Card | null;
  played: Played[];
  order: Played[];
  votes: Record<string, string>;
  cursor: number;
  scores: Record<string, number>;
  step: Step;
  round: number;
};

function deckFor(players: Player[]): Card[] {
  const titles = shuffle(TITLES);
  const portraits: Card[] = players.map((player, index) => ({
    id: `face-${player.id}`,
    title: titles[index % titles.length] ?? "Portrait",
    photo: player.photo,
    who: player.name,
  }));
  const motifs: Card[] = MOTIFS.map((title, index) => ({ id: `motif-${index}`, title }));
  return shuffle([...portraits, ...motifs]);
}

function deal(players: Player[]): Model {
  const named = players.map((player) => ({ ...player, name: player.name.trim() || "Invité" }));
  const deck = deckFor(named);
  const size = Math.max(2, Math.min(5, Math.floor(deck.length / named.length)));
  const hands: Record<string, Card[]> = {};
  named.forEach((player, index) => {
    hands[player.id] = deck.slice(index * size, index * size + size);
  });
  const scores: Record<string, number> = {};
  for (const player of named) scores[player.id] = 0;
  return {
    players: named,
    hands,
    storyteller: 0,
    clue: "",
    picked: null,
    played: [],
    order: [],
    votes: {},
    cursor: 0,
    scores,
    step: "clue",
    round: 1,
  };
}

export function Eclats({ mode }: { mode: Mode }) {
  const party = useParty((state) => state.players);
  const [model, setModel] = useState<Model | null>(null);
  const [sheet, setSheet] = useState<Card[]>([]);

  useEffect(() => {
    const named = party.map((player) => ({ ...player, name: player.name.trim() || "Invité" }));
    setSheet(deckFor(named).slice(0, 12));
  }, [party]);

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        <NeedPlayers min={3} count={party.length}>
          {!model ? (
            <Panel>
              <h2 className="font-display text-3xl">Une phrase, plusieurs images</h2>
              <p className="mt-2 text-muted">
                Le conteur pose un éclat et une phrase. Les autres glissent une image qui pourrait convenir. On vote
                pour retrouver celle du conteur.
              </p>
              <Button className="mt-4" onClick={() => setModel(deal(party))}>
                Distribuer les éclats
              </Button>
            </Panel>
          ) : (
            <Table model={model} setModel={setModel} onReset={() => setModel(null)} />
          )}
        </NeedPlayers>
      </div>
      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>
          Douze éclats de cette maison — portraits et motifs. Imprimez, mélangez, inventez la phrase à voix haute.
        </PrintBar>
        <Sheet cards={sheet} />
      </div>
      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>Le conteur choisit une carte et dit une phrase. Chaque autre joueur pose une carte qui pourrait illustrer la même phrase.</p>
            <p>On mélange. Chacun vote, sauf le conteur, et jamais pour sa propre carte.</p>
            <p>Si tout le monde ou personne ne trouve le conteur, il marque 0 et les autres marquent 2. Sinon le conteur et ceux qui l'ont trouvé marquent 2. Chaque autre carte marque 1 par vote reçu.</p>
            <p>On change de conteur jusqu'à ce que les mains se vident.</p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Sheet({ cards }: { cards: Card[] }) {
  return (
    <div className="sheet-grid">
      {cards.map((card) => (
        <PaperCard key={card.id}>
          <p className="text-xs font-extrabold text-gold">Éclat de conte</p>
          {card.photo ? (
            <Frame name={card.who ?? card.title} photo={card.photo} className="mx-auto h-28 w-24 text-2xl" />
          ) : (
            <div className="mx-auto flex h-28 w-24 items-center justify-center rounded-2xl border border-gold bg-gold-soft" />
          )}
          <h3 className="text-center font-display text-xl leading-tight">{card.title}</h3>
        </PaperCard>
      ))}
    </div>
  );
}

function Table({
  model,
  setModel,
  onReset,
}: {
  model: Model;
  setModel: (model: Model) => void;
  onReset: () => void;
}) {
  const teller = model.players[model.storyteller];
  if (!teller) return null;
  const others = model.players.filter((player) => player.id !== teller.id);

  function removeFromHand(playerId: string, cardId: string) {
    return {
      ...model.hands,
      [playerId]: (model.hands[playerId] ?? []).filter((card) => card.id !== cardId),
    };
  }

  return (
    <Panel>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm font-extrabold text-gold">Conte {model.round}</p>
        <Button variant="ghost" size="sm" onClick={onReset}>
          Ranger
        </Button>
      </div>
      <ul className="mt-3 flex flex-wrap gap-2">
        {model.players.map((player) => (
          <li key={player.id} className="flex items-center gap-2 rounded-full bg-parchment py-1 pr-3 pl-1 text-sm font-extrabold">
            <Portrait name={player.name} photo={player.photo} className="size-8 text-sm" />
            {player.name} · {model.scores[player.id] ?? 0}
          </li>
        ))}
      </ul>

      {model.step === "clue" && (
        <Clue
          teller={teller}
          hand={model.hands[teller.id] ?? []}
          onSubmit={(clue, card) => {
            setModel({
              ...model,
              clue,
              picked: card,
              played: [{ playerId: teller.id, card }],
              hands: removeFromHand(teller.id, card.id),
              cursor: 0,
              step: "cover",
            });
          }}
        />
      )}

      {(model.step === "cover" || model.step === "play") && (
        <Offer
          key={`${model.round}-${model.cursor}`}
          model={model}
          player={others[model.cursor]}
          open={model.step === "play"}
          onOpen={() => setModel({ ...model, step: "play" })}
          onPlay={(card) => {
            const player = others[model.cursor];
            if (!player) return;
            const played = [...model.played, { playerId: player.id, card }];
            const hands = removeFromHand(player.id, card.id);
            if (model.cursor + 1 >= others.length) {
              setModel({ ...model, played, hands, order: shuffle(played), cursor: 0, votes: {}, step: "vote-cover" });
              return;
            }
            setModel({ ...model, played, hands, cursor: model.cursor + 1, step: "cover" });
          }}
        />
      )}

      {(model.step === "vote-cover" || model.step === "vote") && (
        <Ballot
          key={`vote-${model.cursor}`}
          model={model}
          voters={others}
          open={model.step === "vote"}
          onOpen={() => setModel({ ...model, step: "vote" })}
          onVote={(cardId) => {
            const voter = others[model.cursor];
            if (!voter) return;
            const votes = { ...model.votes, [voter.id]: cardId };
            if (model.cursor + 1 >= others.length) {
              setModel(scoreRound({ ...model, votes }));
              return;
            }
            setModel({ ...model, votes, cursor: model.cursor + 1, step: "vote-cover" });
          }}
        />
      )}

      {model.step === "score" && <Score model={model} setModel={setModel} />}
      {model.step === "end" && (
        <div className="mt-4">
          <h2 className="font-display text-3xl">Les mains sont vides</h2>
          <Button className="mt-4" variant="line" onClick={onReset}>
            Rejouer
          </Button>
        </div>
      )}
    </Panel>
  );
}

function scoreRound(model: Model): Model {
  const teller = model.players[model.storyteller];
  if (!teller || !model.picked) return model;
  const voters = model.players.filter((player) => player.id !== teller.id);
  const found = voters.filter((player) => model.votes[player.id] === model.picked?.id);
  const allOrNone = found.length === 0 || found.length === voters.length;
  const scores = { ...model.scores };
  if (allOrNone) {
    for (const voter of voters) scores[voter.id] = (scores[voter.id] ?? 0) + 2;
  } else {
    scores[teller.id] = (scores[teller.id] ?? 0) + 2;
    for (const voter of found) scores[voter.id] = (scores[voter.id] ?? 0) + 2;
  }
  for (const voter of voters) {
    const choice = model.votes[voter.id];
    const owner = model.played.find((item) => item.card.id === choice);
    if (owner && owner.playerId !== teller.id) scores[owner.playerId] = (scores[owner.playerId] ?? 0) + 1;
  }
  return { ...model, scores, step: "score" };
}

function Clue({
  teller,
  hand,
  onSubmit,
}: {
  teller: Player;
  hand: Card[];
  onSubmit: (clue: string, card: Card) => void;
}) {
  const [clue, setClue] = useState("");
  const [cardId, setCardId] = useState<string | null>(null);
  const card = hand.find((item) => item.id === cardId) ?? null;
  return (
    <div className="mt-4">
      <h2 className="font-display text-3xl">{teller.name} conte</h2>
      <p className="mt-2 text-sm text-muted">Choisissez un éclat, puis une phrase que les autres entendront.</p>
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {hand.map((item) => (
          <CardButton key={item.id} card={item} on={item.id === cardId} onClick={() => setCardId(item.id)} />
        ))}
      </div>
      <input
        value={clue}
        maxLength={80}
        onChange={(event) => setClue(event.target.value)}
        placeholder="La phrase du conte"
        className="mt-3 min-h-11 w-full rounded-2xl border border-line bg-parchment px-3"
      />
      <Button className="mt-3" disabled={!clue.trim() || !card} onClick={() => card && onSubmit(clue.trim(), card)}>
        Poser l'éclat
      </Button>
    </div>
  );
}

function Offer({
  model,
  player,
  open,
  onOpen,
  onPlay,
}: {
  model: Model;
  player: Player | undefined;
  open: boolean;
  onOpen: () => void;
  onPlay: (card: Card) => void;
}) {
  if (!player) return null;
  if (!open) {
    return (
      <div className="mt-4">
        <h2 className="font-display text-3xl">{player.name}</h2>
        <p className="mt-2 text-muted">Vous allez entendre la phrase et choisir un éclat. Les autres se détournent.</p>
        <Button className="mt-4" onClick={onOpen}>
          Choisir mon éclat
        </Button>
      </div>
    );
  }
  const hand = model.hands[player.id] ?? [];
  return (
    <div className="mt-4">
      <p className="text-sm font-extrabold text-gold">Phrase de {model.players[model.storyteller]?.name}</p>
      <h2 className="font-display text-3xl leading-tight">« {model.clue} »</h2>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {hand.map((card) => (
          <CardButton key={card.id} card={card} on={false} onClick={() => onPlay(card)} />
        ))}
      </div>
    </div>
  );
}

function Ballot({
  model,
  voters,
  open,
  onOpen,
  onVote,
}: {
  model: Model;
  voters: Player[];
  open: boolean;
  onOpen: () => void;
  onVote: (cardId: string) => void;
}) {
  const voter = voters[model.cursor];
  if (!voter) return null;
  const own = model.played.find((item) => item.playerId === voter.id)?.card.id;
  if (!open) {
    return (
      <div className="mt-4">
        <h2 className="font-display text-3xl">{voter.name} vote</h2>
        <p className="mt-2 text-muted">Retrouvez l'éclat du conteur. Pas le vôtre.</p>
        <Button className="mt-4" onClick={onOpen}>
          Voir les éclats
        </Button>
      </div>
    );
  }
  return (
    <div className="mt-4">
      <p className="font-display text-2xl leading-tight">« {model.clue} »</p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {model.order.map((item, index) => (
          <CardButton
            key={item.card.id}
            card={item.card}
            on={false}
            disabled={item.card.id === own}
            caption={item.card.id === own ? "Votre éclat" : `Carte ${index + 1}`}
            onClick={() => onVote(item.card.id)}
          />
        ))}
      </div>
    </div>
  );
}

function Score({ model, setModel }: { model: Model; setModel: (model: Model) => void }) {
  const teller = model.players[model.storyteller];
  function next() {
    const upcoming = (model.storyteller + 1) % model.players.length;
    const tellerNext = model.players[upcoming];
    if (!tellerNext || (model.hands[tellerNext.id] ?? []).length === 0) {
      setModel({ ...model, step: "end" });
      return;
    }
    setModel({
      ...model,
      storyteller: upcoming,
      round: model.round + 1,
      clue: "",
      picked: null,
      played: [],
      order: [],
      votes: {},
      cursor: 0,
      step: "clue",
    });
  }
  return (
    <div className="mt-4">
      <h2 className="font-display text-3xl">Le conte se dévoile</h2>
      <p className="mt-2 text-sm text-muted">
        L'éclat de {teller?.name} était « {model.picked?.title} ».
      </p>
      <ul className="mt-3 space-y-2">
        {model.order.map((item) => {
          const owner = model.players.find((player) => player.id === item.playerId);
          const votes = Object.values(model.votes).filter((id) => id === item.card.id).length;
          return (
            <li key={item.card.id} className="rounded-2xl bg-parchment px-3 py-2 text-sm">
              <span className="font-extrabold">{item.card.title}</span> — {owner?.name}
              {item.playerId === teller?.id ? " · conteur" : ""} · {votes} vote{votes > 1 ? "s" : ""}
            </li>
          );
        })}
      </ul>
      <Button className="mt-4" onClick={next}>
        Conte suivant
      </Button>
    </div>
  );
}

function CardButton({
  card,
  on,
  disabled,
  caption,
  onClick,
}: {
  card: Card;
  on: boolean;
  disabled?: boolean;
  caption?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={`flex min-h-24 flex-col items-center justify-center gap-2 rounded-2xl border p-2 text-center disabled:opacity-40 ${on ? "border-gold bg-gold-soft" : "border-line bg-cream"}`}
    >
      {card.photo ? <Frame name={card.title} photo={card.photo} className="h-14 w-12 text-lg" /> : null}
      <span className="font-display text-lg leading-tight">{card.title}</span>
      {caption ? <span className="text-xs font-extrabold text-muted">{caption}</span> : null}
    </button>
  );
}
