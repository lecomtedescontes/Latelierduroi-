import { useState } from "react";
import {
  Button,
  Frame,
  LogList,
  NeedPlayers,
  Panel,
  PaperCard,
  Portrait,
  PrintBar,
  type Mode,
} from "@/components/ui";
import { useParty, type Player } from "@/lib/party-store";
import { shuffle } from "@/lib/shuffle";

type RoleId = "loup" | "lumiere" | "gardien" | "herboriste" | "heraut" | "courtisan";
type NightStep = "gardien" | "lumiere" | "loups" | "herboriste";

const ROLE: Record<RoleId, { title: string; text: string }> = {
  loup: {
    title: "Loup de velours",
    text: "Chaque nuit, avec la meute, désignez une proie. Le jour, mentez avec grâce.",
  },
  lumiere: {
    title: "La Lumière",
    text: "Chaque nuit, sondez un visage : loup de velours, ou de la cour.",
  },
  gardien: {
    title: "Gardien des clés",
    text: "Protégez quelqu'un chaque nuit. Jamais la même personne deux nuits de suite.",
  },
  herboriste: {
    title: "L'Herboriste",
    text: "Une rosée pour sauver la proie, une ombre pour en désigner une autre. Une fois chacune.",
  },
  heraut: {
    title: "Le Héraut",
    text: "Si vous tombez, désignez aussitôt quelqu'un qui vous suit.",
  },
  courtisan: {
    title: "Courtisan",
    text: "Aucun pouvoir la nuit. Le jour, votre voix pèse autant qu'une couronne.",
  },
};

const COVER: Record<NightStep, string> = {
  gardien: "le Gardien des clés",
  lumiere: "la Lumière",
  loups: "les Loups de velours",
  herboriste: "l'Herboriste",
};

function composition(count: number): RoleId[] {
  const packs: Record<number, RoleId[]> = {
    4: ["loup", "lumiere", "herboriste", "courtisan"],
    5: ["loup", "lumiere", "gardien", "herboriste", "courtisan"],
    6: ["loup", "loup", "lumiere", "herboriste", "heraut", "courtisan"],
    7: ["loup", "loup", "lumiere", "gardien", "herboriste", "heraut", "courtisan"],
    8: ["loup", "loup", "lumiere", "gardien", "herboriste", "heraut", "courtisan", "courtisan"],
  };
  const key = Math.max(4, Math.min(8, count));
  const roles = [...(packs[key] ?? packs[4]!)];
  while (roles.length < count) roles.push("courtisan");
  if (count >= 9) {
    const slot = roles.lastIndexOf("courtisan");
    if (slot >= 0) roles[slot] = "loup";
  }
  return roles;
}

type Seat = {
  playerId: string;
  name: string;
  photo?: string;
  role: RoleId;
  alive: boolean;
};

type Phase =
  | { t: "peek"; i: number; open: boolean }
  | { t: "cover"; step: NightStep }
  | { t: "act"; step: NightStep }
  | { t: "heraut-cover"; then: "day" | "night" }
  | { t: "heraut"; then: "day" | "night" }
  | { t: "day" }
  | { t: "vote"; i: number; ballots: Record<string, string> }
  | { t: "end"; winner: "loups" | "cour"; reason: string };

type Model = {
  seats: Seat[];
  phase: Phase;
  night: number;
  steps: NightStep[];
  cursor: number;
  lastGuard: string | null;
  saveUsed: boolean;
  poisonUsed: boolean;
  guard: string | null;
  wolf: string | null;
  save: boolean;
  poison: string | null;
  seen: string;
  log: string[];
};

function winnerOf(seats: Seat[]): "loups" | "cour" | null {
  const wolves = seats.filter((seat) => seat.alive && seat.role === "loup").length;
  const court = seats.filter((seat) => seat.alive && seat.role !== "loup").length;
  if (wolves === 0) return "cour";
  if (court === 0 || wolves >= court) return "loups";
  return null;
}

function nightSteps(seats: Seat[], saveUsed: boolean, poisonUsed: boolean): NightStep[] {
  const live = seats.filter((seat) => seat.alive);
  const steps: NightStep[] = [];
  if (live.some((seat) => seat.role === "gardien")) steps.push("gardien");
  if (live.some((seat) => seat.role === "lumiere")) steps.push("lumiere");
  if (live.some((seat) => seat.role === "loup")) steps.push("loups");
  if (live.some((seat) => seat.role === "herboriste") && (!saveUsed || !poisonUsed)) {
    steps.push("herboriste");
  }
  return steps;
}

function withLog(model: Model, line: string): Model {
  return { ...model, log: [line, ...model.log].slice(0, 8) };
}

function endState(model: Model, winner: "loups" | "cour"): Model {
  return {
    ...model,
    phase: {
      t: "end",
      winner,
      reason: winner === "cour" ? "Plus un loup ne siège à la table." : "Les loups sont aussi nombreux que la cour.",
    },
  };
}

function openNight(model: Model): Model {
  const win = winnerOf(model.seats);
  if (win) return endState(model, win);
  const steps = nightSteps(model.seats, model.saveUsed, model.poisonUsed);
  const cleared = { ...model, steps, cursor: 0, guard: null, wolf: null, save: false, poison: null, seen: "" };
  if (!steps.length) return { ...cleared, phase: { t: "day" } };
  return { ...cleared, phase: { t: "cover", step: steps[0]! } };
}

function killAndContinue(model: Model, ids: string[], then: "day" | "night", line: string): Model {
  const heraut = model.seats.find(
    (seat) => seat.alive && ids.includes(seat.playerId) && seat.role === "heraut",
  );
  const seats = model.seats.map((seat) =>
    ids.includes(seat.playerId) ? { ...seat, alive: false } : seat,
  );
  const next = withLog({ ...model, seats }, line);
  if (heraut && seats.some((seat) => seat.alive)) {
    return { ...next, phase: { t: "heraut-cover", then } };
  }
  const win = winnerOf(seats);
  if (win) return endState(next, win);
  if (then === "night") return openNight({ ...next, night: model.night + 1 });
  return { ...next, phase: { t: "day" } };
}

function finishStep(model: Model): Model {
  const saveUsed = model.saveUsed || model.save;
  const poisonUsed = model.poisonUsed || Boolean(model.poison);
  const cursor = model.cursor + 1;
  const drafted = { ...model, saveUsed, poisonUsed, cursor };
  if (cursor >= model.steps.length) return resolveDawn(drafted);
  return { ...drafted, phase: { t: "cover", step: model.steps[cursor]! } };
}

function resolveDawn(model: Model): Model {
  const ids: string[] = [];
  if (model.wolf && model.wolf !== model.guard && !model.save) ids.push(model.wolf);
  if (model.poison && !ids.includes(model.poison)) ids.push(model.poison);
  const names = ids
    .map((id) => model.seats.find((seat) => seat.playerId === id)?.name)
    .filter((name): name is string => Boolean(name));
  const text = names.length
    ? `Aube ${model.night} : la cour pleure ${names.join(" et ")}.`
    : `Aube ${model.night} : la table est intacte.`;
  const guarded = model.guard ? { ...model, lastGuard: model.guard } : model;
  return killAndContinue(guarded, ids, "day", text);
}

function face(seat: Seat) {
  return { id: seat.playerId, name: seat.name, photo: seat.photo };
}

export function Minuit({ mode }: { mode: Mode }) {
  const players = useParty((state) => state.players);
  const [model, setModel] = useState<Model | null>(null);
  const [named, setNamed] = useState<Seat[] | null>(null);
  const roles = composition(Math.max(4, players.length));

  function begin(source: Player[]) {
    const dealt = shuffle(composition(source.length));
    const seats: Seat[] = source.map((player, index) => ({
      playerId: player.id,
      name: player.name.trim() || "Invité",
      photo: player.photo,
      role: dealt[index] ?? "courtisan",
      alive: true,
    }));
    setModel({
      seats,
      phase: { t: "peek", i: 0, open: false },
      night: 1,
      steps: [],
      cursor: 0,
      lastGuard: null,
      saveUsed: false,
      poisonUsed: false,
      guard: null,
      wolf: null,
      save: false,
      poison: null,
      seen: "",
      log: ["Les rôles sont tirés. Un seul visage à la fois."],
    });
  }

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        <NeedPlayers min={4} count={players.length}>
          {!model ? (
            <Panel>
              <h2 className="font-display text-3xl">La nuit va tomber</h2>
              <p className="mt-2 text-muted">
                Le conteur, c'est l'écran. Passez-le. Fermez les yeux quand on vous le demande. Au matin, vote à
                bulletin secret.
              </p>
              <Button className="mt-4" onClick={() => begin(players)}>
                Tirer les rôles
              </Button>
            </Panel>
          ) : (
            <Play model={model} setModel={setModel} onReset={() => setModel(null)} />
          )}
        </NeedPlayers>
      </div>

      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>
          Cartes de rôle à glisser dans une enveloppe, médaillons de table, et — si l'hôte distribue aussitôt —
          une édition où le portrait porte déjà son secret.
        </PrintBar>
        <h2 className="font-display text-2xl">Rôles à envelopper</h2>
        <div className="sheet-grid mt-3">
          {roles.map((role, index) => (
            <PaperCard key={`${role}-${index}`}>
              <p className="text-xs font-extrabold tracking-wide text-gold">Minuit au Château</p>
              <div>
                <h3 className="font-display text-2xl leading-tight">{ROLE[role].title}</h3>
                <p className="mt-2 text-sm leading-snug">{ROLE[role].text}</p>
              </div>
              <p className="text-xs text-muted">{role === "loup" ? "Meute" : "Cour"}</p>
            </PaperCard>
          ))}
        </div>
        <h2 className="mt-8 font-display text-2xl">Médaillons de table</h2>
        <div className="sheet-grid mt-3">
          {players.map((player) => (
            <PaperCard key={player.id}>
              <p className="text-xs font-extrabold text-gold">Place</p>
              <Frame name={player.name} photo={player.photo} className="mx-auto h-28 w-24 text-3xl" />
              <h3 className="text-center font-display text-2xl">{player.name}</h3>
            </PaperCard>
          ))}
        </div>
        <div className="mt-8 print:hidden">
          <Button
            variant="line"
            onClick={() => {
              const dealt = shuffle(composition(players.length));
              setNamed(
                players.map((player, index) => ({
                  playerId: player.id,
                  name: player.name.trim() || "Invité",
                  photo: player.photo,
                  role: dealt[index] ?? "courtisan",
                  alive: true,
                })),
              );
            }}
          >
            Préparer l'édition nominative
          </Button>
          <p className="mt-2 text-sm text-muted">
            À n'imprimer que si la table ne regarde pas : le rôle est écrit sous le portrait.
          </p>
        </div>
        {named && (
          <div className="sheet-grid mt-4">
            {named.map((seat) => (
              <PaperCard key={seat.playerId}>
                <Frame name={seat.name} photo={seat.photo} className="mx-auto h-24 w-20 text-2xl" />
                <div>
                  <h3 className="font-display text-xl">{seat.name}</h3>
                  <p className="text-sm font-extrabold text-rose">{ROLE[seat.role].title}</p>
                  <p className="mt-1 text-xs leading-snug">{ROLE[seat.role].text}</p>
                </div>
              </PaperCard>
            ))}
          </div>
        )}
      </div>

      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>De 4 à 8 joueurs. Au-delà, on ajoute des courtisans, et un troisième loup à partir de neuf.</p>
            <p>Chacun mémorise son rôle, puis la nuit suit toujours le même ordre : Gardien, Lumière, Meute, Herboriste.</p>
            <p>Le Gardien bloque seulement la proie des loups, et change de protégé chaque nuit. La Lumière apprend un camp. L'Herboriste peut sauver la proie et empoisonner quelqu'un, une fois pour chaque fiole. Le poison ignore le Gardien.</p>
            <p>Le jour, on débat puis on vote en secret. Égalité : personne ne sort. Le Héraut, en tombant, désigne une dernière personne.</p>
            <p>La cour gagne si plus aucun loup n'est en vie. Les loups gagnent dès qu'ils sont au moins aussi nombreux que les autres.</p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Play({
  model,
  setModel,
  onReset,
}: {
  model: Model;
  setModel: (model: Model) => void;
  onReset: () => void;
}) {
  const live = model.seats.filter((seat) => seat.alive);
  const phase = model.phase;

  return (
    <div className="grid gap-4 lg:grid-cols-[1.4fr_0.6fr]">
      <Panel>
        {phase.t === "peek" && <Peek model={model} setModel={setModel} />}
        {phase.t === "cover" && (
          <Cover
            title={`Nuit ${model.night}`}
            text={`Tout le monde ferme les yeux. Seul ${COVER[phase.step]} regarde.`}
            action="Je suis prêt"
            onNext={() => setModel({ ...model, phase: { t: "act", step: phase.step } })}
          />
        )}
        {phase.t === "act" && <Act model={model} setModel={setModel} />}
        {phase.t === "heraut-cover" && (
          <Cover
            title="Le Héraut tombe"
            text="Passez l'écran au Héraut. Les autres se détournent."
            action="Je désigne"
            onNext={() => setModel({ ...model, phase: { t: "heraut", then: phase.then } })}
          />
        )}
        {phase.t === "heraut" && (
          <div>
            <h2 className="font-display text-3xl">Qui vous suit ?</h2>
            <Choices
              options={live.map(face)}
              onPick={(id) => {
                const name = model.seats.find((seat) => seat.playerId === id)?.name ?? "";
                setModel(killAndContinue(model, [id], phase.then, `Le Héraut emporte ${name}.`));
              }}
            />
          </div>
        )}
        {phase.t === "day" && (
          <div>
            <h2 className="font-display text-3xl">Le jour dans la cour</h2>
            <p className="mt-2 text-muted">Débattez à voix haute. Quand la table est prête, le vote est secret.</p>
            <ul className="mt-4 flex flex-wrap gap-2">
              {model.seats.map((seat) => (
                <li
                  key={seat.playerId}
                  className={seat.alive ? "flex items-center gap-2 rounded-full bg-gold-soft py-1 pr-3 pl-1" : "flex items-center gap-2 rounded-full bg-rose-soft py-1 pr-3 pl-1 opacity-70"}
                >
                  <Portrait name={seat.name} photo={seat.photo} className="size-8 text-sm" />
                  <span className="text-sm font-extrabold">{seat.alive ? seat.name : `${seat.name} est tombé`}</span>
                </li>
              ))}
            </ul>
            <Button className="mt-4" onClick={() => setModel({ ...model, phase: { t: "vote", i: 0, ballots: {} } })}>
              Ouvrir le vote
            </Button>
          </div>
        )}
        {phase.t === "vote" && <Vote model={model} setModel={setModel} />}
        {phase.t === "end" && (
          <div>
            <p className="text-sm font-extrabold text-gold">{phase.winner === "cour" ? "Victoire de la cour" : "Victoire de la meute"}</p>
            <h2 className="font-display text-4xl">{phase.reason}</h2>
            <ul className="mt-4 space-y-2">
              {model.seats.map((seat) => (
                <li key={seat.playerId} className="flex items-center gap-3">
                  <Portrait name={seat.name} photo={seat.photo} className="size-10 text-sm" />
                  <span>
                    <span className="font-extrabold">{seat.name}</span>
                    <span className="block text-sm text-muted">
                      {ROLE[seat.role].title}
                      {seat.alive ? "" : " · tombé"}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
            <Button className="mt-4" variant="line" onClick={onReset}>
              Recommencer
            </Button>
          </div>
        )}
      </Panel>
      <Panel>
        <h2 className="font-display text-2xl">Chronique</h2>
        <LogList lines={model.log} />
        {phase.t !== "end" && (
          <Button className="mt-4" variant="ghost" onClick={onReset}>
            Abandonner la nuit
          </Button>
        )}
      </Panel>
    </div>
  );
}

function Peek({ model, setModel }: { model: Model; setModel: (model: Model) => void }) {
  const phase = model.phase;
  if (phase.t !== "peek") return null;
  const seat = model.seats[phase.i];
  if (!seat) return null;
  const role = ROLE[seat.role];
  return phase.open ? (
    <div>
      <p className="text-sm font-extrabold text-gold">{seat.name}</p>
      <h2 className="font-display text-4xl">{role.title}</h2>
      <p className="mt-2 max-w-md text-muted">{role.text}</p>
      {seat.role === "loup" && (
        <p className="mt-3 text-sm">
          Meute :{" "}
          {model.seats
            .filter((other) => other.role === "loup")
            .map((other) => other.name)
            .join(", ")}
        </p>
      )}
      <Button
        className="mt-4"
        onClick={() => {
          const next = phase.i + 1;
          if (next >= model.seats.length) setModel(openNight(model));
          else setModel({ ...model, phase: { t: "peek", i: next, open: false } });
        }}
      >
        J'ai retenu mon rôle
      </Button>
    </div>
  ) : (
    <Cover
      title={seat.name}
      text="Les autres regardent ailleurs. Seulement ce prénom touche l'écran."
      action="Voir mon rôle"
      onNext={() => setModel({ ...model, phase: { t: "peek", i: phase.i, open: true } })}
    />
  );
}

function Act({ model, setModel }: { model: Model; setModel: (model: Model) => void }) {
  const phase = model.phase;
  if (phase.t !== "act") return null;
  const live = model.seats.filter((seat) => seat.alive);
  if (phase.step === "gardien") {
    return (
      <div>
        <h2 className="font-display text-3xl">Qui protégez-vous ?</h2>
        <p className="mt-2 text-sm text-muted">Pas le même protégé que la nuit dernière.</p>
        <Choices
          options={live.map(face)}
          disabled={(id) => id === model.lastGuard}
          onPick={(id) => setModel(finishStep({ ...model, guard: id }))}
        />
      </div>
    );
  }
  if (phase.step === "lumiere") {
    const self = model.seats.find((seat) => seat.alive && seat.role === "lumiere");
    return (
      <div>
        <h2 className="font-display text-3xl">Qui sondez-vous ?</h2>
        {model.seen ? (
          <>
            <p className="mt-3 font-display text-2xl">{model.seen}</p>
            <Button className="mt-4" onClick={() => setModel(finishStep(model))}>
              Refermer les yeux
            </Button>
          </>
        ) : (
          <Choices
            options={live.filter((seat) => seat.playerId !== self?.playerId).map(face)}
            onPick={(id) => {
              const seat = model.seats.find((item) => item.playerId === id);
              const seen = seat
                ? `${seat.name} est ${seat.role === "loup" ? "un Loup de velours" : "de la cour"}.`
                : "";
              setModel({ ...model, seen });
            }}
          />
        )}
      </div>
    );
  }
  if (phase.step === "loups") {
    const pack = model.seats.filter((seat) => seat.alive && seat.role === "loup").map((seat) => seat.name);
    return (
      <div>
        <h2 className="font-display text-3xl">La meute choisit</h2>
        <p className="mt-2 text-sm text-muted">Ensemble : {pack.join(", ")}.</p>
        <Choices
          options={live.filter((seat) => seat.role !== "loup").map(face)}
          onPick={(id) => setModel(finishStep({ ...model, wolf: id }))}
        />
      </div>
    );
  }
  const victim = model.seats.find((seat) => seat.playerId === model.wolf);
  return (
    <Herboriste model={model} setModel={setModel} victim={victim?.name ?? "personne"} />
  );
}

function Herboriste({
  model,
  setModel,
  victim,
}: {
  model: Model;
  setModel: (model: Model) => void;
  victim: string;
}) {
  const [poison, setPoison] = useState<string | null>(null);
  const [save, setSave] = useState(false);
  const live = model.seats.filter((seat) => seat.alive);
  return (
    <div>
      <h2 className="font-display text-3xl">Les fioles</h2>
      <p className="mt-2 text-muted">
        {model.wolf ? `La meute vise ${victim}.` : "La meute n'a désigné personne."}
      </p>
      {model.wolf && !model.saveUsed && (
        <Button className="mt-3" variant={save ? "rose" : "line"} onClick={() => setSave((value) => !value)}>
          {save ? "Rosée versée : la proie est sauvée" : "Verser la rosée et sauver la proie"}
        </Button>
      )}
      {!model.poisonUsed && (
        <>
          <p className="mt-4 text-sm font-extrabold">Fiole d'ombre, une seule fois</p>
          <Choices
            options={live.map(face)}
            selected={poison}
            onPick={(id) => setPoison((current) => (current === id ? null : id))}
          />
        </>
      )}
      <Button
        className="mt-4"
        onClick={() => setModel(finishStep({ ...model, save: Boolean(model.wolf) && save, poison }))}
      >
        Refermer l'officine
      </Button>
    </div>
  );
}

function Vote({ model, setModel }: { model: Model; setModel: (model: Model) => void }) {
  const phase = model.phase;
  if (phase.t !== "vote") return null;
  const live = model.seats.filter((seat) => seat.alive);
  const voter = live[phase.i];
  if (!voter) return null;
  return (
    <div>
      <p className="text-sm font-extrabold text-gold">Bulletin secret</p>
      <h2 className="font-display text-3xl">{voter.name} vote</h2>
      <p className="mt-2 text-sm text-muted">Les autres ne regardent pas.</p>
      <Choices
        options={live.map(face)}
        onPick={(id) => {
          const ballots = { ...phase.ballots, [voter.playerId]: id };
          const next = phase.i + 1;
          if (next < live.length) {
            setModel({ ...model, phase: { t: "vote", i: next, ballots } });
            return;
          }
          const tally = new Map<string, number>();
          for (const target of Object.values(ballots)) tally.set(target, (tally.get(target) ?? 0) + 1);
          let best = 0;
          let leaders: string[] = [];
          for (const [idKey, count] of tally) {
            if (count > best) {
              best = count;
              leaders = [idKey];
            } else if (count === best) leaders.push(idKey);
          }
          if (leaders.length !== 1) {
            setModel(openNight(withLog({ ...model, night: model.night + 1 }, "Votes partagés : personne ne sort.")));
            return;
          }
          const fallen = model.seats.find((seat) => seat.playerId === leaders[0])?.name ?? "";
          setModel(killAndContinue(model, [leaders[0]!], "night", `${fallen} est banni par la cour.`));
        }}
      />
    </div>
  );
}

function Cover({
  title,
  text,
  action,
  onNext,
}: {
  title: string;
  text: string;
  action: string;
  onNext: () => void;
}) {
  return (
    <div>
      <h2 className="font-display text-4xl">{title}</h2>
      <p className="mt-2 max-w-md text-muted">{text}</p>
      <Button className="mt-4" onClick={onNext}>
        {action}
      </Button>
    </div>
  );
}

function Choices({
  options,
  onPick,
  disabled,
  selected,
}: {
  options: { id: string; name: string; photo?: string }[];
  onPick: (id: string) => void;
  disabled?: (id: string) => boolean;
  selected?: string | null;
}) {
  return (
    <div className="mt-4 grid grid-cols-2 gap-2">
      {options.map((option) => {
        const off = disabled?.(option.id) ?? false;
        const on = selected === option.id;
        return (
          <button
            key={option.id}
            type="button"
            disabled={off}
            onClick={() => onPick(option.id)}
            className={`flex min-h-11 items-center gap-2 rounded-2xl border px-2 py-2 text-left font-extrabold disabled:opacity-40 ${on ? "border-gold bg-gold-soft" : "border-line bg-parchment"}`}
          >
            <Portrait name={option.name} photo={option.photo} className="size-10 text-sm" />
            <span className="truncate">{option.name}</span>
          </button>
        );
      })}
    </div>
  );
}
