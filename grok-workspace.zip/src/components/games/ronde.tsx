import { Crown, Flower2, Moon, Sparkles, type LucideIcon } from "lucide-react";
import { useState } from "react";
import { Button, Panel, PaperCard, Portrait, PrintBar, type Mode } from "@/components/ui";
import { cn } from "@/lib/cn";
import { useParty, type Player } from "@/lib/party-store";
import { shuffle } from "@/lib/shuffle";

type Suit = "rose" | "lune" | "etoile" | "couronne";
type RCard = { id: string; suit: Suit; rank: number };

const SUITS: { id: Suit; label: string; icon: LucideIcon }[] = [
  { id: "rose", label: "Rose", icon: Flower2 },
  { id: "lune", label: "Lune", icon: Moon },
  { id: "etoile", label: "Étoile", icon: Sparkles },
  { id: "couronne", label: "Couronne", icon: Crown },
];

const TARGET = 21;

function freshDeck(): RCard[] {
  const cards: RCard[] = [];
  for (const suit of SUITS) {
    for (let rank = 1; rank <= 7; rank += 1) cards.push({ id: `${suit.id}-${rank}`, suit: suit.id, rank });
  }
  return shuffle(cards);
}

function legal(card: RCard, top: RCard | null) {
  if (!top) return true;
  return card.suit === top.suit || card.rank === top.rank;
}

type Seat = { id: string; name: string; photo?: string };
type Model = {
  seats: Seat[];
  hands: RCard[][];
  deck: RCard[];
  top: RCard | null;
  turn: number;
  scores: number[];
  pending: RCard | null;
  note: string;
  over: boolean;
  halted: boolean;
};

function deal(players: Player[], scores?: number[]): Model {
  const seats = players.slice(0, 4).map((player) => ({
    id: player.id,
    name: player.name.trim() || "Invité",
    photo: player.photo,
  }));
  const deck = freshDeck();
  const hands = seats.map(() => deck.splice(0, 5));
  let turn = 0;
  seats.forEach((_, index) => {
    if (hands[index]?.some((card) => card.suit === "couronne" && card.rank === 7)) turn = index;
  });
  return {
    seats,
    hands,
    deck,
    top: null,
    turn,
    scores: scores ?? seats.map(() => 0),
    pending: null,
    note: `${seats[turn]?.name ?? "Quelqu'un"} ouvre la ronde.`,
    over: false,
    halted: false,
  };
}

export function Ronde({ mode }: { mode: Mode }) {
  const players = useParty((state) => state.players);
  const [model, setModel] = useState<Model | null>(null);
  const table = players.slice(0, 4);

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        {players.length < 2 ? (
          <Panel>
            <p className="font-display text-2xl">Deux blasons au moins.</p>
            <p className="mt-2 text-muted">Ajoutez un visage dans l'atelier. Au-delà de quatre, les quatre premiers jouent.</p>
          </Panel>
        ) : !model ? (
          <Panel>
            <h2 className="font-display text-3xl">Posez le blason qui répond</h2>
            <p className="mt-2 text-muted">
              Même fleur ou même chiffre que la carte du milieu. Sinon, une seule pioche. Vider sa main rapporte les
              chiffres qui restent aux autres. On joue jusqu'à {TARGET}.
            </p>
            <Button className="mt-4" onClick={() => setModel(deal(table))}>
              Distribuer
            </Button>
          </Panel>
        ) : (
          <Table model={model} setModel={setModel} onReset={() => setModel(null)} source={table} />
        )}
      </div>
      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>Vingt-huit cartes. Imprimez-les deux fois si vous voulez un dos illustré à coller : le dos est en bas de page.</PrintBar>
        <div className="sheet-grid">
          {SUITS.flatMap((suit) =>
            Array.from({ length: 7 }, (_, index) => (
              <Face key={`${suit.id}-${index + 1}`} card={{ id: `${suit.id}-${index + 1}`, suit: suit.id, rank: index + 1 }} />
            )),
          )}
        </div>
        <h2 className="mt-8 font-display text-2xl">Dos</h2>
        <div className="sheet-grid mt-3">
          {Array.from({ length: 8 }, (_, index) => (
            <article key={index} className="sheet-card flex flex-col items-center justify-center rounded-2xl border border-gold bg-gold-soft">
              <Crown className="size-8 text-gold" aria-hidden="true" />
              <p className="mt-2 font-display text-xl">Ronde</p>
            </article>
          ))}
        </div>
      </div>
      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>Quatre blasons, chiffres de 1 à 7. On pose une carte du même blason ou du même chiffre.</p>
            <p>Si rien ne va, on pioche une carte. Si elle va, on peut la poser ou la garder. Sinon le tour passe.</p>
            <p>Le premier sans carte marque la somme des chiffres encore en main. Première personne à {TARGET} points.</p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Table({
  model,
  setModel,
  onReset,
  source,
}: {
  model: Model;
  setModel: (model: Model) => void;
  onReset: () => void;
  source: Player[];
}) {
  const seat = model.seats[model.turn];
  const hand = model.hands[model.turn] ?? [];

  function finishIfEmpty(next: Model, who: number): Model {
    if ((next.hands[who] ?? []).length > 0) return next;
    const gained = next.hands.reduce((sum, cards, index) => {
      if (index === who) return sum;
      return sum + cards.reduce((inner, card) => inner + card.rank, 0);
    }, 0);
    const scores = next.scores.map((score, index) => (index === who ? score + gained : score));
    const name = next.seats[who]?.name ?? "";
    const over = scores[who]! >= TARGET;
    return {
      ...next,
      scores,
      over,
      note: over
        ? `${name} vide sa main, marque ${gained} et atteint ${scores[who]}.`
        : `${name} vide sa main et marque ${gained}.`,
    };
  }

  function play(card: RCard, fromPending = false) {
    if (!legal(card, model.top)) return;
    const hands = model.hands.map((cards, index) =>
      index === model.turn ? cards.filter((item) => item.id !== card.id) : cards,
    );
    const emptied = (hands[model.turn] ?? []).length === 0;
    const drafted: Model = {
      ...model,
      hands,
      top: card,
      pending: null,
      turn: emptied ? model.turn : (model.turn + 1) % model.seats.length,
      halted: emptied,
      note: `${seat?.name} pose ${label(card)}.`,
    };
    setModel(emptied ? finishIfEmpty(drafted, model.turn) : drafted);
  }

  function draw() {
    if (model.deck.length === 0) {
      setModel({
        ...model,
        turn: (model.turn + 1) % model.seats.length,
        note: `${seat?.name} ne peut rien poser. La pioche est vide.`,
      });
      return;
    }
    const [card, ...rest] = model.deck;
    if (!card) return;
    if (legal(card, model.top)) {
      setModel({ ...model, deck: rest, pending: card, note: `${seat?.name} pioche ${label(card)}.` });
      return;
    }
    const hands = model.hands.map((cards, index) => (index === model.turn ? [...cards, card] : cards));
    setModel({
      ...model,
      hands,
      deck: rest,
      turn: (model.turn + 1) % model.seats.length,
      note: `${seat?.name} pioche ${label(card)}, qui ne se pose pas.`,
    });
  }

  const canAny = hand.some((card) => legal(card, model.top));

  return (
    <div className="grid gap-4 lg:grid-cols-[1.3fr_0.7fr]">
      <Panel>
        <p className="text-sm text-muted">{model.note}</p>
        <div className="mt-4 flex justify-center">
          {model.top ? <Mini card={model.top} /> : <p className="text-muted">Le centre est libre.</p>}
        </div>
        {model.over ? (
          <Button className="mt-4" variant="line" onClick={onReset}>
            Nouvelle partie
          </Button>
        ) : model.halted ? (
          <Button className="mt-4" onClick={() => setModel(deal(source, model.scores))}>
            Donner à nouveau
          </Button>
        ) : model.pending ? (
          <div className="mt-4">
            <p className="font-extrabold">Carte piochée : {label(model.pending)}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button onClick={() => play(model.pending!, true)}>La poser</Button>
              <Button
                variant="line"
                onClick={() => {
                  const hands = model.hands.map((cards, index) =>
                    index === model.turn && model.pending ? [...cards, model.pending] : cards,
                  );
                  setModel({
                    ...model,
                    hands,
                    pending: null,
                    turn: (model.turn + 1) % model.seats.length,
                    note: `${seat?.name} garde la pioche.`,
                  });
                }}
              >
                La garder
              </Button>
            </div>
          </div>
        ) : (
          <>
            <h2 className="mt-4 font-display text-3xl">{seat?.name}</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {hand.map((card) => {
                const ok = legal(card, model.top);
                return (
                  <button key={card.id} type="button" disabled={!ok} onClick={() => play(card)} className="disabled:opacity-35">
                    <Mini card={card} mute={!ok} />
                  </button>
                );
              })}
            </div>
            {!canAny && (
              <Button className="mt-4" variant="rose" onClick={draw}>
                Piocher
              </Button>
            )}
          </>
        )}
      </Panel>
      <Panel>
        <h2 className="font-display text-2xl">Blasons</h2>
        <ul className="mt-3 space-y-2">
          {model.seats.map((item, index) => (
            <li key={item.id} className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 font-extrabold">
                <Portrait name={item.name} photo={item.photo} className="size-8 text-sm" />
                {item.name}
              </span>
              <span>
                {model.scores[index]} · {model.hands[index]?.length ?? 0} cartes
              </span>
            </li>
          ))}
        </ul>
        <Button className="mt-4" variant="ghost" onClick={onReset}>
          Quitter la ronde
        </Button>
      </Panel>
    </div>
  );
}

function label(card: RCard) {
  const suit = SUITS.find((item) => item.id === card.suit);
  return `${suit?.label ?? ""} ${card.rank}`;
}

function Mini({ card, mute }: { card: RCard; mute?: boolean }) {
  const suit = SUITS.find((item) => item.id === card.suit);
  const Icon = suit?.icon ?? Crown;
  return (
    <span
      className={cn(
        "flex h-24 w-16 flex-col items-center justify-center rounded-2xl border bg-cream",
        mute ? "border-line" : "border-gold",
      )}
    >
      <Icon className="size-5 text-gold" aria-hidden="true" />
      <span className="font-display text-2xl">{card.rank}</span>
      <span className="text-xs font-extrabold">{suit?.label}</span>
    </span>
  );
}

function Face({ card }: { card: RCard }) {
  const suit = SUITS.find((item) => item.id === card.suit);
  const Icon = suit?.icon ?? Crown;
  return (
    <PaperCard>
      <p className="text-xs font-extrabold text-gold">Ronde des Blasons</p>
      <div className="flex flex-1 flex-col items-center justify-center">
        <Icon className="size-8 text-rose" aria-hidden="true" />
        <p className="font-display text-5xl">{card.rank}</p>
        <p className="font-extrabold">{suit?.label}</p>
      </div>
    </PaperCard>
  );
}
