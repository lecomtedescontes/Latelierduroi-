import { useState } from "react";
import { Button, Die, Panel, Portrait, PrintBar, type Mode } from "@/components/ui";
import { cn } from "@/lib/cn";
import { useParty, type Player } from "@/lib/party-store";

const LINKS: Record<number, { to: number; up: boolean }> = {
  3: { to: 16, up: true },
  8: { to: 22, up: true },
  19: { to: 31, up: true },
  28: { to: 37, up: true },
  14: { to: 5, up: false },
  24: { to: 11, up: false },
  33: { to: 20, up: false },
  39: { to: 26, up: false },
};

type Pawn = { id: string; name: string; photo?: string; pos: number };

function squareAt(row: number, col: number) {
  const fromBottom = 4 - row;
  const index = fromBottom * 8 + (fromBottom % 2 === 0 ? col : 7 - col);
  return index + 1;
}

function hop(from: number, roll: number) {
  const land = Math.min(40, from + roll);
  if (land >= 40) return { pos: 40, note: "atteint le sommet" };
  const link = LINKS[land];
  if (!link) return { pos: land, note: `s'arrête sur la marche ${land}` };
  if (link.up) return { pos: link.to, note: `grimpe l'escalier ${land} → ${link.to}` };
  return { pos: link.to, note: `glisse sur le ruban ${land} → ${link.to}` };
}

export function Tour({ mode }: { mode: Mode }) {
  const players = useParty((state) => state.players);
  const [pawns, setPawns] = useState<Pawn[] | null>(null);
  const [turn, setTurn] = useState(0);
  const [die, setDie] = useState<number | null>(null);
  const [note, setNote] = useState("Le premier en haut de la tour gagne. Pas besoin de la marche exacte.");
  const [winner, setWinner] = useState<string | null>(null);

  function begin(source: Player[]) {
    setPawns(source.map((player) => ({ id: player.id, name: player.name.trim() || "Invité", photo: player.photo, pos: 0 })));
    setTurn(0);
    setDie(null);
    setWinner(null);
    setNote("Tout le monde est au pied de la tour.");
  }

  function roll() {
    if (!pawns || winner) return;
    const value = 1 + Math.floor(Math.random() * 6);
    const pawn = pawns[turn];
    if (!pawn) return;
    const moved = hop(pawn.pos, value);
    const next = pawns.map((item, index) => (index === turn ? { ...item, pos: moved.pos } : item));
    setDie(value);
    setPawns(next);
    if (moved.pos >= 40) {
      setWinner(pawn.id);
      setNote(`${pawn.name} fait ${value} et ${moved.note}.`);
      return;
    }
    setNote(`${pawn.name} fait ${value} et ${moved.note}.`);
    setTurn((turn + 1) % next.length);
  }

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        {!pawns ? (
          <Panel>
            <h2 className="font-display text-3xl">Quarante marches</h2>
            <p className="mt-2 text-muted">
              Les escaliers montent d'un bond. Les rubans roses redescendent. Les pions sont vos portraits.
            </p>
            <Button className="mt-4" onClick={() => begin(players)} disabled={players.length < 2}>
              Poser les pions
            </Button>
            {players.length < 2 && <p className="mt-3 text-sm text-muted">Deux visages au moins.</p>}
          </Panel>
        ) : (
          <div className="grid gap-4 lg:grid-cols-[1.4fr_0.6fr]">
            <Board pawns={pawns} />
            <Panel>
              {die ? <Die value={die} /> : null}
              <p className="mt-3 leading-relaxed">{note}</p>
              {winner ? (
                <p className="mt-3 font-display text-3xl">
                  {pawns.find((pawn) => pawn.id === winner)?.name} couronne la tour.
                </p>
              ) : (
                <p className="mt-3 font-extrabold">Au pied du dé : {pawns[turn]?.name}</p>
              )}
              <div className="mt-4 flex flex-wrap gap-2">
                <Button onClick={roll} disabled={Boolean(winner)}>
                  Lancer le dé
                </Button>
                <Button variant="line" onClick={() => begin(players)}>
                  Recommencer
                </Button>
              </div>
              <ul className="mt-4 space-y-2">
                {pawns.map((pawn) => (
                  <li key={pawn.id} className="flex items-center gap-2 text-sm font-extrabold">
                    <Portrait name={pawn.name} photo={pawn.photo} className="size-8 text-sm" />
                    {pawn.name}
                    <span className="text-muted">{pawn.pos === 0 ? "départ" : `marche ${pawn.pos}`}</span>
                  </li>
                ))}
              </ul>
            </Panel>
          </div>
        )}
      </div>
      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>Plateau à suivre du bas vers le haut, en serpentin. Découpez les pions ronds.</PrintBar>
        <Board pawns={players.map((player) => ({ id: player.id, name: player.name, photo: player.photo, pos: -1 }))} />
        <div className="mt-4 flex flex-wrap gap-3">
          {players.map((player) => (
            <div key={player.id} className="avoid-break flex w-24 flex-col items-center">
              <Portrait name={player.name} photo={player.photo} className="size-16 text-xl" />
              <p className="mt-1 text-center text-sm font-extrabold">{player.name}</p>
            </div>
          ))}
        </div>
      </div>
      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>On lance un dé et l'on avance d'autant de marches, en partant du bas à gauche.</p>
            <p>Une marche dorée avec une flèche monte plus haut. Une marche rose redescend. Le premier à atteindre ou dépasser 40 gagne.</p>
            <p>
              Escaliers : 3→16, 8→22, 19→31, 28→37. Rubans : 14→5, 24→11, 33→20, 39→26.
            </p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Board({ pawns }: { pawns: Pawn[] }) {
  return (
    <div className="grid grid-cols-8 gap-1">
      {Array.from({ length: 5 }, (_, row) =>
        Array.from({ length: 8 }, (_, col) => {
          const n = squareAt(row, col);
          const link = LINKS[n];
          const here = pawns.filter((pawn) => pawn.pos === n);
          return (
            <div
              key={`${row}-${col}`}
              className={cn(
                "flex min-h-14 flex-col justify-between rounded-xl border p-1",
                link?.up ? "border-gold bg-gold-soft" : link ? "border-rose bg-rose-soft" : "border-line bg-cream",
              )}
            >
              <span className="text-xs font-extrabold">{n}</span>
              {link ? (
                <span className={cn("text-xs font-extrabold", link.up ? "text-gold" : "text-rose")}>
                  {link.up ? "↑" : "↓"} {link.to}
                </span>
              ) : (
                <span />
              )}
              <span className="flex flex-wrap gap-0.5">
                {here.map((pawn) => (
                  <Portrait key={pawn.id} name={pawn.name} photo={pawn.photo} className="size-5 text-xs" />
                ))}
              </span>
            </div>
          );
        }),
      )}
    </div>
  );
}
