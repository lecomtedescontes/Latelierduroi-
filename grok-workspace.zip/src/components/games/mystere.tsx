import { useMemo, useState } from "react";
import { Button, Frame, LogList, NeedPlayers, Panel, PaperCard, Portrait, PrintBar, type Mode } from "@/components/ui";
import { cn } from "@/lib/cn";
import { useParty, type Player } from "@/lib/party-store";
import { shuffle } from "@/lib/shuffle";

const ROOMS = [
  ["orangerie", "Orangerie"],
  ["bibliotheque", "Bibliothèque"],
  ["salon", "Salon de thé"],
  ["tour", "Tour du nord"],
  ["galerie", "Galerie des miroirs"],
  ["office", "Office d'argent"],
  ["jardin", "Jardin secret"],
  ["ambre", "Chambre d'ambre"],
  ["trone", "Salle du trône"],
] as const;

const RELICS = [
  ["epingle", "Épingle de perle"],
  ["flute", "Flûte d'or"],
  ["ruban", "Ruban de soie"],
  ["cle", "Clé ancienne"],
  ["coupe", "Coupe de cristal"],
  ["eventail", "Éventail peint"],
] as const;

const GUESTS = [
  { id: "g-brume", name: "Marquis de Brume" },
  { id: "g-paquerette", name: "Dame Pâquerette" },
  { id: "g-lino", name: "Page Lino" },
  { id: "g-oriole", name: "Cantatrice Oriole" },
];

type Kind = "suspect" | "room" | "relic";

type Card = { id: string; kind: Kind; name: string; photo?: string };

type Suggestion = { suspect: string; room: string; relic: string };

type Phase =
  | { t: "turn" }
  | { t: "cover"; cursor: number; suggestion: Suggestion }
  | { t: "refute"; cursor: number; suggestion: Suggestion }
  | { t: "show"; from: number; cardId: string; suggestion: Suggestion }
  | { t: "accuse"; suggestion: Suggestion }
  | { t: "end"; winnerId?: string };

type Model = {
  cards: Card[];
  solution: Suggestion;
  hands: Record<string, string[]>;
  out: Record<string, boolean>;
  turn: number;
  phase: Phase;
  log: string[];
  notes: Record<string, Record<string, number>>;
  peek: boolean;
  book: boolean;
  draft: Suggestion;
};

function build(players: Player[]): Model {
  const suspects: Card[] = players.map((player) => ({
    id: player.id,
    kind: "suspect",
    name: player.name.trim() || "Invité",
    photo: player.photo,
  }));
  for (const guest of GUESTS) {
    if (suspects.length >= 5) break;
    suspects.push({ id: guest.id, kind: "suspect", name: guest.name });
  }
  const rooms: Card[] = ROOMS.map(([id, name]) => ({ id, kind: "room", name }));
  const relics: Card[] = RELICS.map(([id, name]) => ({ id, kind: "relic", name }));
  const solution: Suggestion = {
    suspect: shuffle(suspects)[0]!.id,
    room: shuffle(rooms)[0]!.id,
    relic: shuffle(relics)[0]!.id,
  };
  const deck = shuffle([
    ...suspects.filter((card) => card.id !== solution.suspect),
    ...rooms.filter((card) => card.id !== solution.room),
    ...relics.filter((card) => card.id !== solution.relic),
  ]);
  const hands: Record<string, string[]> = {};
  for (const player of players) hands[player.id] = [];
  deck.forEach((card, index) => {
    hands[players[index % players.length]!.id]!.push(card.id);
  });
  return {
    cards: [...suspects, ...rooms, ...relics],
    solution,
    hands,
    out: {},
    turn: 0,
    phase: { t: "turn" },
    log: ["Le secret est sous trois sceaux. À vous le carnet."],
    notes: {},
    peek: false,
    book: false,
    draft: { suspect: suspects[0]!.id, room: rooms[0]!.id, relic: relics[0]!.id },
  };
}

function nameOf(cards: Card[], id: string) {
  return cards.find((card) => card.id === id)?.name ?? "—";
}

function matches(card: Card, suggestion: Suggestion) {
  return (
    (card.kind === "suspect" && card.id === suggestion.suspect) ||
    (card.kind === "room" && card.id === suggestion.room) ||
    (card.kind === "relic" && card.id === suggestion.relic)
  );
}

export function Mystere({ mode }: { mode: Mode }) {
  const players = useParty((state) => state.players);
  const [model, setModel] = useState<Model | null>(null);
  const cast = useMemo(() => {
    const list: Card[] = players.map((player) => ({
      id: player.id,
      kind: "suspect",
      name: player.name.trim() || "Invité",
      photo: player.photo,
    }));
    for (const guest of GUESTS) {
      if (list.length >= 5) break;
      list.push({ id: guest.id, kind: "suspect", name: guest.name });
    }
    return list;
  }, [players]);

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        <NeedPlayers min={2} count={players.length}>
          {!model ? (
            <Panel>
              <h2 className="font-display text-3xl">Trois sceaux</h2>
              <p className="mt-2 text-muted">
                Un visage, une salle, une relique ont été retirés. Suggérez, faites-vous montrer une carte, puis
                accusez quand le carnet est sûr.
              </p>
              <Button className="mt-4" onClick={() => setModel(build(players))}>
                Sceller le mystère
              </Button>
            </Panel>
          ) : (
            <Board model={model} setModel={setModel} players={players} onReset={() => setModel(null)} />
          )}
        </NeedPlayers>
      </div>
      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>Suspects de la maison, salles du palais, reliques et carnet à cocher.</PrintBar>
        <h2 className="font-display text-2xl">Visages</h2>
        <div className="sheet-grid mt-3">
          {cast.map((card) => (
            <PaperCard key={card.id}>
              <p className="text-xs font-extrabold text-gold">Suspect</p>
              <Frame name={card.name} photo={card.photo} className="mx-auto h-28 w-24 text-3xl" />
              <h3 className="text-center font-display text-2xl leading-tight">{card.name}</h3>
            </PaperCard>
          ))}
        </div>
        <h2 className="mt-8 font-display text-2xl">Salles</h2>
        <div className="sheet-grid mt-3">
          {ROOMS.map(([id, name]) => (
            <PaperCard key={id}>
              <p className="text-xs font-extrabold text-gold">Salle</p>
              <h3 className="font-display text-3xl leading-tight">{name}</h3>
              <p className="text-xs text-muted">Mystère au Palais</p>
            </PaperCard>
          ))}
        </div>
        <h2 className="mt-8 font-display text-2xl">Reliques</h2>
        <div className="sheet-grid mt-3">
          {RELICS.map(([id, name]) => (
            <PaperCard key={id}>
              <p className="text-xs font-extrabold text-rose">Relique</p>
              <h3 className="font-display text-3xl leading-tight">{name}</h3>
              <p className="text-xs text-muted">À montrer, jamais à nommer tout haut.</p>
            </PaperCard>
          ))}
        </div>
      </div>
      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>On retire un suspect, une salle et une relique : c'est la solution. Le reste est distribué.</p>
            <p>À votre tour, suggérez les trois. Chaque autre joueur, dans l'ordre, doit montrer une carte correspondante s'il en a une. Sinon il passe. Une seule carte est montrée, puis le tour passe.</p>
            <p>Accuser est définitif. Juste : vous gagnez. Faux : vous ne suggérez plus, mais vous pouvez encore montrer une carte.</p>
            <p>S'il manque des joueurs pour cinq suspects, la cour invite des hôtes illustrés, sans portrait.</p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function Board({
  model,
  setModel,
  players,
  onReset,
}: {
  model: Model;
  setModel: (model: Model) => void;
  players: Player[];
  onReset: () => void;
}) {
  const byId = new Map(model.cards.map((card) => [card.id, card]));
  const active = players.filter((player) => !model.out[player.id]);
  const player = players[model.turn];
  if (!player) return null;

  function nextTurn(from: number, logLine: string) {
    let turn = from;
    for (let step = 0; step < players.length; step += 1) {
      turn = (turn + 1) % players.length;
      if (!model.out[players[turn]!.id]) break;
    }
    setModel({
      ...model,
      turn,
      peek: false,
      book: false,
      phase: { t: "turn" },
      log: [logLine, ...model.log].slice(0, 8),
    });
  }

  function startRefute(suggestion: Suggestion) {
    const cursor = (model.turn + 1) % players.length;
    const line = `${player!.name} suggère ${nameOf(model.cards, suggestion.suspect)}, ${nameOf(model.cards, suggestion.room)}, ${nameOf(model.cards, suggestion.relic)}.`;
    if (players.length < 2) return;
    setModel({
      ...model,
      peek: false,
      phase: { t: "cover", cursor, suggestion },
      log: [line, ...model.log].slice(0, 8),
    });
  }

  const suggestionLabel = (suggestion: Suggestion) =>
    `${nameOf(model.cards, suggestion.suspect)} · ${nameOf(model.cards, suggestion.room)} · ${nameOf(model.cards, suggestion.relic)}`;

  return (
    <div className="grid gap-4 lg:grid-cols-[1.3fr_0.7fr]">
      <Panel>
        {model.phase.t === "end" ? (
          <div>
            <h2 className="font-display text-4xl">
              {players.find((item) => item.id === (model.phase.t === "end" ? model.phase.winnerId : undefined))
                ?.name ?? "La cour s'est perdue"}
            </h2>
            <EndText model={model} players={players} />
            <Button className="mt-4" variant="line" onClick={onReset}>
              Nouvelle enquête
            </Button>
          </div>
        ) : model.phase.t === "cover" ? (
          <div>
            <h2 className="font-display text-3xl">Passez à {players[model.phase.cursor]?.name}</h2>
            <p className="mt-2 text-muted">Suggestion : {suggestionLabel(model.phase.suggestion)}</p>
            <Button
              className="mt-4"
              onClick={() =>
                setModel({
                  ...model,
                  phase: {
                    t: "refute",
                    cursor: model.phase.t === "cover" ? model.phase.cursor : 0,
                    suggestion: model.phase.t === "cover" ? model.phase.suggestion : model.draft,
                  },
                })
              }
            >
              Je regarde ma main
            </Button>
          </div>
        ) : model.phase.t === "refute" ? (
          <Refute model={model} setModel={setModel} players={players} byId={byId} />
        ) : model.phase.t === "show" ? (
          <div>
            <h2 className="font-display text-3xl">Montrez ceci à {player.name}</h2>
            <Shown card={byId.get(model.phase.cardId)} />
            <Button
              className="mt-4"
              onClick={() => {
                const from = players[model.phase.t === "show" ? model.phase.from : 0]?.name ?? "";
                nextTurn(model.turn, `${from} a montré une carte à ${player.name}.`);
              }}
            >
              C'est vu
            </Button>
          </div>
        ) : model.phase.t === "accuse" ? (
          <div>
            <h2 className="font-display text-3xl">Accuser pour de bon ?</h2>
            <p className="mt-2">{suggestionLabel(model.phase.suggestion)}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                variant="rose"
                onClick={() => {
                  const suggestion = model.phase.t === "accuse" ? model.phase.suggestion : model.draft;
                  const right =
                    suggestion.suspect === model.solution.suspect &&
                    suggestion.room === model.solution.room &&
                    suggestion.relic === model.solution.relic;
                  if (right) {
                    setModel({
                      ...model,
                      phase: { t: "end", winnerId: player.id },
                      log: [`${player.name} perce le secret.`, ...model.log].slice(0, 8),
                    });
                    return;
                  }
                  const out = { ...model.out, [player.id]: true };
                  const still = players.some((item) => item.id !== player.id && !out[item.id]);
                  if (!still) {
                    setModel({
                      ...model,
                      out,
                      phase: { t: "end" },
                      log: [`${player.name} se trompe. Plus personne pour accuser.`, ...model.log].slice(0, 8),
                    });
                    return;
                  }
                  let turn = model.turn;
                  for (let step = 0; step < players.length; step += 1) {
                    turn = (turn + 1) % players.length;
                    if (!out[players[turn]!.id]) break;
                  }
                  setModel({
                    ...model,
                    out,
                    turn,
                    phase: { t: "turn" },
                    peek: false,
                    log: [`${player.name} accuse à faux et quitte l'enquête.`, ...model.log].slice(0, 8),
                  });
                }}
              >
                J'accuse
              </Button>
              <Button variant="line" onClick={() => setModel({ ...model, phase: { t: "turn" } })}>
                Revenir
              </Button>
            </div>
          </div>
        ) : (
          <Turn
            model={model}
            setModel={setModel}
            player={player}
            byId={byId}
            onSuggest={startRefute}
            activeCount={active.length}
          />
        )}
      </Panel>
      <Panel>
        <h2 className="font-display text-2xl">Chronique</h2>
        <LogList lines={model.log} />
        <p className="mt-4 text-sm text-muted">
          En jeu : {active.map((item) => item.name).join(", ") || "—"}
        </p>
        <Button className="mt-4" variant="ghost" onClick={onReset}>
          Ranger l'enquête
        </Button>
      </Panel>
    </div>
  );
}

function EndText({ model, players }: { model: Model; players: Player[] }) {
  if (model.phase.t !== "end") return null;
  const winnerId = model.phase.winnerId;
  const named = players.find((player) => player.id === winnerId);
  return (
    <div className="mt-2 text-muted">
      <p>
        {named ? `${named.name} avait raison.` : "Aucune accusation n'a trouvé les trois sceaux."}
      </p>
      <p className="mt-2">
        C'était {nameOf(model.cards, model.solution.suspect)}, dans {nameOf(model.cards, model.solution.room)}, avec{" "}
        {nameOf(model.cards, model.solution.relic)}.
      </p>
    </div>
  );
}

function Shown({ card }: { card: Card | undefined }) {
  if (!card) return null;
  return (
    <div className="mt-4 max-w-xs rounded-3xl border border-gold bg-gold-soft p-4">
      {card.photo && <Frame name={card.name} photo={card.photo} className="mb-3 h-28 w-full text-2xl" />}
      <p className="text-xs font-extrabold uppercase">{card.kind === "room" ? "Salle" : card.kind === "relic" ? "Relique" : "Suspect"}</p>
      <p className="font-display text-3xl leading-tight">{card.name}</p>
    </div>
  );
}

function Refute({
  model,
  setModel,
  players,
  byId,
}: {
  model: Model;
  setModel: (model: Model) => void;
  players: Player[];
  byId: Map<string, Card>;
}) {
  if (model.phase.t !== "refute") return null;
  const who = players[model.phase.cursor];
  if (!who) return null;
  const suggestion = model.phase.suggestion;
  const options = (model.hands[who.id] ?? [])
    .map((id) => byId.get(id))
    .filter((card): card is Card => Boolean(card && matches(card, suggestion)));

  function pass() {
    const cursor = model.phase.t === "refute" ? model.phase.cursor : 0;
    const next = (cursor + 1) % players.length;
    if (next === model.turn) {
      const asker = players[model.turn]?.name ?? "";
      setModel({
        ...model,
        phase: { t: "turn" },
        turn: nextPlayer(model.turn),
        peek: false,
        log: [`Personne ne répond à ${asker}.`, ...model.log].slice(0, 8),
      });
      return;
    }
    setModel({ ...model, phase: { t: "cover", cursor: next, suggestion } });
  }

  function nextPlayer(from: number) {
    let turn = from;
    for (let step = 0; step < players.length; step += 1) {
      turn = (turn + 1) % players.length;
      if (!model.out[players[turn]!.id]) return turn;
    }
    return from;
  }

  return (
    <div>
      <h2 className="font-display text-3xl">{who.name}</h2>
      <p className="mt-2 text-muted">
        {options.length
          ? "Vous devez montrer l'une de ces cartes, rien d'autre."
          : "Aucune de vos cartes ne répond. Passez l'écran."}
      </p>
      <div className="mt-4 grid gap-2">
        {options.map((card) => (
          <button
            key={card.id}
            type="button"
            className="min-h-11 rounded-2xl border border-line bg-parchment px-3 text-left font-extrabold"
            onClick={() =>
              setModel({
                ...model,
                phase: { t: "show", from: model.phase.t === "refute" ? model.phase.cursor : 0, cardId: card.id, suggestion },
              })
            }
          >
            {card.name}
          </button>
        ))}
      </div>
      {!options.length && (
        <Button className="mt-4" onClick={pass}>
          Je ne peux pas répondre
        </Button>
      )}
    </div>
  );
}

function Turn({
  model,
  setModel,
  player,
  byId,
  onSuggest,
  activeCount,
}: {
  model: Model;
  setModel: (model: Model) => void;
  player: Player;
  byId: Map<string, Card>;
  onSuggest: (suggestion: Suggestion) => void;
  activeCount: number;
}) {
  const hand = (model.hands[player.id] ?? []).map((id) => byId.get(id)).filter((card): card is Card => Boolean(card));
  const suspects = model.cards.filter((card) => card.kind === "suspect");
  const rooms = model.cards.filter((card) => card.kind === "room");
  const relics = model.cards.filter((card) => card.kind === "relic");
  const notes = model.notes[player.id] ?? {};

  function cycle(id: string) {
    const current = notes[id] ?? 0;
    setModel({
      ...model,
      notes: { ...model.notes, [player.id]: { ...notes, [id]: (current + 1) % 3 } },
    });
  }

  return (
    <div>
      <div className="flex items-center gap-3">
        <Portrait name={player.name} photo={player.photo} className="size-12 text-lg" />
        <div>
          <p className="text-sm font-extrabold text-gold">Tour de piste</p>
          <h2 className="font-display text-3xl">{player.name}</h2>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button variant="line" size="sm" onClick={() => setModel({ ...model, peek: !model.peek, book: false })}>
          {model.peek ? "Cacher ma main" : "Voir ma main"}
        </Button>
        <Button variant="line" size="sm" onClick={() => setModel({ ...model, book: !model.book, peek: false })}>
          {model.book ? "Fermer le carnet" : "Mon carnet"}
        </Button>
      </div>
      {model.peek && (
        <ul className="mt-3 flex flex-wrap gap-2">
          {hand.map((card) => (
            <li key={card.id} className="rounded-full bg-gold-soft px-3 py-2 text-sm font-extrabold">
              {card.name}
            </li>
          ))}
        </ul>
      )}
      {model.book && (
        <div className="mt-3 grid gap-1">
          {model.cards.map((card) => {
            const mark = notes[card.id] ?? 0;
            const label = mark === 1 ? "écarté" : mark === 2 ? "à suivre" : "vierge";
            return (
              <button
                key={card.id}
                type="button"
                onClick={() => cycle(card.id)}
                className="flex min-h-11 items-center justify-between rounded-xl px-2 text-left text-sm hover:bg-parchment"
              >
                <span>{card.name}</span>
                <span className={cn("font-extrabold", mark === 1 ? "text-muted" : mark === 2 ? "text-rose" : "text-gold")}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      )}
      <fieldset className="mt-4 grid gap-3 sm:grid-cols-3">
        <Select
          label="Visage"
          value={model.draft.suspect}
          options={suspects}
          onChange={(suspect) => setModel({ ...model, draft: { ...model.draft, suspect } })}
        />
        <Select
          label="Salle"
          value={model.draft.room}
          options={rooms}
          onChange={(room) => setModel({ ...model, draft: { ...model.draft, room } })}
        />
        <Select
          label="Relique"
          value={model.draft.relic}
          options={relics}
          onChange={(relic) => setModel({ ...model, draft: { ...model.draft, relic } })}
        />
      </fieldset>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button onClick={() => onSuggest(model.draft)}>Suggérer</Button>
        <Button
          variant="rose"
          disabled={activeCount < 1}
          onClick={() => setModel({ ...model, phase: { t: "accuse", suggestion: model.draft } })}
        >
          Accuser
        </Button>
      </div>
    </div>
  );
}

function Select({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: Card[];
  onChange: (id: string) => void;
}) {
  return (
    <label className="block text-sm font-extrabold">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-1 min-h-11 w-full rounded-2xl border border-line bg-parchment px-2 font-semibold"
      >
        {options.map((card) => (
          <option key={card.id} value={card.id}>
            {card.name}
          </option>
        ))}
      </select>
    </label>
  );
}
