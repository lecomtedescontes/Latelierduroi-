import { BookOpen, Crown, Feather, Flower2, Gem, KeyRound, Moon, Music, Sparkles, Sun, type LucideIcon } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button, Frame, NeedPlayers, Panel, PaperCard, Portrait, PrintBar, type Mode } from "@/components/ui";
import { useParty } from "@/lib/party-store";
import { shuffle, uid } from "@/lib/shuffle";

const MOTIFS: { id: string; label: string; icon: LucideIcon }[] = [
  { id: "couronne", label: "Couronne", icon: Crown },
  { id: "rose", label: "Rose", icon: Flower2 },
  { id: "lune", label: "Lune", icon: Moon },
  { id: "etoile", label: "Étoile", icon: Sparkles },
  { id: "cle", label: "Clé", icon: KeyRound },
  { id: "flute", label: "Flûte", icon: Music },
  { id: "soleil", label: "Soleil", icon: Sun },
  { id: "livre", label: "Livre", icon: BookOpen },
  { id: "plume", label: "Plume", icon: Feather },
  { id: "gemme", label: "Gemme", icon: Gem },
];

type MemoCard = {
  uid: string;
  pairId: string;
  label: string;
  photo?: string;
  icon?: LucideIcon;
};

function makeDeck(players: { id: string; name: string; photo?: string }[]): MemoCard[] {
  const chosen = [
    ...players.map((player) => ({
      pairId: player.id,
      label: player.name.trim() || "Invité",
      photo: player.photo,
      icon: undefined as LucideIcon | undefined,
    })),
    ...MOTIFS.map((motif) => ({
      pairId: motif.id,
      label: motif.label,
      photo: undefined,
      icon: motif.icon,
    })),
  ].slice(0, Math.max(6, Math.min(10, Math.max(players.length + 2, 6))));
  return shuffle(
    chosen.flatMap((face) => [
      { ...face, uid: uid() },
      { ...face, uid: uid() },
    ]),
  );
}

export function Memoire({ mode }: { mode: Mode }) {
  const players = useParty((state) => state.players);
  const [cards, setCards] = useState<MemoCard[]>([]);
  const [found, setFound] = useState<string[]>([]);
  const [up, setUp] = useState<string[]>([]);
  const [turn, setTurn] = useState(0);
  const [scores, setScores] = useState<number[]>([]);
  const [lock, setLock] = useState(false);
  const [sheet, setSheet] = useState<MemoCard[]>([]);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    setSheet(makeDeck(players));
  }, [players]);

  useEffect(() => () => {
    if (timer.current) window.clearTimeout(timer.current);
  }, []);

  function deal() {
    if (timer.current) window.clearTimeout(timer.current);
    setCards(makeDeck(players));
    setFound([]);
    setUp([]);
    setTurn(0);
    setScores(players.map(() => 0));
    setLock(false);
  }

  const started = cards.length > 0;
  const pairs = cards.length / 2;
  const done = started && found.length === pairs;
  const roster = players.map((player) => ({ ...player, name: player.name.trim() || "Invité" }));

  function pick(card: MemoCard) {
    if (!started || done || lock || found.includes(card.pairId) || up.includes(card.uid)) return;
    if (up.length === 0) {
      setUp([card.uid]);
      return;
    }
    const first = cards.find((item) => item.uid === up[0]);
    if (!first) return;
    if (first.pairId === card.pairId) {
      setFound((current) => [...current, card.pairId]);
      setScores((current) => current.map((score, index) => (index === turn ? score + 1 : score)));
      setUp([]);
      return;
    }
    setUp([first.uid, card.uid]);
    setLock(true);
    timer.current = window.setTimeout(() => {
      setUp([]);
      setTurn((value) => (value + 1) % players.length);
      setLock(false);
    }, 800);
  }

  return (
    <>
      <div className={mode === "jouer" ? "print:hidden" : "hidden print:hidden"}>
        <NeedPlayers min={1} count={players.length}>
          {!started ? (
            <Panel>
              <h2 className="font-display text-3xl">Médaillons face cachée</h2>
              <p className="mt-2 text-muted">
                Retournez-en deux. Une paire reste ouverte et vous rejouez. Sinon, l'écran passe au suivant.
              </p>
              <Button className="mt-4" onClick={deal}>
                Disposer les cartes
              </Button>
            </Panel>
          ) : (
            <Panel>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="font-extrabold">
                  {done ? "Toutes les paires sont ouvertes." : `Au tour de ${roster[turn]?.name ?? ""}`}
                </p>
                <Button variant="line" size="sm" onClick={deal}>
                  Rebattre
                </Button>
              </div>
              <ul className="mt-3 flex flex-wrap gap-2">
                {roster.map((player, index) => (
                  <li
                    key={player.id}
                    className={`flex items-center gap-2 rounded-full py-1 pr-3 pl-1 ${index === turn && !done ? "bg-gold-soft" : "bg-parchment"}`}
                  >
                    <Portrait name={player.name} photo={player.photo} className="size-8 text-sm" />
                    <span className="text-sm font-extrabold">
                      {player.name} · {scores[index] ?? 0}
                    </span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
                {cards.map((card) => {
                  const open = up.includes(card.uid) || found.includes(card.pairId);
                  const Icon = card.icon;
                  return (
                    <button
                      key={card.uid}
                      type="button"
                      onClick={() => pick(card)}
                      className="flex aspect-[3/4] flex-col items-center justify-center rounded-2xl border border-gold bg-cream p-2"
                      aria-label={open ? card.label : "Carte face cachée"}
                    >
                      {open ? (
                        <>
                          {card.photo ? (
                            <Frame name={card.label} photo={card.photo} className="h-16 w-14 text-xl" />
                          ) : Icon ? (
                            <Icon className="size-8 text-gold" aria-hidden="true" />
                          ) : null}
                          <span className="mt-2 text-center text-xs font-extrabold">{card.label}</span>
                        </>
                      ) : (
                        <Crown className="size-6 text-gold" aria-hidden="true" />
                      )}
                    </button>
                  );
                })}
              </div>
              {done && (
                <p className="mt-4 font-display text-2xl">
                  {winnerLine(roster.map((player) => player.name), scores)}
                </p>
              )}
            </Panel>
          )}
        </NeedPlayers>
      </div>
      <div className={mode === "imprimer" ? "" : "hidden"}>
        <PrintBar>Deux cartes identiques par visage et par symbole. Découpez, mélangez face cachée.</PrintBar>
        <div className="sheet-grid">
          {sheet.map((card) => {
            const Icon = card.icon;
            return (
              <PaperCard key={card.uid}>
                <p className="text-xs font-extrabold text-gold">Mémoire d'Or</p>
                <div className="flex flex-1 flex-col items-center justify-center gap-2">
                  {card.photo ? (
                    <Frame name={card.label} photo={card.photo} className="h-24 w-20 text-2xl" />
                  ) : Icon ? (
                    <Icon className="size-10 text-gold" aria-hidden="true" />
                  ) : null}
                  <h3 className="text-center font-display text-2xl">{card.label}</h3>
                </div>
              </PaperCard>
            );
          })}
        </div>
      </div>
      <div className={mode === "regles" ? "print:hidden" : "hidden"}>
        <Panel>
          <div className="space-y-3 text-muted">
            <p>On retourne deux cartes. Si elles vont ensemble, elles restent ouvertes et l'on rejoue.</p>
            <p>Sinon on les referme et le voisin joue. À la fin, le plus de paires l'emporte. À un seul joueur, on joue contre la table.</p>
          </div>
        </Panel>
      </div>
    </>
  );
}

function winnerLine(names: string[], scores: number[]) {
  const best = Math.max(0, ...scores);
  const leaders = names.filter((_, index) => scores[index] === best);
  if (leaders.length === 1) return `${leaders[0]} a la mémoire la plus dorée.`;
  return `Égalité entre ${leaders.join(" et ")}.`;
}
