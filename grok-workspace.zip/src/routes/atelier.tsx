import { createFileRoute } from "@tanstack/react-router";
import { ImagePlus, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { Shell } from "@/components/shell";
import { Button, Portrait, buttonClass } from "@/components/ui";
import { fileToPortrait } from "@/lib/portrait-file";
import { useParty } from "@/lib/party-store";

export const Route = createFileRoute("/atelier")({ component: Atelier });

function Atelier() {
  const houseName = useParty((state) => state.houseName);
  const players = useParty((state) => state.players);
  const notice = useParty((state) => state.notice);
  const setHouseName = useParty((state) => state.setHouseName);
  const addPlayer = useParty((state) => state.addPlayer);
  const updatePlayer = useParty((state) => state.updatePlayer);
  const removePlayer = useParty((state) => state.removePlayer);
  const clearNotice = useParty((state) => state.clearNotice);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [localError, setLocalError] = useState("");

  async function onPhoto(id: string, file: File | undefined) {
    if (!file) return;
    setLocalError("");
    clearNotice();
    setBusyId(id);
    try {
      const photo = await fileToPortrait(file);
      updatePlayer(id, { photo });
    } catch {
      setLocalError("Cette image ne s'ouvre pas. Essayez un autre portrait.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <Shell>
      <p className="text-sm font-extrabold tracking-wide text-gold">Atelier des visages</p>
      <h1 className="mt-2 font-display text-4xl leading-tight sm:text-5xl">Composez la maison</h1>
      <p className="mt-3 max-w-2xl text-muted">
        Ces prénoms et ces portraits habillent tous les jeux : suspects, médaillons, pions, dos de cartes.
        Tout reste dans le navigateur de cet appareil.
      </p>

      <label className="mt-8 block max-w-md">
        <span className="text-sm font-extrabold">Nom de la maison</span>
        <input
          value={houseName}
          maxLength={42}
          onChange={(event) => setHouseName(event.target.value)}
          className="mt-2 min-h-11 w-full rounded-2xl border border-line bg-cream px-4 text-ink"
        />
      </label>

      {(notice || localError) && (
        <p className="mt-4 max-w-xl rounded-2xl bg-rose-soft px-4 py-3 text-sm text-ink" role="status">
          {localError || notice}
        </p>
      )}

      <ul className="mt-6 grid gap-3 sm:grid-cols-2">
        {players.map((player) => (
          <li key={player.id} className="flex gap-3 rounded-3xl border border-line bg-cream p-3">
            <Portrait name={player.name} photo={player.photo} className="size-16 text-xl" />
            <div className="min-w-0 flex-1">
              <label className="block">
                <span className="sr-only">Prénom</span>
                <input
                  value={player.name}
                  maxLength={18}
                  onChange={(event) => updatePlayer(player.id, { name: event.target.value })}
                  className="min-h-11 w-full rounded-2xl border border-line bg-parchment px-3 font-extrabold"
                />
              </label>
              <div className="mt-2 flex flex-wrap gap-2">
                <label className={buttonClass({ variant: "line", size: "sm" })}>
                  <ImagePlus className="size-4" aria-hidden="true" />
                  {busyId === player.id ? "Ouverture…" : player.photo ? "Changer" : "Portrait"}
                  <input
                    type="file"
                    accept="image/*"
                    className="sr-only"
                    onChange={(event) => {
                      const file = event.target.files?.[0];
                      void onPhoto(player.id, file);
                      event.target.value = "";
                    }}
                  />
                </label>
                {player.photo && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => updatePlayer(player.id, { photo: undefined })}
                  >
                    Retirer
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removePlayer(player.id)}
                  disabled={players.length < 2}
                >
                  <Trash2 className="size-4" aria-hidden="true" />
                  Sortir
                </Button>
              </div>
            </div>
          </li>
        ))}
      </ul>

      <Button className="mt-4" variant="rose" onClick={addPlayer} disabled={players.length >= 10}>
        <Plus className="size-4" aria-hidden="true" />
        Ajouter un visage
      </Button>
      <p className="mt-3 text-sm text-muted">Jusqu'à dix. Une photo nette, visage centré : elle sera recadrée en médaillon.</p>
    </Shell>
  );
}
