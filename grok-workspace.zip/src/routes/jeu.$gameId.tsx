import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useState } from "react";
import { Domaine } from "@/components/games/domaine";
import { Eclats } from "@/components/games/eclats";
import { Memoire } from "@/components/games/memoire";
import { Minuit } from "@/components/games/minuit";
import { Mystere } from "@/components/games/mystere";
import { Phrases } from "@/components/games/phrases";
import { Ronde } from "@/components/games/ronde";
import { Tour } from "@/components/games/tour";
import { Shell } from "@/components/shell";
import type { Mode } from "@/components/ui";
import { cn } from "@/lib/cn";
import { findGame, type GameId } from "@/lib/games";
import { useParty } from "@/lib/party-store";

export const Route = createFileRoute("/jeu/$gameId")({ component: GamePage });

const VIEWS: Record<GameId, (props: { mode: Mode }) => React.ReactNode> = {
  minuit: Minuit,
  mystere: Mystere,
  phrases: Phrases,
  domaine: Domaine,
  memoire: Memoire,
  tour: Tour,
  eclats: Eclats,
  ronde: Ronde,
};

function GamePage() {
  const { gameId } = Route.useParams();
  const game = findGame(gameId);
  const houseName = useParty((state) => state.houseName);
  const [mode, setMode] = useState<Mode>("jouer");

  if (!game) {
    return (
      <Shell>
        <h1 className="font-display text-4xl">Ce jeu n'est pas dans le coffret.</h1>
        <Link to="/" className="mt-4 inline-flex min-h-11 items-center font-extrabold text-gold">
          Retour au salon
        </Link>
      </Shell>
    );
  }

  const View = VIEWS[game.id];
  const tabs: { id: Mode; label: string }[] = [
    { id: "jouer", label: "Jouer" },
    { id: "imprimer", label: "Imprimer" },
    { id: "regles", label: "Règles" },
  ];

  return (
    <Shell>
      <Link to="/" className="inline-flex min-h-11 items-center gap-2 text-sm font-extrabold print:hidden">
        <ArrowLeft className="size-4" aria-hidden="true" />
        Salon
      </Link>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-extrabold text-gold">
            Édition · {houseName} · {game.players} · {game.time}
          </p>
          <h1 className="mt-1 font-display text-4xl leading-tight sm:text-5xl">{game.title}</h1>
          <p className="mt-2 max-w-2xl text-muted">{game.pitch}</p>
        </div>
        <div className="inline-flex rounded-full bg-gold-soft p-1 print:hidden" role="tablist">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={mode === tab.id}
              onClick={() => setMode(tab.id)}
              className={cn(
                "min-h-11 rounded-full px-4 text-sm font-extrabold",
                mode === tab.id ? "bg-cream text-ink shadow-sm" : "text-ink/70",
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
      <div className="mt-6">
        <View mode={mode} />
      </div>
    </Shell>
  );
}
