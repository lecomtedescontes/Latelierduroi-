import { createFileRoute, Link } from "@tanstack/react-router";
import { ImagePlus, Printer, TabletSmartphone } from "lucide-react";
import { Shell } from "@/components/shell";
import { Portrait, buttonClass } from "@/components/ui";
import { cn } from "@/lib/cn";
import { GAMES } from "@/lib/games";
import { useParty } from "@/lib/party-store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const houseName = useParty((state) => state.houseName);
  const players = useParty((state) => state.players);

  return (
    <Shell>
      <section className="grid items-center gap-8 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <p className="text-sm font-extrabold tracking-wide text-gold">Maison de jeux à offrir</p>
          <h1 className="mt-2 font-display text-4xl leading-tight text-ink sm:text-6xl">
            Des jeux de cour
            <span className="block text-rose">à leur visage.</span>
          </h1>
          <p className="mt-4 max-w-xl text-lg leading-relaxed text-muted">
            Huit jeux originaux. Chacun existe deux fois : une table numérique que l'on se passe de main en
            main, et des planches à imprimer où les portraits de {houseName} se fondent dans les cartes.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/atelier" className={buttonClass()}>
              Composer la maison
            </Link>
            <a href="#jeux" className={buttonClass({ variant: "line" })}>
              Choisir un jeu
            </a>
          </div>
          <ul className="mt-8 flex flex-wrap gap-2">
            {players.map((player) => (
              <li key={player.id} className="flex items-center gap-2 rounded-full border border-line bg-cream py-1 pr-3 pl-1">
                <Portrait name={player.name} photo={player.photo} className="size-9 text-sm" />
                <span className="text-sm font-extrabold">{player.name}</span>
              </li>
            ))}
          </ul>
        </div>
        <figure className="overflow-hidden rounded-3xl border border-line bg-cream shadow-md">
          <img
            src="/og.jpg"
            alt="Affiche de l'atelier : couronne d'or, trois cartes et un ruban rose"
            className="aspect-video w-full object-cover"
          />
          <figcaption className="px-4 py-3 text-sm text-muted">
            L'édition de la maison se prépare ici, puis se joue ou s'imprime.
          </figcaption>
        </figure>
      </section>

      <section className="mt-12 grid gap-3 sm:grid-cols-3">
        {[
          { icon: ImagePlus, title: "Les portraits", text: "Un prénom, une photo. Le médaillon sert à tous les jeux." },
          { icon: TabletSmartphone, title: "La table", text: "Passez l'écran. Les secrets ne s'ouvrent que pour le bon visage." },
          { icon: Printer, title: "Les planches", text: "Cartes, titres et plateaux prêts à découper, au nom de la maison." },
        ].map((step) => (
          <article key={step.title} className="rounded-3xl border border-line bg-cream p-4">
            <step.icon className="size-5 text-gold" aria-hidden="true" />
            <h2 className="mt-3 font-display text-2xl">{step.title}</h2>
            <p className="mt-1 text-sm leading-relaxed text-muted">{step.text}</p>
          </article>
        ))}
      </section>

      <section id="jeux" className="mt-14 scroll-mt-6">
        <h2 className="font-display text-3xl sm:text-4xl">Le coffret</h2>
        <p className="mt-2 max-w-2xl text-muted">
          Règles écrites pour cette maison, sans emprunter le nom d'un grand classique. Chaque jeu ouvre son
          atelier : jouer, imprimer, relire.
        </p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {GAMES.map((game, index) => {
            const Icon = game.icon;
            return (
              <Link
                key={game.id}
                to="/jeu/$gameId"
                params={{ gameId: game.id }}
                className="group flex gap-4 rounded-3xl border border-line bg-cream p-4 shadow-sm transition duration-200 hover:border-gold"
              >
                <span className="font-display text-2xl text-gold">{String(index + 1).padStart(2, "0")}</span>
                <span className="min-w-0">
                  <span className="flex items-center gap-2">
                    <Icon className="size-4 text-rose" aria-hidden="true" />
                    <span className="font-display text-2xl leading-tight">{game.title}</span>
                  </span>
                  <span className="mt-1 block text-sm leading-relaxed text-muted">{game.pitch}</span>
                  <span className="mt-3 flex flex-wrap gap-2 text-xs font-extrabold text-ink">
                    <span className="rounded-full bg-gold-soft px-2 py-1">{game.players}</span>
                    <span className="rounded-full bg-rose-soft px-2 py-1">{game.time}</span>
                    <span className={cn("rounded-full px-2 py-1 text-gold group-hover:underline")}>
                      Ouvrir l'édition
                    </span>
                  </span>
                </span>
              </Link>
            );
          })}
        </div>
      </section>
    </Shell>
  );
}
