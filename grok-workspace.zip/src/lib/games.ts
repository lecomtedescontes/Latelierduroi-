import type { LucideIcon } from "lucide-react";
import {
  Castle,
  Feather,
  Gem,
  Layers,
  Moon,
  Search,
  Sparkles,
  TowerControl,
} from "lucide-react";

export type GameId =
  | "minuit"
  | "mystere"
  | "phrases"
  | "domaine"
  | "memoire"
  | "tour"
  | "eclats"
  | "ronde";

export type GameInfo = {
  id: GameId;
  title: string;
  pitch: string;
  players: string;
  time: string;
  icon: LucideIcon;
};

export const GAMES: GameInfo[] = [
  {
    id: "minuit",
    title: "Minuit au Château",
    pitch: "Les yeux se ferment. Les loups de velours choisissent, la cour vote au matin.",
    players: "4 à 8",
    time: "25 min",
    icon: Moon,
  },
  {
    id: "mystere",
    title: "Mystère au Palais",
    pitch: "Un visage, une salle, une relique. Retrouvez le secret avant la cour.",
    players: "2 à 6",
    time: "30 min",
    icon: Search,
  },
  {
    id: "phrases",
    title: "Phrases de Soie",
    pitch: "Une phrase trouée, des réponses chuchotées, un juge qui couronne la plus belle.",
    players: "3 à 8",
    time: "20 min",
    icon: Feather,
  },
  {
    id: "domaine",
    title: "Le Grand Domaine",
    pitch: "Achetez vergers, tours et salons. Dorez-les. Le trésor aime les audacieux.",
    players: "2 à 6",
    time: "25 min",
    icon: Castle,
  },
  {
    id: "memoire",
    title: "Mémoire d'Or",
    pitch: "Retournez les médaillons. Les paires de visages et de symboles rapportent la mise.",
    players: "1 à 6",
    time: "10 min",
    icon: Layers,
  },
  {
    id: "tour",
    title: "La Tour Enchantée",
    pitch: "Escaliers de soie et rubans glissants. Le premier en haut de la tour l'emporte.",
    players: "2 à 6",
    time: "15 min",
    icon: TowerControl,
  },
  {
    id: "eclats",
    title: "Éclats de Conte",
    pitch: "Une phrase, des images, des votes. Le conte juste est celui que la table reconnaît.",
    players: "3 à 8",
    time: "25 min",
    icon: Sparkles,
  },
  {
    id: "ronde",
    title: "La Ronde des Blasons",
    pitch: "Rose, lune, étoile ou couronne : posez le blason qui répond, videz votre main.",
    players: "2 à 4",
    time: "15 min",
    icon: Gem,
  },
];

export function findGame(id: string): GameInfo | undefined {
  return GAMES.find((game) => game.id === id);
}
