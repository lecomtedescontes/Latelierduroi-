import { create } from "zustand";
import { uid } from "@/lib/shuffle";

export type Player = {
  id: string;
  name: string;
  photo?: string;
};

type Saved = {
  houseName: string;
  players: Player[];
};

type PartyState = Saved & {
  notice: string;
  hydrate: () => void;
  setHouseName: (name: string) => void;
  addPlayer: () => void;
  updatePlayer: (id: string, patch: Partial<Pick<Player, "name" | "photo">>) => void;
  removePlayer: (id: string) => void;
  clearNotice: () => void;
};

const KEY = "atelier-petit-roi-v1";

function defaults(): Saved {
  return {
    houseName: "La maison des étoiles",
    players: [
      { id: "lea", name: "Léa" },
      { id: "sacha", name: "Sacha" },
      { id: "ines", name: "Inès" },
      { id: "noe", name: "Noé" },
    ],
  };
}

function persist(data: Saved): string {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
    return "";
  } catch {
    return "Le portrait est trop lourd pour rester en mémoire sur cet appareil.";
  }
}

export const useParty = create<PartyState>((set, get) => ({
  ...defaults(),
  notice: "",
  hydrate: () => {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as Partial<Saved>;
      if (!parsed.players?.length) return;
      const players = parsed.players.filter(
        (player) => player && typeof player.id === "string" && typeof player.name === "string",
      );
      if (!players.length) return;
      set({
        houseName:
          typeof parsed.houseName === "string" && parsed.houseName.trim()
            ? parsed.houseName
            : defaults().houseName,
        players,
      });
    } catch {
      /* garde la maison d'exemple */
    }
  },
  setHouseName: (houseName) => {
    const players = get().players;
    set({ houseName, notice: persist({ houseName, players }) });
  },
  addPlayer: () => {
    const players = [...get().players, { id: uid(), name: "Invité" }];
    if (players.length > 10) return;
    const houseName = get().houseName;
    set({ players, notice: persist({ houseName, players }) });
  },
  updatePlayer: (id, patch) => {
    const players = get().players.map((player) =>
      player.id === id ? { ...player, ...patch } : player,
    );
    const houseName = get().houseName;
    set({ players, notice: persist({ houseName, players }) });
  },
  removePlayer: (id) => {
    const players = get().players.filter((player) => player.id !== id);
    if (!players.length) return;
    const houseName = get().houseName;
    set({ players, notice: persist({ houseName, players }) });
  },
  clearNotice: () => set({ notice: "" }),
}));
