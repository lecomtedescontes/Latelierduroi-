import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Plus, m as ImagePlus, n as Trash2 } from "../_libs/lucide-react.mjs";
import { c as Portrait, d as buttonClass, h as useParty, t as Button, u as Shell } from "./ui-91VX8Rel.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/atelier-CzJnmVmf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function fileToPortrait(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			const side = 360;
			const canvas = document.createElement("canvas");
			canvas.width = side;
			canvas.height = side;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			const scale = Math.max(side / img.width, side / img.height);
			const width = img.width * scale;
			const height = img.height * scale;
			ctx.drawImage(img, (side - width) / 2, (side - height) / 2, width, height);
			URL.revokeObjectURL(url);
			resolve(canvas.toDataURL("image/jpeg", .72));
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("image"));
		};
		img.src = url;
	});
}
function Atelier() {
	const houseName = useParty((state) => state.houseName);
	const players = useParty((state) => state.players);
	const notice = useParty((state) => state.notice);
	const setHouseName = useParty((state) => state.setHouseName);
	const addPlayer = useParty((state) => state.addPlayer);
	const updatePlayer = useParty((state) => state.updatePlayer);
	const removePlayer = useParty((state) => state.removePlayer);
	const clearNotice = useParty((state) => state.clearNotice);
	const [busyId, setBusyId] = (0, import_react.useState)(null);
	const [localError, setLocalError] = (0, import_react.useState)("");
	async function onPhoto(id, file) {
		if (!file) return;
		setLocalError("");
		clearNotice();
		setBusyId(id);
		try {
			const photo = await fileToPortrait(file);
			updatePlayer(id, { photo });
		} catch {
			setLocalError("Cette image ne s'ouvre pas. Essayez un autre portrait.");
		} finally {
			setBusyId(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-extrabold tracking-wide text-gold",
			children: "Atelier des visages"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl leading-tight sm:text-5xl",
			children: "Composez la maison"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-muted",
			children: "Ces prénoms et ces portraits habillent tous les jeux : suspects, médaillons, pions, dos de cartes. Tout reste dans le navigateur de cet appareil."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-8 block max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-extrabold",
				children: "Nom de la maison"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: houseName,
				maxLength: 42,
				onChange: (event) => setHouseName(event.target.value),
				className: "mt-2 min-h-11 w-full rounded-2xl border border-line bg-cream px-4 text-ink"
			})]
		}),
		(notice || localError) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-xl rounded-2xl bg-rose-soft px-4 py-3 text-sm text-ink",
			role: "status",
			children: localError || notice
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 grid gap-3 sm:grid-cols-2",
			children: players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3 rounded-3xl border border-line bg-cream p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					name: player.name,
					photo: player.photo,
					className: "size-16 text-xl"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Prénom"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: player.name,
							maxLength: 18,
							onChange: (event) => updatePlayer(player.id, { name: event.target.value }),
							className: "min-h-11 w-full rounded-2xl border border-line bg-parchment px-3 font-extrabold"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: buttonClass({
									variant: "line",
									size: "sm"
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									busyId === player.id ? "Ouverture…" : player.photo ? "Changer" : "Portrait",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										className: "sr-only",
										onChange: (event) => {
											const file = event.target.files?.[0];
											onPhoto(player.id, file);
											event.target.value = "";
										}
									})
								]
							}),
							player.photo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => updatePlayer(player.id, { photo: void 0 }),
								children: "Retirer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => removePlayer(player.id),
								disabled: players.length < 2,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Sortir"]
							})
						]
					})]
				})]
			}, player.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			className: "mt-4",
			variant: "rose",
			onClick: addPlayer,
			disabled: players.length >= 10,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
				className: "size-4",
				"aria-hidden": "true"
			}), "Ajouter un visage"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "Jusqu'à dix. Une photo nette, visage centré : elle sera recadrée en médaillon."
		})
	] });
}
//#endregion
export { Atelier as component };
