import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Printer, i as TabletSmartphone, m as ImagePlus } from "../_libs/lucide-react.mjs";
import { c as Portrait, d as buttonClass, f as cn, h as useParty, u as Shell } from "./ui-91VX8Rel.mjs";
import { t as GAMES } from "./games-CWwe_HIO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CORR6LBF.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const houseName = useParty((state) => state.houseName);
	const players = useParty((state) => state.players);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid items-center gap-8 lg:grid-cols-[1.05fr_0.95fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-extrabold tracking-wide text-gold",
					children: "Maison de jeux à offrir"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-2 font-display text-4xl leading-tight text-ink sm:text-6xl",
					children: ["Des jeux de cour", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-rose",
						children: "à leur visage."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 max-w-xl text-lg leading-relaxed text-muted",
					children: [
						"Huit jeux originaux. Chacun existe deux fois : une table numérique que l'on se passe de main en main, et des planches à imprimer où les portraits de ",
						houseName,
						" se fondent dans les cartes."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/atelier",
						className: buttonClass(),
						children: "Composer la maison"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#jeux",
						className: buttonClass({ variant: "line" }),
						children: "Choisir un jeu"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 flex flex-wrap gap-2",
					children: players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2 rounded-full border border-line bg-cream py-1 pr-3 pl-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: player.name,
							photo: player.photo,
							className: "size-9 text-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-extrabold",
							children: player.name
						})]
					}, player.id))
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "overflow-hidden rounded-3xl border border-line bg-cream shadow-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/og.jpg",
					alt: "Affiche de l'atelier : couronne d'or, trois cartes et un ruban rose",
					className: "aspect-video w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
					className: "px-4 py-3 text-sm text-muted",
					children: "L'édition de la maison se prépare ici, puis se joue ou s'imprime."
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mt-12 grid gap-3 sm:grid-cols-3",
			children: [
				{
					icon: ImagePlus,
					title: "Les portraits",
					text: "Un prénom, une photo. Le médaillon sert à tous les jeux."
				},
				{
					icon: TabletSmartphone,
					title: "La table",
					text: "Passez l'écran. Les secrets ne s'ouvrent que pour le bon visage."
				},
				{
					icon: Printer,
					title: "Les planches",
					text: "Cartes, titres et plateaux prêts à découper, au nom de la maison."
				}
			].map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-3xl border border-line bg-cream p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(step.icon, {
						className: "size-5 text-gold",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-2xl",
						children: step.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-muted",
						children: step.text
					})
				]
			}, step.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "jeux",
			className: "mt-14 scroll-mt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl sm:text-4xl",
					children: "Le coffret"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: "Règles écrites pour cette maison, sans emprunter le nom d'un grand classique. Chaque jeu ouvre son atelier : jouer, imprimer, relire."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-2",
					children: GAMES.map((game, index) => {
						const Icon = game.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/jeu/$gameId",
							params: { gameId: game.id },
							className: "group flex gap-4 rounded-3xl border border-line bg-cream p-4 shadow-sm transition duration-200 hover:border-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl text-gold",
								children: String(index + 1).padStart(2, "0")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-4 text-rose",
											"aria-hidden": "true"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-2xl leading-tight",
											children: game.title
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-sm leading-relaxed text-muted",
										children: game.pitch
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-3 flex flex-wrap gap-2 text-xs font-extrabold text-ink",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-gold-soft px-2 py-1",
												children: game.players
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-rose-soft px-2 py-1",
												children: game.time
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn("rounded-full px-2 py-1 text-gold group-hover:underline"),
												children: "Ouvrir l'édition"
											})
										]
									})
								]
							})]
						}, game.id);
					})
				})
			]
		})
	] });
}
//#endregion
export { Home as component };
