import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Feather, a as Sun, b as BookOpen, d as Moon, g as Flower2, h as Gem, o as Sparkles, p as KeyRound, u as Music, v as Crown, x as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as NeedPlayers, c as Portrait, f as cn, h as useParty, i as LogList, l as PrintBar, m as uid, n as Die, o as Panel, p as shuffle, r as Frame, s as PaperCard, t as Button, u as Shell } from "./ui-91VX8Rel.mjs";
import { n as Route } from "./router-Dhha8f4o.mjs";
import { n as findGame } from "./games-CWwe_HIO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jeu._gameId-DrEvXOG0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SPACES = [
	{
		t: "gate",
		name: "Porte d'or"
	},
	{
		t: "estate",
		name: "Verger",
		price: 60,
		rent: 8
	},
	{
		t: "edict",
		name: "Édit"
	},
	{
		t: "estate",
		name: "Rubans",
		price: 70,
		rent: 10
	},
	{
		t: "tax",
		name: "Cygnes",
		amount: 20
	},
	{
		t: "estate",
		name: "Hiboux",
		price: 90,
		rent: 14
	},
	{
		t: "estate",
		name: "Porcelaine",
		price: 100,
		rent: 14
	},
	{
		t: "rest",
		name: "Sieste"
	},
	{
		t: "estate",
		name: "Galerie",
		price: 120,
		rent: 18
	},
	{
		t: "edict",
		name: "Édit"
	},
	{
		t: "estate",
		name: "Cuisine",
		price: 130,
		rent: 20
	},
	{
		t: "estate",
		name: "Orangerie",
		price: 140,
		rent: 22
	},
	{
		t: "tax",
		name: "Bal",
		amount: 30
	},
	{
		t: "estate",
		name: "Ambre",
		price: 160,
		rent: 24
	},
	{
		t: "estate",
		name: "Livres",
		price: 180,
		rent: 28
	},
	{
		t: "estate",
		name: "Trône",
		price: 220,
		rent: 36
	}
];
var LAYOUT = [
	{
		k: "s",
		n: 0
	},
	{
		k: "s",
		n: 1
	},
	{
		k: "s",
		n: 2
	},
	{
		k: "s",
		n: 3
	},
	{
		k: "s",
		n: 4
	},
	{
		k: "s",
		n: 15
	},
	{ k: "c" },
	{
		k: "s",
		n: 5
	},
	{
		k: "s",
		n: 14
	},
	{
		k: "s",
		n: 6
	},
	{
		k: "s",
		n: 13
	},
	{
		k: "s",
		n: 7
	},
	{
		k: "s",
		n: 12
	},
	{
		k: "s",
		n: 11
	},
	{
		k: "s",
		n: 10
	},
	{
		k: "s",
		n: 9
	},
	{
		k: "s",
		n: 8
	}
];
var DEEDS = [
	{
		name: "Verger de miel",
		price: 60,
		rent: 8
	},
	{
		name: "Atelier des rubans",
		price: 70,
		rent: 10
	},
	{
		name: "Tour des hiboux",
		price: 90,
		rent: 14
	},
	{
		name: "Salon de porcelaine",
		price: 100,
		rent: 14
	},
	{
		name: "Galerie des miroirs",
		price: 120,
		rent: 18
	},
	{
		name: "Cuisine d'argent",
		price: 130,
		rent: 20
	},
	{
		name: "Orangerie",
		price: 140,
		rent: 22
	},
	{
		name: "Chambre d'ambre",
		price: 160,
		rent: 24
	},
	{
		name: "Bibliothèque",
		price: 180,
		rent: 28
	},
	{
		name: "Salle du trône",
		price: 220,
		rent: 36
	}
];
var PASS = 20;
var GILD = 50;
var WIN = 400;
var PURSE = 220;
function logName(model) {
	return model.pawns[model.turn]?.name ?? "";
}
function alive(model) {
	return model.pawns.filter((pawn) => !pawn.out);
}
function finish(model) {
	const rich = model.pawns.find((pawn) => !pawn.out && pawn.money >= WIN);
	if (rich) return {
		...model,
		phase: {
			t: "end",
			id: rich.id,
			reason: `${rich.name} atteint ${WIN} écus.`
		}
	};
	const left = alive(model);
	if (left.length <= 1 && left[0]) return {
		...model,
		phase: {
			t: "end",
			id: left[0].id,
			reason: `${left[0].name} reste seul dans le domaine.`
		}
	};
	return model;
}
function pay(model, fromId, amount, toId) {
	const pawns = model.pawns.map((pawn) => ({ ...pawn }));
	const from = pawns.find((pawn) => pawn.id === fromId);
	if (!from || from.out) return {
		model,
		broke: false
	};
	if (from.money >= amount) {
		from.money -= amount;
		if (toId) {
			const to = pawns.find((pawn) => pawn.id === toId);
			if (to) to.money += amount;
		}
		return {
			model: {
				...model,
				pawns
			},
			broke: false
		};
	}
	if (toId) {
		const to = pawns.find((pawn) => pawn.id === toId);
		if (to) to.money += from.money;
	}
	from.money = 0;
	from.out = true;
	const own = { ...model.own };
	for (const key of Object.keys(own)) {
		const index = Number(key);
		if (own[index]?.ownerId === fromId) delete own[index];
	}
	return {
		model: {
			...model,
			pawns,
			own
		},
		broke: true
	};
}
function give(model, amount, note) {
	const pawns = model.pawns.map((pawn, index) => index === model.turn ? {
		...pawn,
		money: pawn.money + amount
	} : pawn);
	return finish({
		...model,
		pawns,
		phase: { t: "note" },
		note
	});
}
function edict(model) {
	const roll = Math.floor(Math.random() * 6);
	if (roll === 0) return give(model, 25, `${logName(model)} reçoit 25 écus du trésor.`);
	if (roll === 1) return give(model, 40, `Un invité laisse 40 écus à ${logName(model)}.`);
	if (roll === 2) {
		const charged = pay(model, model.pawns[model.turn].id, 15, null);
		const note = charged.broke ? `${logName(model)} ne peut pas payer les lanternes et quitte la table.` : `${logName(model)} paie 15 écus pour les lanternes.`;
		return finish({
			...charged.model,
			phase: { t: "note" },
			note
		});
	}
	if (roll === 3) {
		let next = model;
		const others = model.pawns.filter((pawn) => !pawn.out && pawn.id !== model.pawns[model.turn]?.id);
		for (const other of others) next = pay(next, other.id, 10, model.pawns[model.turn].id).model;
		return finish({
			...next,
			phase: { t: "note" },
			note: `C'est la fête de ${logName(model)} : chacun donne 10 écus, s'il le peut.`
		});
	}
	if (roll === 4) {
		const ownerId = model.pawns[model.turn].id;
		const owned = Object.entries(model.own).filter(([, value]) => value.ownerId === ownerId && !value.gilded).map(([key]) => Number(key)).sort((a, b) => {
			const pa = SPACES[a];
			const pb = SPACES[b];
			return (pa?.t === "estate" ? pa.price : 0) - (pb?.t === "estate" ? pb.price : 0);
		});
		if (!owned.length) return {
			...model,
			phase: { t: "note" },
			note: "L'édit dore un domaine, mais vous n'en avez aucun de libre."
		};
		const index = owned[0];
		return {
			...model,
			own: {
				...model.own,
				[index]: {
					ownerId,
					gilded: true
				}
			},
			phase: { t: "note" },
			note: `${SPACES[index]?.name ?? "Un domaine"} est doré sans frais.`
		};
	}
	const charged = pay(model, model.pawns[model.turn].id, 20, null);
	return finish({
		...charged.model,
		phase: { t: "note" },
		note: charged.broke ? `${logName(model)} a oublié sa bourse et quitte la table.` : `${logName(model)} paie 20 écus : bourse oubliée.`
	});
}
function land(model, pos) {
	const stopped = finish(model);
	if (stopped.phase.t === "end") return stopped;
	const space = SPACES[pos];
	const pawn = model.pawns[model.turn];
	if (!space || !pawn) return model;
	if (space.t === "estate") {
		const owner = model.own[pos];
		if (!owner) return {
			...model,
			phase: {
				t: "buy",
				index: pos
			}
		};
		if (owner.ownerId === pawn.id) return {
			...model,
			phase: {
				t: "own",
				index: pos
			}
		};
		const holder = model.pawns.find((item) => item.id === owner.ownerId);
		const rent = space.rent * (owner.gilded ? 2 : 1);
		if (!holder || holder.out) return {
			...model,
			phase: {
				t: "buy",
				index: pos
			}
		};
		const charged = pay(model, pawn.id, rent, holder.id);
		return finish({
			...charged.model,
			phase: { t: "note" },
			note: charged.broke ? `${pawn.name} ne peut pas payer ${rent} écus et quitte la table.` : `${pawn.name} verse ${rent} écus à ${holder.name}.`
		});
	}
	if (space.t === "tax") {
		const charged = pay(model, pawn.id, space.amount, null);
		return finish({
			...charged.model,
			phase: { t: "note" },
			note: charged.broke ? `${pawn.name} ne paie pas ${space.name} et sort.` : `${pawn.name} paie ${space.amount} écus : ${space.name}.`
		});
	}
	if (space.t === "edict") return edict(model);
	if (space.t === "rest") return {
		...model,
		phase: { t: "note" },
		note: `${pawn.name} fait la sieste au jardin.`
	};
	return {
		...model,
		phase: { t: "note" },
		note: `${pawn.name} est à la Porte d'or.`
	};
}
function Domaine({ mode }) {
	const players = useParty((state) => state.players);
	const [model, setModel] = (0, import_react.useState)(null);
	function begin(source) {
		const pawns = source.slice(0, 6).map((player) => ({
			id: player.id,
			name: player.name.trim() || "Invité",
			photo: player.photo,
			pos: 0,
			money: PURSE,
			out: false
		}));
		setModel({
			pawns,
			own: {},
			turn: 0,
			phase: { t: "roll" },
			die: null,
			note: `Chacun reçoit ${PURSE} écus. Premier à ${WIN}, ou dernier debout.`
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: players.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "Il faut deux acquéreurs."
			}) }) : !model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Seize lieux, une bourse"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: ["Achetez, encaissez, dorez une fois pour doubler le loyer. Les édits de la cour bousculent les bourses.", players.length > 6 ? " Les six premiers de la maison jouent." : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					onClick: () => begin(players),
					children: "Ouvrir les portes"
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, {
				model,
				setModel,
				onReset: () => setModel(null)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Titres de propriété à signer du sceau de l'acheteur. Le plateau numérique reste la partie vivante." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sheet-grid",
				children: DEEDS.map((deed) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold text-gold",
						children: "Titre"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl leading-tight",
						children: deed.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"Prix ",
							deed.price,
							" · loyer ",
							deed.rent
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: ["Doré : loyer ", deed.rent * 2]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Sceau du propriétaire"
					})
				] }, deed.name))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Chaque joueur part avec ",
						PURSE,
						" écus, sur la Porte d'or. Un dé. Passer ou retomber sur la Porte rapporte ",
						PASS,
						" écus."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Un lieu libre s'achète. Chez un autre, on paie le loyer — double s'il est doré. Dorer coûte ",
						GILD,
						" écus, une fois."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Si l'on ne peut pas payer, on rend ses domaines à la cour et l'on sort. On gagne à ",
						WIN,
						" écus, ou en restant le dernier."
					] })
				]
			}) })
		})
	] });
}
function Match({ model, setModel, onReset }) {
	const pawn = model.pawns[model.turn];
	function nextTurn(base) {
		if (base.phase.t === "end") return base;
		let turn = base.turn;
		for (let step = 0; step < base.pawns.length; step += 1) {
			turn = (turn + 1) % base.pawns.length;
			if (!base.pawns[turn]?.out) break;
		}
		return {
			...base,
			turn,
			phase: { t: "roll" },
			die: null
		};
	}
	function onRoll() {
		if (!pawn || model.phase.t !== "roll") return;
		const die = 1 + Math.floor(Math.random() * 6);
		const sum = pawn.pos + die;
		const passed = sum >= SPACES.length;
		const pos = sum % SPACES.length;
		const pawns = model.pawns.map((item, index) => index === model.turn ? {
			...item,
			pos,
			money: item.money + (passed ? PASS : 0)
		} : item);
		const note = passed ? `${pawn.name} fait ${die}, touche ${PASS} à la Porte et s'arrête sur ${SPACES[pos]?.name}.` : `${pawn.name} fait ${die} et s'arrête sur ${SPACES[pos]?.name}.`;
		setModel(land({
			...model,
			pawns,
			die,
			note
		}, pos));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-5 gap-1",
			children: LAYOUT.map((cell, index) => {
				if (cell.k === "c") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "col-span-3 row-span-3 flex flex-col items-center justify-center rounded-3xl border border-line bg-gold-soft p-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl leading-tight sm:text-2xl",
							children: "Grand Domaine"
						}),
						model.die ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Die, { value: model.die })
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs font-extrabold",
							children: pawn && model.phase.t !== "end" ? pawn.name : "Fin"
						})
					]
				}, "center");
				const space = SPACES[cell.n];
				const owner = model.own[cell.n];
				const holder = model.pawns.find((item) => item.id === owner?.ownerId);
				const here = model.pawns.filter((item) => !item.out && item.pos === cell.n);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("flex min-h-16 flex-col justify-between rounded-xl border p-1", space.t === "edict" ? "border-rose bg-rose-soft" : space.t === "estate" ? "border-gold bg-cream" : "border-line bg-parchment"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-extrabold leading-tight",
						children: space.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center justify-between gap-1",
						children: [holder ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: holder.name,
							photo: holder.photo,
							className: "size-5 text-xs"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex",
							children: here.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
								name: item.name,
								photo: item.photo,
								className: "size-5 text-xs ring-1"
							}, item.id))
						})]
					})]
				}, `${cell.n}-${index}`);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: model.note }),
			model.phase.t === "end" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: model.phase.reason
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					variant: "line",
					onClick: onReset,
					children: "Rejouer"
				})]
			}) : model.phase.t === "roll" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-3",
				onClick: onRoll,
				children: "Lancer le dé"
			}) : model.phase.t === "buy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Buy, {
				model,
				setModel
			}) : model.phase.t === "own" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnPane, {
				model,
				setModel
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-3",
				onClick: () => setModel(nextTurn(model)),
				children: "Joueur suivant"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-2 sm:grid-cols-2",
				children: model.pawns.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("flex items-center justify-between gap-2 rounded-2xl px-2 py-1", item.out && "opacity-50"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 font-extrabold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: item.name,
							photo: item.photo,
							className: "size-8 text-sm"
						}), item.name]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: item.out ? "sorti" : `${item.money} écus`
					})]
				}, item.id))
			})
		] })]
	});
}
function Buy({ model, setModel }) {
	if (model.phase.t !== "buy") return null;
	const space = SPACES[model.phase.index];
	const pawn = model.pawns[model.turn];
	if (!space || space.t !== "estate" || !pawn) return null;
	const index = model.phase.index;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex flex-wrap gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			disabled: pawn.money < space.price,
			onClick: () => {
				const charged = pay(model, pawn.id, space.price, null);
				setModel({
					...charged.model,
					own: {
						...charged.model.own,
						[index]: {
							ownerId: pawn.id,
							gilded: false
						}
					},
					phase: { t: "note" },
					note: `${pawn.name} achète ${space.name} pour ${space.price} écus.`
				});
			},
			children: ["Acheter ", space.price]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "line",
			onClick: () => setModel({
				...model,
				phase: { t: "note" },
				note: `${pawn.name} laisse ${space.name}.`
			}),
			children: "Laisser"
		})]
	});
}
function OwnPane({ model, setModel }) {
	if (model.phase.t !== "own") return null;
	const space = SPACES[model.phase.index];
	const pawn = model.pawns[model.turn];
	const owner = model.own[model.phase.index];
	if (!space || space.t !== "estate" || !pawn || !owner) return null;
	const index = model.phase.index;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex flex-wrap gap-2",
		children: [!owner.gilded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			disabled: pawn.money < GILD,
			onClick: () => {
				const charged = pay(model, pawn.id, GILD, null);
				setModel({
					...charged.model,
					own: {
						...charged.model.own,
						[index]: {
							ownerId: pawn.id,
							gilded: true
						}
					},
					phase: { t: "note" },
					note: `${pawn.name} dore ${space.name}. Le loyer double.`
				});
			},
			children: [
				"Dorer (",
				GILD,
				")"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "line",
			onClick: () => setModel({
				...model,
				phase: { t: "note" },
				note: `${pawn.name} séjourne chez soi.`
			}),
			children: "Continuer"
		})]
	});
}
var MOTIFS$1 = [
	"Orage doré",
	"Thé de minuit",
	"Cheval de nuage",
	"Clé perdue",
	"Jardin mouillé",
	"Rire sous cape",
	"Navire de sucre",
	"Lanterne bleue",
	"Escalier sans fin",
	"Lettre jamais lue",
	"Chapeau trop grand",
	"Soupe aux étoiles"
];
var TITLES = [
	"Regard de fête",
	"Couronne de travers",
	"Secret du col",
	"Clair de lune",
	"Rire en or",
	"Pas de velours",
	"Étoile dans l'œil",
	"Manteau trop grand"
];
function deckFor(players) {
	const titles = shuffle(TITLES);
	const portraits = players.map((player, index) => ({
		id: `face-${player.id}`,
		title: titles[index % titles.length] ?? "Portrait",
		photo: player.photo,
		who: player.name
	}));
	const motifs = MOTIFS$1.map((title, index) => ({
		id: `motif-${index}`,
		title
	}));
	return shuffle([...portraits, ...motifs]);
}
function deal$1(players) {
	const named = players.map((player) => ({
		...player,
		name: player.name.trim() || "Invité"
	}));
	const deck = deckFor(named);
	const size = Math.max(2, Math.min(5, Math.floor(deck.length / named.length)));
	const hands = {};
	named.forEach((player, index) => {
		hands[player.id] = deck.slice(index * size, index * size + size);
	});
	const scores = {};
	for (const player of named) scores[player.id] = 0;
	return {
		players: named,
		hands,
		storyteller: 0,
		clue: "",
		picked: null,
		played: [],
		order: [],
		votes: {},
		cursor: 0,
		scores,
		step: "clue",
		round: 1
	};
}
function Eclats({ mode }) {
	const party = useParty((state) => state.players);
	const [model, setModel] = (0, import_react.useState)(null);
	const [sheet, setSheet] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const named = party.map((player) => ({
			...player,
			name: player.name.trim() || "Invité"
		}));
		setSheet(deckFor(named).slice(0, 12));
	}, [party]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedPlayers, {
				min: 3,
				count: party.length,
				children: !model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Une phrase, plusieurs images"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Le conteur pose un éclat et une phrase. Les autres glissent une image qui pourrait convenir. On vote pour retrouver celle du conteur."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => setModel(deal$1(party)),
						children: "Distribuer les éclats"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table$2, {
					model,
					setModel,
					onReset: () => setModel(null)
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Douze éclats de cette maison — portraits et motifs. Imprimez, mélangez, inventez la phrase à voix haute." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, { cards: sheet })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Le conteur choisit une carte et dit une phrase. Chaque autre joueur pose une carte qui pourrait illustrer la même phrase." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "On mélange. Chacun vote, sauf le conteur, et jamais pour sa propre carte." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Si tout le monde ou personne ne trouve le conteur, il marque 0 et les autres marquent 2. Sinon le conteur et ceux qui l'ont trouvé marquent 2. Chaque autre carte marque 1 par vote reçu." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "On change de conteur jusqu'à ce que les mains se vident." })
				]
			}) })
		})
	] });
}
function Sheet({ cards }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sheet-grid",
		children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-extrabold text-gold",
				children: "Éclat de conte"
			}),
			card.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
				name: card.who ?? card.title,
				photo: card.photo,
				className: "mx-auto h-28 w-24 text-2xl"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto flex h-28 w-24 items-center justify-center rounded-2xl border border-gold bg-gold-soft" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-center font-display text-xl leading-tight",
				children: card.title
			})
		] }, card.id))
	});
}
function Table$2({ model, setModel, onReset }) {
	const teller = model.players[model.storyteller];
	if (!teller) return null;
	const others = model.players.filter((player) => player.id !== teller.id);
	function removeFromHand(playerId, cardId) {
		return {
			...model.hands,
			[playerId]: (model.hands[playerId] ?? []).filter((card) => card.id !== cardId)
		};
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-extrabold text-gold",
				children: ["Conte ", model.round]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: onReset,
				children: "Ranger"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 flex flex-wrap gap-2",
			children: model.players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-2 rounded-full bg-parchment py-1 pr-3 pl-1 text-sm font-extrabold",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
						name: player.name,
						photo: player.photo,
						className: "size-8 text-sm"
					}),
					player.name,
					" · ",
					model.scores[player.id] ?? 0
				]
			}, player.id))
		}),
		model.step === "clue" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clue, {
			teller,
			hand: model.hands[teller.id] ?? [],
			onSubmit: (clue, card) => {
				setModel({
					...model,
					clue,
					picked: card,
					played: [{
						playerId: teller.id,
						card
					}],
					hands: removeFromHand(teller.id, card.id),
					cursor: 0,
					step: "cover"
				});
			}
		}),
		(model.step === "cover" || model.step === "play") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Offer, {
			model,
			player: others[model.cursor],
			open: model.step === "play",
			onOpen: () => setModel({
				...model,
				step: "play"
			}),
			onPlay: (card) => {
				const player = others[model.cursor];
				if (!player) return;
				const played = [...model.played, {
					playerId: player.id,
					card
				}];
				const hands = removeFromHand(player.id, card.id);
				if (model.cursor + 1 >= others.length) {
					setModel({
						...model,
						played,
						hands,
						order: shuffle(played),
						cursor: 0,
						votes: {},
						step: "vote-cover"
					});
					return;
				}
				setModel({
					...model,
					played,
					hands,
					cursor: model.cursor + 1,
					step: "cover"
				});
			}
		}, `${model.round}-${model.cursor}`),
		(model.step === "vote-cover" || model.step === "vote") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ballot, {
			model,
			voters: others,
			open: model.step === "vote",
			onOpen: () => setModel({
				...model,
				step: "vote"
			}),
			onVote: (cardId) => {
				const voter = others[model.cursor];
				if (!voter) return;
				const votes = {
					...model.votes,
					[voter.id]: cardId
				};
				if (model.cursor + 1 >= others.length) {
					setModel(scoreRound({
						...model,
						votes
					}));
					return;
				}
				setModel({
					...model,
					votes,
					cursor: model.cursor + 1,
					step: "vote-cover"
				});
			}
		}, `vote-${model.cursor}`),
		model.step === "score" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
			model,
			setModel
		}),
		model.step === "end" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "Les mains sont vides"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "line",
				onClick: onReset,
				children: "Rejouer"
			})]
		})
	] });
}
function scoreRound(model) {
	const teller = model.players[model.storyteller];
	if (!teller || !model.picked) return model;
	const voters = model.players.filter((player) => player.id !== teller.id);
	const found = voters.filter((player) => model.votes[player.id] === model.picked?.id);
	const allOrNone = found.length === 0 || found.length === voters.length;
	const scores = { ...model.scores };
	if (allOrNone) for (const voter of voters) scores[voter.id] = (scores[voter.id] ?? 0) + 2;
	else {
		scores[teller.id] = (scores[teller.id] ?? 0) + 2;
		for (const voter of found) scores[voter.id] = (scores[voter.id] ?? 0) + 2;
	}
	for (const voter of voters) {
		const choice = model.votes[voter.id];
		const owner = model.played.find((item) => item.card.id === choice);
		if (owner && owner.playerId !== teller.id) scores[owner.playerId] = (scores[owner.playerId] ?? 0) + 1;
	}
	return {
		...model,
		scores,
		step: "score"
	};
}
function Clue({ teller, hand, onSubmit }) {
	const [clue, setClue] = (0, import_react.useState)("");
	const [cardId, setCardId] = (0, import_react.useState)(null);
	const card = hand.find((item) => item.id === cardId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-3xl",
				children: [teller.name, " conte"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Choisissez un éclat, puis une phrase que les autres entendront."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
				children: hand.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardButton, {
					card: item,
					on: item.id === cardId,
					onClick: () => setCardId(item.id)
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: clue,
				maxLength: 80,
				onChange: (event) => setClue(event.target.value),
				placeholder: "La phrase du conte",
				className: "mt-3 min-h-11 w-full rounded-2xl border border-line bg-parchment px-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-3",
				disabled: !clue.trim() || !card,
				onClick: () => card && onSubmit(clue.trim(), card),
				children: "Poser l'éclat"
			})
		]
	});
}
function Offer({ model, player, open, onOpen, onPlay }) {
	if (!player) return null;
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: player.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Vous allez entendre la phrase et choisir un éclat. Les autres se détournent."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: onOpen,
				children: "Choisir mon éclat"
			})
		]
	});
	const hand = model.hands[player.id] ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-extrabold text-gold",
				children: ["Phrase de ", model.players[model.storyteller]?.name]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-3xl leading-tight",
				children: [
					"« ",
					model.clue,
					" »"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: hand.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardButton, {
					card,
					on: false,
					onClick: () => onPlay(card)
				}, card.id))
			})
		]
	});
}
function Ballot({ model, voters, open, onOpen, onVote }) {
	const voter = voters[model.cursor];
	if (!voter) return null;
	const own = model.played.find((item) => item.playerId === voter.id)?.card.id;
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-3xl",
				children: [voter.name, " vote"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Retrouvez l'éclat du conteur. Pas le vôtre."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: onOpen,
				children: "Voir les éclats"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-display text-2xl leading-tight",
			children: [
				"« ",
				model.clue,
				" »"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-2 gap-2",
			children: model.order.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardButton, {
				card: item.card,
				on: false,
				disabled: item.card.id === own,
				caption: item.card.id === own ? "Votre éclat" : `Carte ${index + 1}`,
				onClick: () => onVote(item.card.id)
			}, item.card.id))
		})]
	});
}
function Score({ model, setModel }) {
	const teller = model.players[model.storyteller];
	function next() {
		const upcoming = (model.storyteller + 1) % model.players.length;
		const tellerNext = model.players[upcoming];
		if (!tellerNext || (model.hands[tellerNext.id] ?? []).length === 0) {
			setModel({
				...model,
				step: "end"
			});
			return;
		}
		setModel({
			...model,
			storyteller: upcoming,
			round: model.round + 1,
			clue: "",
			picked: null,
			played: [],
			order: [],
			votes: {},
			cursor: 0,
			step: "clue"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "Le conte se dévoile"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					"L'éclat de ",
					teller?.name,
					" était « ",
					model.picked?.title,
					" »."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: model.order.map((item) => {
					const owner = model.players.find((player) => player.id === item.playerId);
					const votes = Object.values(model.votes).filter((id) => id === item.card.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl bg-parchment px-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-extrabold",
								children: item.card.title
							}),
							" — ",
							owner?.name,
							item.playerId === teller?.id ? " · conteur" : "",
							" · ",
							votes,
							" vote",
							votes > 1 ? "s" : ""
						]
					}, item.card.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: next,
				children: "Conte suivant"
			})
		]
	});
}
function CardButton({ card, on, disabled, caption, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		onClick,
		className: `flex min-h-24 flex-col items-center justify-center gap-2 rounded-2xl border p-2 text-center disabled:opacity-40 ${on ? "border-gold bg-gold-soft" : "border-line bg-cream"}`,
		children: [
			card.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
				name: card.title,
				photo: card.photo,
				className: "h-14 w-12 text-lg"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg leading-tight",
				children: card.title
			}),
			caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-extrabold text-muted",
				children: caption
			}) : null
		]
	});
}
var MOTIFS = [
	{
		id: "couronne",
		label: "Couronne",
		icon: Crown
	},
	{
		id: "rose",
		label: "Rose",
		icon: Flower2
	},
	{
		id: "lune",
		label: "Lune",
		icon: Moon
	},
	{
		id: "etoile",
		label: "Étoile",
		icon: Sparkles
	},
	{
		id: "cle",
		label: "Clé",
		icon: KeyRound
	},
	{
		id: "flute",
		label: "Flûte",
		icon: Music
	},
	{
		id: "soleil",
		label: "Soleil",
		icon: Sun
	},
	{
		id: "livre",
		label: "Livre",
		icon: BookOpen
	},
	{
		id: "plume",
		label: "Plume",
		icon: Feather
	},
	{
		id: "gemme",
		label: "Gemme",
		icon: Gem
	}
];
function makeDeck(players) {
	const chosen = [...players.map((player) => ({
		pairId: player.id,
		label: player.name.trim() || "Invité",
		photo: player.photo,
		icon: void 0
	})), ...MOTIFS.map((motif) => ({
		pairId: motif.id,
		label: motif.label,
		photo: void 0,
		icon: motif.icon
	}))].slice(0, Math.max(6, Math.min(10, Math.max(players.length + 2, 6))));
	return shuffle(chosen.flatMap((face) => [{
		...face,
		uid: uid()
	}, {
		...face,
		uid: uid()
	}]));
}
function Memoire({ mode }) {
	const players = useParty((state) => state.players);
	const [cards, setCards] = (0, import_react.useState)([]);
	const [found, setFound] = (0, import_react.useState)([]);
	const [up, setUp] = (0, import_react.useState)([]);
	const [turn, setTurn] = (0, import_react.useState)(0);
	const [scores, setScores] = (0, import_react.useState)([]);
	const [lock, setLock] = (0, import_react.useState)(false);
	const [sheet, setSheet] = (0, import_react.useState)([]);
	const timer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setSheet(makeDeck(players));
	}, [players]);
	(0, import_react.useEffect)(() => () => {
		if (timer.current) window.clearTimeout(timer.current);
	}, []);
	function deal() {
		if (timer.current) window.clearTimeout(timer.current);
		setCards(makeDeck(players));
		setFound([]);
		setUp([]);
		setTurn(0);
		setScores(players.map(() => 0));
		setLock(false);
	}
	const started = cards.length > 0;
	const pairs = cards.length / 2;
	const done = started && found.length === pairs;
	const roster = players.map((player) => ({
		...player,
		name: player.name.trim() || "Invité"
	}));
	function pick(card) {
		if (!started || done || lock || found.includes(card.pairId) || up.includes(card.uid)) return;
		if (up.length === 0) {
			setUp([card.uid]);
			return;
		}
		const first = cards.find((item) => item.uid === up[0]);
		if (!first) return;
		if (first.pairId === card.pairId) {
			setFound((current) => [...current, card.pairId]);
			setScores((current) => current.map((score, index) => index === turn ? score + 1 : score));
			setUp([]);
			return;
		}
		setUp([first.uid, card.uid]);
		setLock(true);
		timer.current = window.setTimeout(() => {
			setUp([]);
			setTurn((value) => (value + 1) % players.length);
			setLock(false);
		}, 800);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedPlayers, {
				min: 1,
				count: players.length,
				children: !started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Médaillons face cachée"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Retournez-en deux. Une paire reste ouverte et vous rejouez. Sinon, l'écran passe au suivant."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: deal,
						children: "Disposer les cartes"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-extrabold",
							children: done ? "Toutes les paires sont ouvertes." : `Au tour de ${roster[turn]?.name ?? ""}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "line",
							size: "sm",
							onClick: deal,
							children: "Rebattre"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-wrap gap-2",
						children: roster.map((player, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: `flex items-center gap-2 rounded-full py-1 pr-3 pl-1 ${index === turn && !done ? "bg-gold-soft" : "bg-parchment"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
								name: player.name,
								photo: player.photo,
								className: "size-8 text-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-extrabold",
								children: [
									player.name,
									" · ",
									scores[index] ?? 0
								]
							})]
						}, player.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4",
						children: cards.map((card) => {
							const open = up.includes(card.uid) || found.includes(card.pairId);
							const Icon = card.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => pick(card),
								className: "flex aspect-[3/4] flex-col items-center justify-center rounded-2xl border border-gold bg-cream p-2",
								"aria-label": open ? card.label : "Carte face cachée",
								children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [card.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
									name: card.label,
									photo: card.photo,
									className: "h-16 w-14 text-xl"
								}) : Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-8 text-gold",
									"aria-hidden": "true"
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 text-center text-xs font-extrabold",
									children: card.label
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, {
									className: "size-6 text-gold",
									"aria-hidden": "true"
								})
							}, card.uid);
						})
					}),
					done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-display text-2xl",
						children: winnerLine(roster.map((player) => player.name), scores)
					})
				] })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Deux cartes identiques par visage et par symbole. Découpez, mélangez face cachée." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sheet-grid",
				children: sheet.map((card) => {
					const Icon = card.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold text-gold",
						children: "Mémoire d'Or"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-1 flex-col items-center justify-center gap-2",
						children: [card.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							name: card.label,
							photo: card.photo,
							className: "h-24 w-20 text-2xl"
						}) : Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-10 text-gold",
							"aria-hidden": "true"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-center font-display text-2xl",
							children: card.label
						})]
					})] }, card.uid);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "On retourne deux cartes. Si elles vont ensemble, elles restent ouvertes et l'on rejoue." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sinon on les referme et le voisin joue. À la fin, le plus de paires l'emporte. À un seul joueur, on joue contre la table." })]
			}) })
		})
	] });
}
function winnerLine(names, scores) {
	const best = Math.max(0, ...scores);
	const leaders = names.filter((_, index) => scores[index] === best);
	if (leaders.length === 1) return `${leaders[0]} a la mémoire la plus dorée.`;
	return `Égalité entre ${leaders.join(" et ")}.`;
}
var ROLE = {
	loup: {
		title: "Loup de velours",
		text: "Chaque nuit, avec la meute, désignez une proie. Le jour, mentez avec grâce."
	},
	lumiere: {
		title: "La Lumière",
		text: "Chaque nuit, sondez un visage : loup de velours, ou de la cour."
	},
	gardien: {
		title: "Gardien des clés",
		text: "Protégez quelqu'un chaque nuit. Jamais la même personne deux nuits de suite."
	},
	herboriste: {
		title: "L'Herboriste",
		text: "Une rosée pour sauver la proie, une ombre pour en désigner une autre. Une fois chacune."
	},
	heraut: {
		title: "Le Héraut",
		text: "Si vous tombez, désignez aussitôt quelqu'un qui vous suit."
	},
	courtisan: {
		title: "Courtisan",
		text: "Aucun pouvoir la nuit. Le jour, votre voix pèse autant qu'une couronne."
	}
};
var COVER = {
	gardien: "le Gardien des clés",
	lumiere: "la Lumière",
	loups: "les Loups de velours",
	herboriste: "l'Herboriste"
};
function composition(count) {
	const packs = {
		4: [
			"loup",
			"lumiere",
			"herboriste",
			"courtisan"
		],
		5: [
			"loup",
			"lumiere",
			"gardien",
			"herboriste",
			"courtisan"
		],
		6: [
			"loup",
			"loup",
			"lumiere",
			"herboriste",
			"heraut",
			"courtisan"
		],
		7: [
			"loup",
			"loup",
			"lumiere",
			"gardien",
			"herboriste",
			"heraut",
			"courtisan"
		],
		8: [
			"loup",
			"loup",
			"lumiere",
			"gardien",
			"herboriste",
			"heraut",
			"courtisan",
			"courtisan"
		]
	};
	const roles = [...packs[Math.max(4, Math.min(8, count))] ?? packs[4]];
	while (roles.length < count) roles.push("courtisan");
	if (count >= 9) {
		const slot = roles.lastIndexOf("courtisan");
		if (slot >= 0) roles[slot] = "loup";
	}
	return roles;
}
function winnerOf(seats) {
	const wolves = seats.filter((seat) => seat.alive && seat.role === "loup").length;
	const court = seats.filter((seat) => seat.alive && seat.role !== "loup").length;
	if (wolves === 0) return "cour";
	if (court === 0 || wolves >= court) return "loups";
	return null;
}
function nightSteps(seats, saveUsed, poisonUsed) {
	const live = seats.filter((seat) => seat.alive);
	const steps = [];
	if (live.some((seat) => seat.role === "gardien")) steps.push("gardien");
	if (live.some((seat) => seat.role === "lumiere")) steps.push("lumiere");
	if (live.some((seat) => seat.role === "loup")) steps.push("loups");
	if (live.some((seat) => seat.role === "herboriste") && (!saveUsed || !poisonUsed)) steps.push("herboriste");
	return steps;
}
function withLog(model, line) {
	return {
		...model,
		log: [line, ...model.log].slice(0, 8)
	};
}
function endState(model, winner) {
	return {
		...model,
		phase: {
			t: "end",
			winner,
			reason: winner === "cour" ? "Plus un loup ne siège à la table." : "Les loups sont aussi nombreux que la cour."
		}
	};
}
function openNight(model) {
	const win = winnerOf(model.seats);
	if (win) return endState(model, win);
	const steps = nightSteps(model.seats, model.saveUsed, model.poisonUsed);
	const cleared = {
		...model,
		steps,
		cursor: 0,
		guard: null,
		wolf: null,
		save: false,
		poison: null,
		seen: ""
	};
	if (!steps.length) return {
		...cleared,
		phase: { t: "day" }
	};
	return {
		...cleared,
		phase: {
			t: "cover",
			step: steps[0]
		}
	};
}
function killAndContinue(model, ids, then, line) {
	const heraut = model.seats.find((seat) => seat.alive && ids.includes(seat.playerId) && seat.role === "heraut");
	const seats = model.seats.map((seat) => ids.includes(seat.playerId) ? {
		...seat,
		alive: false
	} : seat);
	const next = withLog({
		...model,
		seats
	}, line);
	if (heraut && seats.some((seat) => seat.alive)) return {
		...next,
		phase: {
			t: "heraut-cover",
			then
		}
	};
	const win = winnerOf(seats);
	if (win) return endState(next, win);
	if (then === "night") return openNight({
		...next,
		night: model.night + 1
	});
	return {
		...next,
		phase: { t: "day" }
	};
}
function finishStep(model) {
	const saveUsed = model.saveUsed || model.save;
	const poisonUsed = model.poisonUsed || Boolean(model.poison);
	const cursor = model.cursor + 1;
	const drafted = {
		...model,
		saveUsed,
		poisonUsed,
		cursor
	};
	if (cursor >= model.steps.length) return resolveDawn(drafted);
	return {
		...drafted,
		phase: {
			t: "cover",
			step: model.steps[cursor]
		}
	};
}
function resolveDawn(model) {
	const ids = [];
	if (model.wolf && model.wolf !== model.guard && !model.save) ids.push(model.wolf);
	if (model.poison && !ids.includes(model.poison)) ids.push(model.poison);
	const names = ids.map((id) => model.seats.find((seat) => seat.playerId === id)?.name).filter((name) => Boolean(name));
	const text = names.length ? `Aube ${model.night} : la cour pleure ${names.join(" et ")}.` : `Aube ${model.night} : la table est intacte.`;
	return killAndContinue(model.guard ? {
		...model,
		lastGuard: model.guard
	} : model, ids, "day", text);
}
function face(seat) {
	return {
		id: seat.playerId,
		name: seat.name,
		photo: seat.photo
	};
}
function Minuit({ mode }) {
	const players = useParty((state) => state.players);
	const [model, setModel] = (0, import_react.useState)(null);
	const [named, setNamed] = (0, import_react.useState)(null);
	const roles = composition(Math.max(4, players.length));
	function begin(source) {
		const dealt = shuffle(composition(source.length));
		const seats = source.map((player, index) => ({
			playerId: player.id,
			name: player.name.trim() || "Invité",
			photo: player.photo,
			role: dealt[index] ?? "courtisan",
			alive: true
		}));
		setModel({
			seats,
			phase: {
				t: "peek",
				i: 0,
				open: false
			},
			night: 1,
			steps: [],
			cursor: 0,
			lastGuard: null,
			saveUsed: false,
			poisonUsed: false,
			guard: null,
			wolf: null,
			save: false,
			poison: null,
			seen: "",
			log: ["Les rôles sont tirés. Un seul visage à la fois."]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedPlayers, {
				min: 4,
				count: players.length,
				children: !model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "La nuit va tomber"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Le conteur, c'est l'écran. Passez-le. Fermez les yeux quand on vous le demande. Au matin, vote à bulletin secret."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => begin(players),
						children: "Tirer les rôles"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
					model,
					setModel,
					onReset: () => setModel(null)
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Cartes de rôle à glisser dans une enveloppe, médaillons de table, et — si l'hôte distribue aussitôt — une édition où le portrait porte déjà son secret." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Rôles à envelopper"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: roles.map((role, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold tracking-wide text-gold",
							children: "Minuit au Château"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl leading-tight",
							children: ROLE[role].title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-snug",
							children: ROLE[role].text
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: role === "loup" ? "Meute" : "Cour"
						})
					] }, `${role}-${index}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 font-display text-2xl",
					children: "Médaillons de table"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold text-gold",
							children: "Place"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							name: player.name,
							photo: player.photo,
							className: "mx-auto h-28 w-24 text-3xl"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-center font-display text-2xl",
							children: player.name
						})
					] }, player.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 print:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "line",
						onClick: () => {
							const dealt = shuffle(composition(players.length));
							setNamed(players.map((player, index) => ({
								playerId: player.id,
								name: player.name.trim() || "Invité",
								photo: player.photo,
								role: dealt[index] ?? "courtisan",
								alive: true
							})));
						},
						children: "Préparer l'édition nominative"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "À n'imprimer que si la table ne regarde pas : le rôle est écrit sous le portrait."
					})]
				}),
				named && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-4",
					children: named.map((seat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
						name: seat.name,
						photo: seat.photo,
						className: "mx-auto h-24 w-20 text-2xl"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl",
							children: seat.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-extrabold text-rose",
							children: ROLE[seat.role].title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-snug",
							children: ROLE[seat.role].text
						})
					] })] }, seat.playerId))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "De 4 à 8 joueurs. Au-delà, on ajoute des courtisans, et un troisième loup à partir de neuf." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Chacun mémorise son rôle, puis la nuit suit toujours le même ordre : Gardien, Lumière, Meute, Herboriste." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Le Gardien bloque seulement la proie des loups, et change de protégé chaque nuit. La Lumière apprend un camp. L'Herboriste peut sauver la proie et empoisonner quelqu'un, une fois pour chaque fiole. Le poison ignore le Gardien." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Le jour, on débat puis on vote en secret. Égalité : personne ne sort. Le Héraut, en tombant, désigne une dernière personne." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "La cour gagne si plus aucun loup n'est en vie. Les loups gagnent dès qu'ils sont au moins aussi nombreux que les autres." })
				]
			}) })
		})
	] });
}
function Play({ model, setModel, onReset }) {
	const live = model.seats.filter((seat) => seat.alive);
	const phase = model.phase;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1.4fr_0.6fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			phase.t === "peek" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Peek, {
				model,
				setModel
			}),
			phase.t === "cover" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
				title: `Nuit ${model.night}`,
				text: `Tout le monde ferme les yeux. Seul ${COVER[phase.step]} regarde.`,
				action: "Je suis prêt",
				onNext: () => setModel({
					...model,
					phase: {
						t: "act",
						step: phase.step
					}
				})
			}),
			phase.t === "act" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Act, {
				model,
				setModel
			}),
			phase.t === "heraut-cover" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
				title: "Le Héraut tombe",
				text: "Passez l'écran au Héraut. Les autres se détournent.",
				action: "Je désigne",
				onNext: () => setModel({
					...model,
					phase: {
						t: "heraut",
						then: phase.then
					}
				})
			}),
			phase.t === "heraut" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "Qui vous suit ?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choices, {
				options: live.map(face),
				onPick: (id) => {
					const name = model.seats.find((seat) => seat.playerId === id)?.name ?? "";
					setModel(killAndContinue(model, [id], phase.then, `Le Héraut emporte ${name}.`));
				}
			})] }),
			phase.t === "day" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Le jour dans la cour"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Débattez à voix haute. Quand la table est prête, le vote est secret."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 flex flex-wrap gap-2",
					children: model.seats.map((seat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: seat.alive ? "flex items-center gap-2 rounded-full bg-gold-soft py-1 pr-3 pl-1" : "flex items-center gap-2 rounded-full bg-rose-soft py-1 pr-3 pl-1 opacity-70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: seat.name,
							photo: seat.photo,
							className: "size-8 text-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-extrabold",
							children: seat.alive ? seat.name : `${seat.name} est tombé`
						})]
					}, seat.playerId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					onClick: () => setModel({
						...model,
						phase: {
							t: "vote",
							i: 0,
							ballots: {}
						}
					}),
					children: "Ouvrir le vote"
				})
			] }),
			phase.t === "vote" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vote, {
				model,
				setModel
			}),
			phase.t === "end" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-extrabold text-gold",
					children: phase.winner === "cour" ? "Victoire de la cour" : "Victoire de la meute"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl",
					children: phase.reason
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2",
					children: model.seats.map((seat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: seat.name,
							photo: seat.photo,
							className: "size-10 text-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-extrabold",
							children: seat.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-sm text-muted",
							children: [ROLE[seat.role].title, seat.alive ? "" : " · tombé"]
						})] })]
					}, seat.playerId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					variant: "line",
					onClick: onReset,
					children: "Recommencer"
				})
			] })
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Chronique"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogList, { lines: model.log }),
			phase.t !== "end" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "ghost",
				onClick: onReset,
				children: "Abandonner la nuit"
			})
		] })]
	});
}
function Peek({ model, setModel }) {
	const phase = model.phase;
	if (phase.t !== "peek") return null;
	const seat = model.seats[phase.i];
	if (!seat) return null;
	const role = ROLE[seat.role];
	return phase.open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-extrabold text-gold",
			children: seat.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl",
			children: role.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-md text-muted",
			children: role.text
		}),
		seat.role === "loup" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm",
			children: [
				"Meute :",
				" ",
				model.seats.filter((other) => other.role === "loup").map((other) => other.name).join(", ")
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: () => {
				const next = phase.i + 1;
				if (next >= model.seats.length) setModel(openNight(model));
				else setModel({
					...model,
					phase: {
						t: "peek",
						i: next,
						open: false
					}
				});
			},
			children: "J'ai retenu mon rôle"
		})
	] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {
		title: seat.name,
		text: "Les autres regardent ailleurs. Seulement ce prénom touche l'écran.",
		action: "Voir mon rôle",
		onNext: () => setModel({
			...model,
			phase: {
				t: "peek",
				i: phase.i,
				open: true
			}
		})
	});
}
function Act({ model, setModel }) {
	const phase = model.phase;
	if (phase.t !== "act") return null;
	const live = model.seats.filter((seat) => seat.alive);
	if (phase.step === "gardien") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: "Qui protégez-vous ?"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Pas le même protégé que la nuit dernière."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choices, {
			options: live.map(face),
			disabled: (id) => id === model.lastGuard,
			onPick: (id) => setModel(finishStep({
				...model,
				guard: id
			}))
		})
	] });
	if (phase.step === "lumiere") {
		const self = model.seats.find((seat) => seat.alive && seat.role === "lumiere");
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: "Qui sondez-vous ?"
		}), model.seen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 font-display text-2xl",
			children: model.seen
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: () => setModel(finishStep(model)),
			children: "Refermer les yeux"
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choices, {
			options: live.filter((seat) => seat.playerId !== self?.playerId).map(face),
			onPick: (id) => {
				const seat = model.seats.find((item) => item.playerId === id);
				const seen = seat ? `${seat.name} est ${seat.role === "loup" ? "un Loup de velours" : "de la cour"}.` : "";
				setModel({
					...model,
					seen
				});
			}
		})] });
	}
	if (phase.step === "loups") {
		const pack = model.seats.filter((seat) => seat.alive && seat.role === "loup").map((seat) => seat.name);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "La meute choisit"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					"Ensemble : ",
					pack.join(", "),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choices, {
				options: live.filter((seat) => seat.role !== "loup").map(face),
				onPick: (id) => setModel(finishStep({
					...model,
					wolf: id
				}))
			})
		] });
	}
	const victim = model.seats.find((seat) => seat.playerId === model.wolf);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Herboriste, {
		model,
		setModel,
		victim: victim?.name ?? "personne"
	});
}
function Herboriste({ model, setModel, victim }) {
	const [poison, setPoison] = (0, import_react.useState)(null);
	const [save, setSave] = (0, import_react.useState)(false);
	const live = model.seats.filter((seat) => seat.alive);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: "Les fioles"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: model.wolf ? `La meute vise ${victim}.` : "La meute n'a désigné personne."
		}),
		model.wolf && !model.saveUsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-3",
			variant: save ? "rose" : "line",
			onClick: () => setSave((value) => !value),
			children: save ? "Rosée versée : la proie est sauvée" : "Verser la rosée et sauver la proie"
		}),
		!model.poisonUsed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm font-extrabold",
			children: "Fiole d'ombre, une seule fois"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choices, {
			options: live.map(face),
			selected: poison,
			onPick: (id) => setPoison((current) => current === id ? null : id)
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: () => setModel(finishStep({
				...model,
				save: Boolean(model.wolf) && save,
				poison
			})),
			children: "Refermer l'officine"
		})
	] });
}
function Vote({ model, setModel }) {
	const phase = model.phase;
	if (phase.t !== "vote") return null;
	const live = model.seats.filter((seat) => seat.alive);
	const voter = live[phase.i];
	if (!voter) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-extrabold text-gold",
			children: "Bulletin secret"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "font-display text-3xl",
			children: [voter.name, " vote"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Les autres ne regardent pas."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choices, {
			options: live.map(face),
			onPick: (id) => {
				const ballots = {
					...phase.ballots,
					[voter.playerId]: id
				};
				const next = phase.i + 1;
				if (next < live.length) {
					setModel({
						...model,
						phase: {
							t: "vote",
							i: next,
							ballots
						}
					});
					return;
				}
				const tally = /* @__PURE__ */ new Map();
				for (const target of Object.values(ballots)) tally.set(target, (tally.get(target) ?? 0) + 1);
				let best = 0;
				let leaders = [];
				for (const [idKey, count] of tally) if (count > best) {
					best = count;
					leaders = [idKey];
				} else if (count === best) leaders.push(idKey);
				if (leaders.length !== 1) {
					setModel(openNight(withLog({
						...model,
						night: model.night + 1
					}, "Votes partagés : personne ne sort.")));
					return;
				}
				const fallen = model.seats.find((seat) => seat.playerId === leaders[0])?.name ?? "";
				setModel(killAndContinue(model, [leaders[0]], "night", `${fallen} est banni par la cour.`));
			}
		})
	] });
}
function Cover({ title, text, action, onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-md text-muted",
			children: text
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: onNext,
			children: action
		})
	] });
}
function Choices({ options, onPick, disabled, selected }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 grid grid-cols-2 gap-2",
		children: options.map((option) => {
			const off = disabled?.(option.id) ?? false;
			const on = selected === option.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: off,
				onClick: () => onPick(option.id),
				className: `flex min-h-11 items-center gap-2 rounded-2xl border px-2 py-2 text-left font-extrabold disabled:opacity-40 ${on ? "border-gold bg-gold-soft" : "border-line bg-parchment"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					name: option.name,
					photo: option.photo,
					className: "size-10 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: option.name
				})]
			}, option.id);
		})
	});
}
var ROOMS = [
	["orangerie", "Orangerie"],
	["bibliotheque", "Bibliothèque"],
	["salon", "Salon de thé"],
	["tour", "Tour du nord"],
	["galerie", "Galerie des miroirs"],
	["office", "Office d'argent"],
	["jardin", "Jardin secret"],
	["ambre", "Chambre d'ambre"],
	["trone", "Salle du trône"]
];
var RELICS = [
	["epingle", "Épingle de perle"],
	["flute", "Flûte d'or"],
	["ruban", "Ruban de soie"],
	["cle", "Clé ancienne"],
	["coupe", "Coupe de cristal"],
	["eventail", "Éventail peint"]
];
var GUESTS = [
	{
		id: "g-brume",
		name: "Marquis de Brume"
	},
	{
		id: "g-paquerette",
		name: "Dame Pâquerette"
	},
	{
		id: "g-lino",
		name: "Page Lino"
	},
	{
		id: "g-oriole",
		name: "Cantatrice Oriole"
	}
];
function build(players) {
	const suspects = players.map((player) => ({
		id: player.id,
		kind: "suspect",
		name: player.name.trim() || "Invité",
		photo: player.photo
	}));
	for (const guest of GUESTS) {
		if (suspects.length >= 5) break;
		suspects.push({
			id: guest.id,
			kind: "suspect",
			name: guest.name
		});
	}
	const rooms = ROOMS.map(([id, name]) => ({
		id,
		kind: "room",
		name
	}));
	const relics = RELICS.map(([id, name]) => ({
		id,
		kind: "relic",
		name
	}));
	const solution = {
		suspect: shuffle(suspects)[0].id,
		room: shuffle(rooms)[0].id,
		relic: shuffle(relics)[0].id
	};
	const deck = shuffle([
		...suspects.filter((card) => card.id !== solution.suspect),
		...rooms.filter((card) => card.id !== solution.room),
		...relics.filter((card) => card.id !== solution.relic)
	]);
	const hands = {};
	for (const player of players) hands[player.id] = [];
	deck.forEach((card, index) => {
		hands[players[index % players.length].id].push(card.id);
	});
	return {
		cards: [
			...suspects,
			...rooms,
			...relics
		],
		solution,
		hands,
		out: {},
		turn: 0,
		phase: { t: "turn" },
		log: ["Le secret est sous trois sceaux. À vous le carnet."],
		notes: {},
		peek: false,
		book: false,
		draft: {
			suspect: suspects[0].id,
			room: rooms[0].id,
			relic: relics[0].id
		}
	};
}
function nameOf(cards, id) {
	return cards.find((card) => card.id === id)?.name ?? "—";
}
function matches(card, suggestion) {
	return card.kind === "suspect" && card.id === suggestion.suspect || card.kind === "room" && card.id === suggestion.room || card.kind === "relic" && card.id === suggestion.relic;
}
function Mystere({ mode }) {
	const players = useParty((state) => state.players);
	const [model, setModel] = (0, import_react.useState)(null);
	const cast = (0, import_react.useMemo)(() => {
		const list = players.map((player) => ({
			id: player.id,
			kind: "suspect",
			name: player.name.trim() || "Invité",
			photo: player.photo
		}));
		for (const guest of GUESTS) {
			if (list.length >= 5) break;
			list.push({
				id: guest.id,
				kind: "suspect",
				name: guest.name
			});
		}
		return list;
	}, [players]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedPlayers, {
				min: 2,
				count: players.length,
				children: !model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "Trois sceaux"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Un visage, une salle, une relique ont été retirés. Suggérez, faites-vous montrer une carte, puis accusez quand le carnet est sûr."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => setModel(build(players)),
						children: "Sceller le mystère"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board$1, {
					model,
					setModel,
					players,
					onReset: () => setModel(null)
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Suspects de la maison, salles du palais, reliques et carnet à cocher." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Visages"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: cast.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold text-gold",
							children: "Suspect"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							name: card.name,
							photo: card.photo,
							className: "mx-auto h-28 w-24 text-3xl"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-center font-display text-2xl leading-tight",
							children: card.name
						})
					] }, card.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 font-display text-2xl",
					children: "Salles"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: ROOMS.map(([id, name]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold text-gold",
							children: "Salle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-3xl leading-tight",
							children: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Mystère au Palais"
						})
					] }, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 font-display text-2xl",
					children: "Reliques"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: RELICS.map(([id, name]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold text-rose",
							children: "Relique"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-3xl leading-tight",
							children: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "À montrer, jamais à nommer tout haut."
						})
					] }, id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "On retire un suspect, une salle et une relique : c'est la solution. Le reste est distribué." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "À votre tour, suggérez les trois. Chaque autre joueur, dans l'ordre, doit montrer une carte correspondante s'il en a une. Sinon il passe. Une seule carte est montrée, puis le tour passe." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Accuser est définitif. Juste : vous gagnez. Faux : vous ne suggérez plus, mais vous pouvez encore montrer une carte." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "S'il manque des joueurs pour cinq suspects, la cour invite des hôtes illustrés, sans portrait." })
				]
			}) })
		})
	] });
}
function Board$1({ model, setModel, players, onReset }) {
	const byId = new Map(model.cards.map((card) => [card.id, card]));
	const active = players.filter((player) => !model.out[player.id]);
	const player = players[model.turn];
	if (!player) return null;
	function nextTurn(from, logLine) {
		let turn = from;
		for (let step = 0; step < players.length; step += 1) {
			turn = (turn + 1) % players.length;
			if (!model.out[players[turn].id]) break;
		}
		setModel({
			...model,
			turn,
			peek: false,
			book: false,
			phase: { t: "turn" },
			log: [logLine, ...model.log].slice(0, 8)
		});
	}
	function startRefute(suggestion) {
		const cursor = (model.turn + 1) % players.length;
		const line = `${player.name} suggère ${nameOf(model.cards, suggestion.suspect)}, ${nameOf(model.cards, suggestion.room)}, ${nameOf(model.cards, suggestion.relic)}.`;
		if (players.length < 2) return;
		setModel({
			...model,
			peek: false,
			phase: {
				t: "cover",
				cursor,
				suggestion
			},
			log: [line, ...model.log].slice(0, 8)
		});
	}
	const suggestionLabel = (suggestion) => `${nameOf(model.cards, suggestion.suspect)} · ${nameOf(model.cards, suggestion.room)} · ${nameOf(model.cards, suggestion.relic)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1.3fr_0.7fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: model.phase.t === "end" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl",
				children: players.find((item) => item.id === (model.phase.t === "end" ? model.phase.winnerId : void 0))?.name ?? "La cour s'est perdue"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EndText, {
				model,
				players
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "line",
				onClick: onReset,
				children: "Nouvelle enquête"
			})
		] }) : model.phase.t === "cover" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-3xl",
				children: ["Passez à ", players[model.phase.cursor]?.name]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-muted",
				children: ["Suggestion : ", suggestionLabel(model.phase.suggestion)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => setModel({
					...model,
					phase: {
						t: "refute",
						cursor: model.phase.t === "cover" ? model.phase.cursor : 0,
						suggestion: model.phase.t === "cover" ? model.phase.suggestion : model.draft
					}
				}),
				children: "Je regarde ma main"
			})
		] }) : model.phase.t === "refute" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Refute, {
			model,
			setModel,
			players,
			byId
		}) : model.phase.t === "show" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-3xl",
				children: ["Montrez ceci à ", player.name]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shown, { card: byId.get(model.phase.cardId) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => {
					const from = players[model.phase.t === "show" ? model.phase.from : 0]?.name ?? "";
					nextTurn(model.turn, `${from} a montré une carte à ${player.name}.`);
				},
				children: "C'est vu"
			})
		] }) : model.phase.t === "accuse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "Accuser pour de bon ?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: suggestionLabel(model.phase.suggestion)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "rose",
					onClick: () => {
						const suggestion = model.phase.t === "accuse" ? model.phase.suggestion : model.draft;
						if (suggestion.suspect === model.solution.suspect && suggestion.room === model.solution.room && suggestion.relic === model.solution.relic) {
							setModel({
								...model,
								phase: {
									t: "end",
									winnerId: player.id
								},
								log: [`${player.name} perce le secret.`, ...model.log].slice(0, 8)
							});
							return;
						}
						const out = {
							...model.out,
							[player.id]: true
						};
						if (!players.some((item) => item.id !== player.id && !out[item.id])) {
							setModel({
								...model,
								out,
								phase: { t: "end" },
								log: [`${player.name} se trompe. Plus personne pour accuser.`, ...model.log].slice(0, 8)
							});
							return;
						}
						let turn = model.turn;
						for (let step = 0; step < players.length; step += 1) {
							turn = (turn + 1) % players.length;
							if (!out[players[turn].id]) break;
						}
						setModel({
							...model,
							out,
							turn,
							phase: { t: "turn" },
							peek: false,
							log: [`${player.name} accuse à faux et quitte l'enquête.`, ...model.log].slice(0, 8)
						});
					},
					children: "J'accuse"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "line",
					onClick: () => setModel({
						...model,
						phase: { t: "turn" }
					}),
					children: "Revenir"
				})]
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Turn, {
			model,
			setModel,
			player,
			byId,
			onSuggest: startRefute,
			activeCount: active.length
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Chronique"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogList, { lines: model.log }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: ["En jeu : ", active.map((item) => item.name).join(", ") || "—"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "ghost",
				onClick: onReset,
				children: "Ranger l'enquête"
			})
		] })]
	});
}
function EndText({ model, players }) {
	if (model.phase.t !== "end") return null;
	const winnerId = model.phase.winnerId;
	const named = players.find((player) => player.id === winnerId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: named ? `${named.name} avait raison.` : "Aucune accusation n'a trouvé les trois sceaux." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2",
			children: [
				"C'était ",
				nameOf(model.cards, model.solution.suspect),
				", dans ",
				nameOf(model.cards, model.solution.room),
				", avec",
				" ",
				nameOf(model.cards, model.solution.relic),
				"."
			]
		})]
	});
}
function Shown({ card }) {
	if (!card) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 max-w-xs rounded-3xl border border-gold bg-gold-soft p-4",
		children: [
			card.photo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
				name: card.name,
				photo: card.photo,
				className: "mb-3 h-28 w-full text-2xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-extrabold uppercase",
				children: card.kind === "room" ? "Salle" : card.kind === "relic" ? "Relique" : "Suspect"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl leading-tight",
				children: card.name
			})
		]
	});
}
function Refute({ model, setModel, players, byId }) {
	if (model.phase.t !== "refute") return null;
	const who = players[model.phase.cursor];
	if (!who) return null;
	const suggestion = model.phase.suggestion;
	const options = (model.hands[who.id] ?? []).map((id) => byId.get(id)).filter((card) => Boolean(card && matches(card, suggestion)));
	function pass() {
		const next = ((model.phase.t === "refute" ? model.phase.cursor : 0) + 1) % players.length;
		if (next === model.turn) {
			const asker = players[model.turn]?.name ?? "";
			setModel({
				...model,
				phase: { t: "turn" },
				turn: nextPlayer(model.turn),
				peek: false,
				log: [`Personne ne répond à ${asker}.`, ...model.log].slice(0, 8)
			});
			return;
		}
		setModel({
			...model,
			phase: {
				t: "cover",
				cursor: next,
				suggestion
			}
		});
	}
	function nextPlayer(from) {
		let turn = from;
		for (let step = 0; step < players.length; step += 1) {
			turn = (turn + 1) % players.length;
			if (!model.out[players[turn].id]) return turn;
		}
		return from;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: who.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: options.length ? "Vous devez montrer l'une de ces cartes, rien d'autre." : "Aucune de vos cartes ne répond. Passez l'écran."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-2",
			children: options.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 rounded-2xl border border-line bg-parchment px-3 text-left font-extrabold",
				onClick: () => setModel({
					...model,
					phase: {
						t: "show",
						from: model.phase.t === "refute" ? model.phase.cursor : 0,
						cardId: card.id,
						suggestion
					}
				}),
				children: card.name
			}, card.id))
		}),
		!options.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: pass,
			children: "Je ne peux pas répondre"
		})
	] });
}
function Turn({ model, setModel, player, byId, onSuggest, activeCount }) {
	const hand = (model.hands[player.id] ?? []).map((id) => byId.get(id)).filter((card) => Boolean(card));
	const suspects = model.cards.filter((card) => card.kind === "suspect");
	const rooms = model.cards.filter((card) => card.kind === "room");
	const relics = model.cards.filter((card) => card.kind === "relic");
	const notes = model.notes[player.id] ?? {};
	function cycle(id) {
		const current = notes[id] ?? 0;
		setModel({
			...model,
			notes: {
				...model.notes,
				[player.id]: {
					...notes,
					[id]: (current + 1) % 3
				}
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
				name: player.name,
				photo: player.photo,
				className: "size-12 text-lg"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-extrabold text-gold",
				children: "Tour de piste"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: player.name
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "line",
				size: "sm",
				onClick: () => setModel({
					...model,
					peek: !model.peek,
					book: false
				}),
				children: model.peek ? "Cacher ma main" : "Voir ma main"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "line",
				size: "sm",
				onClick: () => setModel({
					...model,
					book: !model.book,
					peek: false
				}),
				children: model.book ? "Fermer le carnet" : "Mon carnet"
			})]
		}),
		model.peek && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 flex flex-wrap gap-2",
			children: hand.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-full bg-gold-soft px-3 py-2 text-sm font-extrabold",
				children: card.name
			}, card.id))
		}),
		model.book && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid gap-1",
			children: model.cards.map((card) => {
				const mark = notes[card.id] ?? 0;
				const label = mark === 1 ? "écarté" : mark === 2 ? "à suivre" : "vierge";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => cycle(card.id),
					className: "flex min-h-11 items-center justify-between rounded-xl px-2 text-left text-sm hover:bg-parchment",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: card.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("font-extrabold", mark === 1 ? "text-muted" : mark === 2 ? "text-rose" : "text-gold"),
						children: label
					})]
				}, card.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
			className: "mt-4 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Visage",
					value: model.draft.suspect,
					options: suspects,
					onChange: (suspect) => setModel({
						...model,
						draft: {
							...model.draft,
							suspect
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Salle",
					value: model.draft.room,
					options: rooms,
					onChange: (room) => setModel({
						...model,
						draft: {
							...model.draft,
							room
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Relique",
					value: model.draft.relic,
					options: relics,
					onChange: (relic) => setModel({
						...model,
						draft: {
							...model.draft,
							relic
						}
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => onSuggest(model.draft),
				children: "Suggérer"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "rose",
				disabled: activeCount < 1,
				onClick: () => setModel({
					...model,
					phase: {
						t: "accuse",
						suggestion: model.draft
					}
				}),
				children: "Accuser"
			})]
		})
	] });
}
function Select({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-extrabold",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			value,
			onChange: (event) => onChange(event.target.value),
			className: "mt-1 min-h-11 w-full rounded-2xl border border-line bg-parchment px-2 font-semibold",
			children: options.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: card.id,
				children: card.name
			}, card.id))
		})]
	});
}
var PROMPTS = [
	"Au bal, {name} arrive vêtu de ___.",
	"Le cadeau le plus étrange devant {name} : ___.",
	"Pour endormir le dragon de la tour, il faut ___.",
	"La recette secrète du goûter contient ___.",
	"Si le château parlait, il dirait : ___.",
	"{name} a un animal invisible qui ___.",
	"L'édit du jour interdit formellement ___.",
	"Dans la bibliothèque, un livre s'intitule ___.",
	"Cette nuit, {name} a rêvé de ___.",
	"Pour gagner le cœur de la cour, il suffit de ___.",
	"La potion rose sent ___.",
	"Personne ne sait que {name} collectionne ___.",
	"Le trône est trop grand : on le remplace par ___.",
	"À minuit, les portraits se mettent à ___.",
	"Le mot de passe du jardin secret est ___.",
	"Demain, tout le monde devra ___.",
	"Le goûter royal est annulé à cause de ___.",
	"{name} a brodé sur son mouchoir : ___."
];
function fill(template, players) {
	const name = players[Math.floor(Math.random() * players.length)]?.name ?? "quelqu'un";
	return template.replaceAll("{name}", name);
}
function openRound(model) {
	const deck = model.deck.length ? model.deck : shuffle(PROMPTS);
	const template = deck[0] ?? PROMPTS[0];
	return {
		...model,
		deck: deck.slice(1),
		prompt: fill(template, model.order),
		step: "cover",
		cursor: 0,
		answers: [],
		pile: []
	};
}
function Phrases({ mode }) {
	const players = useParty((state) => state.players);
	const [model, setModel] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedPlayers, {
				min: 3,
				count: players.length,
				children: !model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "La phrase a un trou"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Chacun écrit à l'abri des regards. Le juge couronne la fin qu'il préfère. Premier à 5 points."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => {
							const scores = {};
							const order = players.map((player) => ({
								...player,
								name: player.name.trim() || "Invité"
							}));
							for (const player of order) scores[player.id] = 0;
							setModel(openRound({
								order,
								judge: 0,
								prompt: "",
								deck: shuffle(PROMPTS),
								step: "cover",
								cursor: 0,
								answers: [],
								pile: [],
								scores,
								log: []
							}));
						},
						children: "Tirer une phrase"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table$1, {
					model,
					setModel,
					onReset: () => setModel(null)
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Phrases à lire tout haut, et cartes-réponses au prénom de chacun." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Phrases"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: PROMPTS.map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold text-gold",
							children: "Phrases de Soie"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl leading-snug",
							children: prompt.replaceAll("{name}", "______")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Le juge lit. Les autres écrivent."
						})
					] }, prompt))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 font-display text-2xl",
					children: "Réponses"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
								name: player.name,
								photo: player.photo,
								className: "size-10 text-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-extrabold",
								children: player.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block border-b border-gold" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block border-b border-gold" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block border-b border-gold" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Une idée, puis on plie."
						})
					] }, player.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "À trois au moins. Le juge lit la phrase. Chaque autre joueur écrit une fin, sans la montrer." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Le juge choisit sa préférée et donne un point. On change de juge. Le premier à cinq remporte le ruban." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "À l'impression, le prénom devient un blanc : la table le choisit à voix haute." })
				]
			}) })
		})
	] });
}
function Table$1({ model, setModel, onReset }) {
	const judge = model.order[model.judge];
	const writers = model.order.filter((player) => player.id !== judge?.id);
	function award(answer) {
		if (!judge) return;
		const scores = {
			...model.scores,
			[answer.playerId]: (model.scores[answer.playerId] ?? 0) + 1
		};
		const who = model.order.find((player) => player.id === answer.playerId);
		const log = [`${judge.name} couronne ${who?.name ?? "quelqu'un"} : « ${answer.text} »`, ...model.log].slice(0, 6);
		if (Object.values(scores).some((score) => score >= 5)) {
			setModel({
				...model,
				scores,
				log,
				step: "end"
			});
			return;
		}
		const judgeIndex = (model.judge + 1) % model.order.length;
		setModel(openRound({
			...model,
			scores,
			log,
			judge: judgeIndex
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1.4fr_0.6fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: model.step === "end" || !judge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Winner, {
			model,
			onReset
		}) : model.step === "judge" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-extrabold text-gold",
				children: [judge.name, " juge"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-3xl leading-tight",
				children: model.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: model.pile.map((answer) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => award(answer),
					className: "min-h-11 rounded-2xl border border-line bg-parchment px-3 py-3 text-left font-extrabold",
					children: answer.text
				}, answer.playerId))
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Writer, {
			prompt: model.prompt,
			player: writers[model.cursor],
			hidden: model.step === "cover",
			onOpen: () => setModel({
				...model,
				step: "write"
			}),
			onAnswer: (text) => {
				const player = writers[model.cursor];
				if (!player) return;
				const answers = [...model.answers, {
					playerId: player.id,
					text
				}];
				if (model.cursor + 1 >= writers.length) {
					setModel({
						...model,
						answers,
						pile: shuffle(answers),
						step: "judge"
					});
					return;
				}
				setModel({
					...model,
					answers,
					cursor: model.cursor + 1,
					step: "cover"
				});
			}
		}, `${model.judge}-${model.cursor}-${model.prompt}`) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Rubans"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: model.order.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 font-extrabold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
								name: player.name,
								photo: player.photo,
								className: "size-8 text-sm"
							}),
							player.name,
							player.id === judge?.id && model.step !== "end" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-extrabold text-gold",
								children: "juge"
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: model.scores[player.id] ?? 0 })]
				}, player.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogList, { lines: model.log }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "ghost",
				onClick: onReset,
				children: "Ranger les phrases"
			})
		] })]
	});
}
function Writer({ prompt, player, hidden, onOpen, onAnswer }) {
	const [text, setText] = (0, import_react.useState)("");
	if (!player) return null;
	if (hidden) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl",
			children: player.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: "Le juge et les autres regardent ailleurs."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: onOpen,
			children: "Écrire ma réponse"
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm font-extrabold text-gold",
			children: [player.name, " écrit"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-display text-3xl leading-tight",
			children: prompt
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: text,
			maxLength: 80,
			onChange: (event) => setText(event.target.value),
			placeholder: "Votre fin de phrase",
			className: "mt-4 min-h-24 w-full rounded-2xl border border-line bg-parchment p-3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-3",
			disabled: !text.trim(),
			onClick: () => onAnswer(text.trim()),
			children: "Plier la réponse"
		})
	] });
}
function Winner({ model, onReset }) {
	const best = [...model.order].sort((a, b) => (model.scores[b.id] ?? 0) - (model.scores[a.id] ?? 0))[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-extrabold text-gold",
			children: "Cinq rubans"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl",
			children: best ? `${best.name} emporte la soirée` : "Fin"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			variant: "line",
			onClick: onReset,
			children: "Rejouer"
		})
	] });
}
var SUITS = [
	{
		id: "rose",
		label: "Rose",
		icon: Flower2
	},
	{
		id: "lune",
		label: "Lune",
		icon: Moon
	},
	{
		id: "etoile",
		label: "Étoile",
		icon: Sparkles
	},
	{
		id: "couronne",
		label: "Couronne",
		icon: Crown
	}
];
var TARGET = 21;
function freshDeck() {
	const cards = [];
	for (const suit of SUITS) for (let rank = 1; rank <= 7; rank += 1) cards.push({
		id: `${suit.id}-${rank}`,
		suit: suit.id,
		rank
	});
	return shuffle(cards);
}
function legal(card, top) {
	if (!top) return true;
	return card.suit === top.suit || card.rank === top.rank;
}
function deal(players, scores) {
	const seats = players.slice(0, 4).map((player) => ({
		id: player.id,
		name: player.name.trim() || "Invité",
		photo: player.photo
	}));
	const deck = freshDeck();
	const hands = seats.map(() => deck.splice(0, 5));
	let turn = 0;
	seats.forEach((_, index) => {
		if (hands[index]?.some((card) => card.suit === "couronne" && card.rank === 7)) turn = index;
	});
	return {
		seats,
		hands,
		deck,
		top: null,
		turn,
		scores: scores ?? seats.map(() => 0),
		pending: null,
		note: `${seats[turn]?.name ?? "Quelqu'un"} ouvre la ronde.`,
		over: false,
		halted: false
	};
}
function Ronde({ mode }) {
	const players = useParty((state) => state.players);
	const [model, setModel] = (0, import_react.useState)(null);
	const table = players.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: players.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "Deux blasons au moins."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Ajoutez un visage dans l'atelier. Au-delà de quatre, les quatre premiers jouent."
			})] }) : !model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Posez le blason qui répond"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: [
						"Même fleur ou même chiffre que la carte du milieu. Sinon, une seule pioche. Vider sa main rapporte les chiffres qui restent aux autres. On joue jusqu'à ",
						TARGET,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					onClick: () => setModel(deal(table)),
					children: "Distribuer"
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
				model,
				setModel,
				onReset: () => setModel(null),
				source: table
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Vingt-huit cartes. Imprimez-les deux fois si vous voulez un dos illustré à coller : le dos est en bas de page." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid",
					children: SUITS.flatMap((suit) => Array.from({ length: 7 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Face, { card: {
						id: `${suit.id}-${index + 1}`,
						suit: suit.id,
						rank: index + 1
					} }, `${suit.id}-${index + 1}`)))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 font-display text-2xl",
					children: "Dos"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-grid mt-3",
					children: Array.from({ length: 8 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "sheet-card flex flex-col items-center justify-center rounded-2xl border border-gold bg-gold-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, {
							className: "size-8 text-gold",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-xl",
							children: "Ronde"
						})]
					}, index))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Quatre blasons, chiffres de 1 à 7. On pose une carte du même blason ou du même chiffre." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Si rien ne va, on pioche une carte. Si elle va, on peut la poser ou la garder. Sinon le tour passe." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Le premier sans carte marque la somme des chiffres encore en main. Première personne à ",
						TARGET,
						" points."
					] })
				]
			}) })
		})
	] });
}
function Table({ model, setModel, onReset, source }) {
	const seat = model.seats[model.turn];
	const hand = model.hands[model.turn] ?? [];
	function finishIfEmpty(next, who) {
		if ((next.hands[who] ?? []).length > 0) return next;
		const gained = next.hands.reduce((sum, cards, index) => {
			if (index === who) return sum;
			return sum + cards.reduce((inner, card) => inner + card.rank, 0);
		}, 0);
		const scores = next.scores.map((score, index) => index === who ? score + gained : score);
		const name = next.seats[who]?.name ?? "";
		const over = scores[who] >= TARGET;
		return {
			...next,
			scores,
			over,
			note: over ? `${name} vide sa main, marque ${gained} et atteint ${scores[who]}.` : `${name} vide sa main et marque ${gained}.`
		};
	}
	function play(card, fromPending = false) {
		if (!legal(card, model.top)) return;
		const hands = model.hands.map((cards, index) => index === model.turn ? cards.filter((item) => item.id !== card.id) : cards);
		const emptied = (hands[model.turn] ?? []).length === 0;
		const drafted = {
			...model,
			hands,
			top: card,
			pending: null,
			turn: emptied ? model.turn : (model.turn + 1) % model.seats.length,
			halted: emptied,
			note: `${seat?.name} pose ${label(card)}.`
		};
		setModel(emptied ? finishIfEmpty(drafted, model.turn) : drafted);
	}
	function draw() {
		if (model.deck.length === 0) {
			setModel({
				...model,
				turn: (model.turn + 1) % model.seats.length,
				note: `${seat?.name} ne peut rien poser. La pioche est vide.`
			});
			return;
		}
		const [card, ...rest] = model.deck;
		if (!card) return;
		if (legal(card, model.top)) {
			setModel({
				...model,
				deck: rest,
				pending: card,
				note: `${seat?.name} pioche ${label(card)}.`
			});
			return;
		}
		const hands = model.hands.map((cards, index) => index === model.turn ? [...cards, card] : cards);
		setModel({
			...model,
			hands,
			deck: rest,
			turn: (model.turn + 1) % model.seats.length,
			note: `${seat?.name} pioche ${label(card)}, qui ne se pose pas.`
		});
	}
	const canAny = hand.some((card) => legal(card, model.top));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1.3fr_0.7fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: model.note
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex justify-center",
				children: model.top ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, { card: model.top }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Le centre est libre."
				})
			}),
			model.over ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "line",
				onClick: onReset,
				children: "Nouvelle partie"
			}) : model.halted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => setModel(deal(source, model.scores)),
				children: "Donner à nouveau"
			}) : model.pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-extrabold",
					children: ["Carte piochée : ", label(model.pending)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => play(model.pending, true),
						children: "La poser"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "line",
						onClick: () => {
							const hands = model.hands.map((cards, index) => index === model.turn && model.pending ? [...cards, model.pending] : cards);
							setModel({
								...model,
								hands,
								pending: null,
								turn: (model.turn + 1) % model.seats.length,
								note: `${seat?.name} garde la pioche.`
							});
						},
						children: "La garder"
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 font-display text-3xl",
					children: seat?.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: hand.map((card) => {
						const ok = legal(card, model.top);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !ok,
							onClick: () => play(card),
							className: "disabled:opacity-35",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
								card,
								mute: !ok
							})
						}, card.id);
					})
				}),
				!canAny && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					variant: "rose",
					onClick: draw,
					children: "Piocher"
				})
			] })
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Blasons"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: model.seats.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 font-extrabold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: item.name,
							photo: item.photo,
							className: "size-8 text-sm"
						}), item.name]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						model.scores[index],
						" · ",
						model.hands[index]?.length ?? 0,
						" cartes"
					] })]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				variant: "ghost",
				onClick: onReset,
				children: "Quitter la ronde"
			})
		] })]
	});
}
function label(card) {
	return `${SUITS.find((item) => item.id === card.suit)?.label ?? ""} ${card.rank}`;
}
function Mini({ card, mute }) {
	const suit = SUITS.find((item) => item.id === card.suit);
	const Icon = suit?.icon ?? Crown;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("flex h-24 w-16 flex-col items-center justify-center rounded-2xl border bg-cream", mute ? "border-line" : "border-gold"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-5 text-gold",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-2xl",
				children: card.rank
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-extrabold",
				children: suit?.label
			})
		]
	});
}
function Face({ card }) {
	const suit = SUITS.find((item) => item.id === card.suit);
	const Icon = suit?.icon ?? Crown;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-extrabold text-gold",
		children: "Ronde des Blasons"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col items-center justify-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-8 text-rose",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-5xl",
				children: card.rank
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-extrabold",
				children: suit?.label
			})
		]
	})] });
}
var LINKS = {
	3: {
		to: 16,
		up: true
	},
	8: {
		to: 22,
		up: true
	},
	19: {
		to: 31,
		up: true
	},
	28: {
		to: 37,
		up: true
	},
	14: {
		to: 5,
		up: false
	},
	24: {
		to: 11,
		up: false
	},
	33: {
		to: 20,
		up: false
	},
	39: {
		to: 26,
		up: false
	}
};
function squareAt(row, col) {
	const fromBottom = 4 - row;
	return fromBottom * 8 + (fromBottom % 2 === 0 ? col : 7 - col) + 1;
}
function hop(from, roll) {
	const land = Math.min(40, from + roll);
	if (land >= 40) return {
		pos: 40,
		note: "atteint le sommet"
	};
	const link = LINKS[land];
	if (!link) return {
		pos: land,
		note: `s'arrête sur la marche ${land}`
	};
	if (link.up) return {
		pos: link.to,
		note: `grimpe l'escalier ${land} → ${link.to}`
	};
	return {
		pos: link.to,
		note: `glisse sur le ruban ${land} → ${link.to}`
	};
}
function Tour({ mode }) {
	const players = useParty((state) => state.players);
	const [pawns, setPawns] = (0, import_react.useState)(null);
	const [turn, setTurn] = (0, import_react.useState)(0);
	const [die, setDie] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("Le premier en haut de la tour gagne. Pas besoin de la marche exacte.");
	const [winner, setWinner] = (0, import_react.useState)(null);
	function begin(source) {
		setPawns(source.map((player) => ({
			id: player.id,
			name: player.name.trim() || "Invité",
			photo: player.photo,
			pos: 0
		})));
		setTurn(0);
		setDie(null);
		setWinner(null);
		setNote("Tout le monde est au pied de la tour.");
	}
	function roll() {
		if (!pawns || winner) return;
		const value = 1 + Math.floor(Math.random() * 6);
		const pawn = pawns[turn];
		if (!pawn) return;
		const moved = hop(pawn.pos, value);
		const next = pawns.map((item, index) => index === turn ? {
			...item,
			pos: moved.pos
		} : item);
		setDie(value);
		setPawns(next);
		if (moved.pos >= 40) {
			setWinner(pawn.id);
			setNote(`${pawn.name} fait ${value} et ${moved.note}.`);
			return;
		}
		setNote(`${pawn.name} fait ${value} et ${moved.note}.`);
		setTurn((turn + 1) % next.length);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "jouer" ? "print:hidden" : "hidden print:hidden",
			children: !pawns ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Quarante marches"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Les escaliers montent d'un bond. Les rubans roses redescendent. Les pions sont vos portraits."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					onClick: () => begin(players),
					disabled: players.length < 2,
					children: "Poser les pions"
				}),
				players.length < 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Deux visages au moins."
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[1.4fr_0.6fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, { pawns }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					die ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Die, { value: die }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 leading-relaxed",
						children: note
					}),
					winner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-display text-3xl",
						children: [pawns.find((pawn) => pawn.id === winner)?.name, " couronne la tour."]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-extrabold",
						children: ["Au pied du dé : ", pawns[turn]?.name]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: roll,
							disabled: Boolean(winner),
							children: "Lancer le dé"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "line",
							onClick: () => begin(players),
							children: "Recommencer"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2",
						children: pawns.map((pawn) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2 text-sm font-extrabold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
									name: pawn.name,
									photo: pawn.photo,
									className: "size-8 text-sm"
								}),
								pawn.name,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: pawn.pos === 0 ? "départ" : `marche ${pawn.pos}`
								})
							]
						}, pawn.id))
					})
				] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: mode === "imprimer" ? "" : "hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintBar, { children: "Plateau à suivre du bas vers le haut, en serpentin. Découpez les pions ronds." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, { pawns: players.map((player) => ({
					id: player.id,
					name: player.name,
					photo: player.photo,
					pos: -1
				})) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-3",
					children: players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "avoid-break flex w-24 flex-col items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: player.name,
							photo: player.photo,
							className: "size-16 text-xl"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-center text-sm font-extrabold",
							children: player.name
						})]
					}, player.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mode === "regles" ? "print:hidden" : "hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "On lance un dé et l'on avance d'autant de marches, en partant du bas à gauche." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Une marche dorée avec une flèche monte plus haut. Une marche rose redescend. Le premier à atteindre ou dépasser 40 gagne." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Escaliers : 3→16, 8→22, 19→31, 28→37. Rubans : 14→5, 24→11, 33→20, 39→26." })
				]
			}) })
		})
	] });
}
function Board({ pawns }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-8 gap-1",
		children: Array.from({ length: 5 }, (_, row) => Array.from({ length: 8 }, (_, col) => {
			const n = squareAt(row, col);
			const link = LINKS[n];
			const here = pawns.filter((pawn) => pawn.pos === n);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex min-h-14 flex-col justify-between rounded-xl border p-1", link?.up ? "border-gold bg-gold-soft" : link ? "border-rose bg-rose-soft" : "border-line bg-cream"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-extrabold",
						children: n
					}),
					link ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("text-xs font-extrabold", link.up ? "text-gold" : "text-rose"),
						children: [
							link.up ? "↑" : "↓",
							" ",
							link.to
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex flex-wrap gap-0.5",
						children: here.map((pawn) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							name: pawn.name,
							photo: pawn.photo,
							className: "size-5 text-xs"
						}, pawn.id))
					})
				]
			}, `${row}-${col}`);
		}))
	});
}
var VIEWS = {
	minuit: Minuit,
	mystere: Mystere,
	phrases: Phrases,
	domaine: Domaine,
	memoire: Memoire,
	tour: Tour,
	eclats: Eclats,
	ronde: Ronde
};
function GamePage() {
	const { gameId } = Route.useParams();
	const game = findGame(gameId);
	const houseName = useParty((state) => state.houseName);
	const [mode, setMode] = (0, import_react.useState)("jouer");
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl",
		children: "Ce jeu n'est pas dans le coffret."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "mt-4 inline-flex min-h-11 items-center font-extrabold text-gold",
		children: "Retour au salon"
	})] });
	const View = VIEWS[game.id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/",
			className: "inline-flex min-h-11 items-center gap-2 text-sm font-extrabold print:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
				className: "size-4",
				"aria-hidden": "true"
			}), "Salon"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-extrabold text-gold",
					children: [
						"Édition · ",
						houseName,
						" · ",
						game.players,
						" · ",
						game.time
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl leading-tight sm:text-5xl",
					children: game.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: game.pitch
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex rounded-full bg-gold-soft p-1 print:hidden",
				role: "tablist",
				children: [
					{
						id: "jouer",
						label: "Jouer"
					},
					{
						id: "imprimer",
						label: "Imprimer"
					},
					{
						id: "regles",
						label: "Règles"
					}
				].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": mode === tab.id,
					onClick: () => setMode(tab.id),
					className: cn("min-h-11 rounded-full px-4 text-sm font-extrabold", mode === tab.id ? "bg-cream text-ink shadow-sm" : "text-ink/70"),
					children: tab.label
				}, tab.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, { mode })
		})
	] });
}
//#endregion
export { GamePage as component };
