import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Printer, v as Crown } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-91VX8Rel.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function shuffle(list) {
	const copy = [...list];
	for (let i = copy.length - 1; i > 0; i -= 1) {
		const j = Math.floor(Math.random() * (i + 1));
		const current = copy[i];
		copy[i] = copy[j];
		copy[j] = current;
	}
	return copy;
}
function uid() {
	return Math.random().toString(36).slice(2, 10);
}
var KEY = "atelier-petit-roi-v1";
function defaults() {
	return {
		houseName: "La maison des étoiles",
		players: [
			{
				id: "lea",
				name: "Léa"
			},
			{
				id: "sacha",
				name: "Sacha"
			},
			{
				id: "ines",
				name: "Inès"
			},
			{
				id: "noe",
				name: "Noé"
			}
		]
	};
}
function persist(data) {
	try {
		localStorage.setItem(KEY, JSON.stringify(data));
		return "";
	} catch {
		return "Le portrait est trop lourd pour rester en mémoire sur cet appareil.";
	}
}
var useParty = create((set, get) => ({
	...defaults(),
	notice: "",
	hydrate: () => {
		try {
			const raw = localStorage.getItem(KEY);
			if (!raw) return;
			const parsed = JSON.parse(raw);
			if (!parsed.players?.length) return;
			const players = parsed.players.filter((player) => player && typeof player.id === "string" && typeof player.name === "string");
			if (!players.length) return;
			set({
				houseName: typeof parsed.houseName === "string" && parsed.houseName.trim() ? parsed.houseName : defaults().houseName,
				players
			});
		} catch {}
	},
	setHouseName: (houseName) => {
		const players = get().players;
		set({
			houseName,
			notice: persist({
				houseName,
				players
			})
		});
	},
	addPlayer: () => {
		const players = [...get().players, {
			id: uid(),
			name: "Invité"
		}];
		if (players.length > 10) return;
		const houseName = get().houseName;
		set({
			players,
			notice: persist({
				houseName,
				players
			})
		});
	},
	updatePlayer: (id, patch) => {
		const players = get().players.map((player) => player.id === id ? {
			...player,
			...patch
		} : player);
		const houseName = get().houseName;
		set({
			players,
			notice: persist({
				houseName,
				players
			})
		});
	},
	removePlayer: (id) => {
		const players = get().players.filter((player) => player.id !== id);
		if (!players.length) return;
		const houseName = get().houseName;
		set({
			players,
			notice: persist({
				houseName,
				players
			})
		});
	},
	clearNotice: () => set({ notice: "" })
}));
function Shell({ children }) {
	const hydrate = useParty((state) => state.hydrate);
	const path = useRouterState({ select: (state) => state.location.pathname });
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "print:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex min-h-11 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 items-center justify-center rounded-full bg-gold text-cream",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg leading-tight sm:text-xl",
							children: "L'Atelier du Petit Roi"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex items-center gap-1",
						children: [{
							to: "/",
							label: "Salon"
						}, {
							to: "/atelier",
							label: "Atelier"
						}].map((link) => {
							const active = path === link.to;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: link.to,
								className: cn("inline-flex min-h-11 items-center rounded-full px-4 text-sm font-extrabold", active ? "bg-ink text-cream" : "text-ink hover:bg-gold-soft"),
								children: link.label
							}, link.to);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-6xl px-4 pb-16",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "print:hidden mx-auto w-full max-w-6xl px-4 pb-10 text-sm text-muted",
				children: "Jeux originaux de l'atelier. Les portraits restent sur cet appareil : rien n'est envoyé."
			})
		]
	});
}
var buttonStyles = cva("inline-flex items-center justify-center gap-2 rounded-full font-extrabold transition duration-200 disabled:cursor-not-allowed disabled:opacity-45", {
	variants: {
		variant: {
			gold: "bg-gold text-cream hover:opacity-90",
			rose: "bg-rose text-cream hover:opacity-90",
			line: "border border-line bg-cream text-ink hover:border-gold",
			ghost: "bg-transparent text-ink hover:bg-gold-soft"
		},
		size: {
			md: "min-h-11 px-5 text-base",
			sm: "min-h-11 px-4 text-sm"
		}
	},
	defaultVariants: {
		variant: "gold",
		size: "md"
	}
});
function buttonClass(opts) {
	return buttonStyles(opts);
}
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonStyles({
			variant,
			size
		}), className),
		...props
	});
}
function Portrait({ name, photo, className }) {
	const letter = name.trim().charAt(0).toUpperCase() || "?";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-rose-soft font-display text-rose ring-2 ring-gold-soft", className),
		children: photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: photo,
			alt: "",
			className: "h-full w-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			children: letter
		})
	});
}
function Frame({ name, photo, className }) {
	const letter = name.trim().charAt(0).toUpperCase() || "?";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex items-center justify-center overflow-hidden rounded-2xl border border-gold bg-gold-soft font-display text-gold", className),
		children: photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: photo,
			alt: "",
			className: "h-full w-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			children: letter
		})
	});
}
function Panel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-3xl border border-line bg-cream p-4 shadow-sm sm:p-5", className),
		children
	});
}
function NeedPlayers({ min, count, children }) {
	if (count >= min) return children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: "La table est encore trop petite."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-muted",
			children: [
				"Ce jeu demande ",
				min,
				" visages. La maison en compte ",
				count,
				"."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/atelier",
			className: cn(buttonClass(), "mt-4"),
			children: "Composer la maison"
		})
	] });
}
function PrintBar({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 flex flex-wrap items-center justify-between gap-3 print:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-xl text-sm text-muted",
			children: children ?? "Planches au format carte. Imprimez, ou enregistrez en PDF, puis découpez le filet."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "line",
			onClick: () => window.print(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
				className: "size-4",
				"aria-hidden": "true"
			}), "Imprimer"]
		})]
	});
}
function PaperCard({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: cn("sheet-card flex flex-col justify-between overflow-hidden rounded-2xl border border-gold bg-cream p-3 text-ink", className),
		children
	});
}
function LogList({ lines }) {
	if (!lines.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "mt-4 space-y-1 text-sm text-muted",
		children: lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, `${index}-${line}`))
	});
}
var PIP = {
	1: [4],
	2: [0, 8],
	3: [
		0,
		4,
		8
	],
	4: [
		0,
		2,
		6,
		8
	],
	5: [
		0,
		2,
		4,
		6,
		8
	],
	6: [
		0,
		2,
		3,
		5,
		6,
		8
	]
};
function Die({ value }) {
	const on = new Set(PIP[value] ?? []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-label": `Dé ${value}`,
		className: "grid h-14 w-14 grid-cols-3 gap-1 rounded-2xl border border-gold bg-cream p-1.5",
		children: Array.from({ length: 9 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("rounded-full", on.has(index) ? "bg-ink" : "bg-transparent") }, index))
	});
}
//#endregion
export { NeedPlayers as a, Portrait as c, buttonClass as d, cn as f, useParty as h, LogList as i, PrintBar as l, uid as m, Die as n, Panel as o, shuffle as p, Frame as r, PaperCard as s, Button as t, Shell as u };
