//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bp7XlOzr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/atelier",
			"/jeu/$gameId"
		],
		preloads: ["/assets/index-CZqpbH05.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CZqpbH05.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Dkfz1EFE.js",
			"/assets/ui-C7C8HJ4X.js",
			"/assets/games-CKTHiBnw.js",
			"/assets/image-plus-DXEi1XHQ.js"
		]
	},
	"/atelier": {
		filePath: "/workspace/src/routes/atelier.tsx",
		children: void 0,
		preloads: [
			"/assets/atelier-CC7UJDEu.js",
			"/assets/ui-C7C8HJ4X.js",
			"/assets/image-plus-DXEi1XHQ.js"
		]
	},
	"/jeu/$gameId": {
		filePath: "/workspace/src/routes/jeu.$gameId.tsx",
		children: void 0,
		preloads: [
			"/assets/jeu._gameId-Bkpr88zR.js",
			"/assets/ui-C7C8HJ4X.js",
			"/assets/games-CKTHiBnw.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
